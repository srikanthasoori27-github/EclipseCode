var app = angular.module('SelfServiceRoles', ['ui.bootstrap','sailpoint.i18n','ngRoute',
	'sailpoint.util', 'sailpoint.ui.bootstrap.carousel', 'sailpoint.dataview', 'sailpoint.config',
	'sailpoint.modal']);

var pluginName = "selfserviceroles";
var debug = false;

app.config(
	function ( $routeProvider, $httpProvider, $provide) {
	
		$httpProvider.defaults.xsrfCookieName = "CSRF-TOKEN";
		
		$routeProvider.when('/' , {
			templateUrl: PluginHelper.getPluginFileUrl(pluginName ,'ui/templates/search.html'),
			controller: 'SearchRoleController',
			controllerAs: 'search'
		})
		.when("/create", {
			templateUrl: PluginHelper.getPluginFileUrl(pluginName ,'ui/templates/role-main.html'),
			controller: 'MainController',
			controllerAs: 'main'
		})
		.when("/edit/:id", {
			templateUrl: PluginHelper.getPluginFileUrl(pluginName ,'ui/templates/role-main.html'),
			controller: 'MainController',
			controllerAs: 'main'
		});
	});
	

app.controller('HomePage', function($scope, RoleService) {

	$scope.isCustomMessageCollapsed = false;
	$scope.customMessage = null;
	$scope.hasCustomMessage = function() {
	
		var has = false;
		var message = $scope.customMessage;
		if ( message && message.length > 0) has =  true;
		return has;
		
	}
	
	function init() {
	
		RoleService.getUIConfig().then(function success(uiConfig) {
			
			$scope.customMessage  = uiConfig.customHeaderMessage;
			
		}, function error(error) {
			
			return error;
		});	
	}
	
	
	init();
	
});
	