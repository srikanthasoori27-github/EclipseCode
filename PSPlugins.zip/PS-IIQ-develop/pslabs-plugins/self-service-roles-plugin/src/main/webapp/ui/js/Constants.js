
const broadcastEvents = {

	ROLE_TYPE_CHANGE: "roleTypeChange",
	ROLE_MODEL_CREATED: "roleModelCreated"
}
