/*
 * Workfile:     BulkApprovals.js
 * Purpose:      Responsible for loading approval details into bulk approvals page
 * 1. It is a full page link with link shown on IIQ home page under a) My Work-> Bulk Approvals and b) Bell notification icon -> (count)Bulk Approvals
 * 2. It shows a table listing all "Approval" type work items to be acted upon on bulk
 * 
 */
const COMMENT_DIALOG_TEMPLATE_URL = 'common/comment/template/comment-dialog.html';
var bulkApprovalsModule = angular.module('BulkApprovals', ['ui.bootstrap','sailpoint.comment','sailpoint.esig','angular-loading-bar', 'ngAnimate', 'ngSanitize', 'sailpoint.modal', 'datatables']);

bulkApprovalsModule.config(['$locationProvider', function($locationProvider){
$locationProvider.html5Mode({
  enabled: true,
  requireBase: false
  })
}])

bulkApprovalsModule.config(function ($httpProvider) {
  $httpProvider.defaults.xsrfCookieName = "CSRF-TOKEN";
});


/**
 * Controller for the bulk approvals
 */
bulkApprovalsModule.controller('BulkApprovals', function(bulkApprovalsService, commentService,electronicSignatureService,spModal, $q, $location,$compile, $scope, $uibModal,$window, DTOptionsBuilder, DTColumnDefBuilder, DTColumnBuilder) {
	
	var me = this,
			promises;

	me.workItems = [];

	me.contextPath = "";

	me.selectedPage = false;

	me.alerts = [
	 ];

	me.workItemsPayload = []; 

	me.selected = {};
	
	me.selectAll = false;


    $scope.back = function() {
        $window.history.back();
    }

    
    function fetchAllWorkItemsPayload() {
        return bulkApprovalsService.getAllWorkItemsPayload();
    }

    function getContextPath() {
        return bulkApprovalsService.getContextPath();
    }
	
    me.getAllWorkItemsPayload = function() {
		getContextPath().then(function(data) {
		    me.contextPath = data;
            fetchAllWorkItemsPayload().then(function(data) {
                me.workItems = data;
                return data;
            });
		});
	};

  	function fetchHideColumnList() {
  	     	   
		return bulkApprovalsService.getToHideColumnList();
	
	}
  	     
	me.getHideColumnList = function() {
				 
		fetchHideColumnList().then(function(data) {
			
			return data;
		});
	}
  	     
  	
  	function fetchShowColumnList() {

		return bulkApprovalsService.getToShowColumnList();
	}
  	     
  	me.getShowColumnList = function() {
  	         
		fetchShowColumnList().then(function(data) {

		return data;
			  
		});

	}

	function sendApprovalRequest (jsonPayload) {
	    var payload = JSON.stringify(jsonPayload);
        bulkApprovalsService.addApprovalCommentandApprove(payload).then(function(data) {
            me.getAllWorkItemsPayload();
            $scope.dtInstance.reloadData();
            $window.location.reload();
            me.applyAlerts(data);
            me.selectAll = false;

         });
	}

	function sendRejectionRequest(jsonPayload) {
		var payload = JSON.stringify(jsonPayload);
        bulkApprovalsService.addRejectionCommentAndReject(payload).then(function(data) {
            me.getAllWorkItemsPayload();
            $scope.dtInstance.reloadData();
            $window.location.reload();
            me.applyAlerts(data);
            me.selectAll = false;
         });
	}
  	
    $scope.addApprovalCommentandApprove = function() {
    	var originalpayload = me.findSelectedItems();
    	if(originalpayload != '') {

    		var jsonPayload = JSON.parse(originalpayload);   		
    		showCommentDialog('#{msgs.dialog_title_approval_comments}','#{msgs.bulkapprovals_enter_appr_comments}','#{msgs.bulkapprovals_approved} ',false).then(function(comment) {

            	var approvalComment = comment;
            	var esigMap = new Map();

                for(let i = 0; i < jsonPayload.length; i++){
                    var esigName = jsonPayload[i].esigName;
                    var esigValue = esigMap.get(esigName);
                    if(!esigValue) {
                        var esigMeaning = jsonPayload[i].esigMeaning;
                        esigMap.set(esigName,esigMeaning);
                    }
                }
            	for(let i = 0; i < jsonPayload.length; i++){
            		jsonPayload[i].approvalComment = approvalComment;
            	}

            	payload = {}
                payload ["data"] = jsonPayload;

                var approved = 0;
                if(esigMap != 0) {
                    esigMap.forEach(function(value, key) {
                        electronicSignatureService.openDialog(value).then(function(result) {
                            approved++;
                            payload ["signatureUsername"] = result.username;
                            payload ["signaturePassword"] = result.password;

                            if(approved >= esigMap.size) {
                                sendApprovalRequest(payload);
                            }
                        });
                    });
                }else {
                    sendApprovalRequest(payload);
                }
    		});

    	}
    }
    
    $scope.addRejectionCommentAndReject = function() {
    	var originalpayload = me.findSelectedItems();
    	if(originalpayload != '') {
 
    		var jsonPayload = JSON.parse(originalpayload);

    		showCommentDialog('#{msgs.dialog_title_rejection_comments}','#{msgs.bulkapprovals_enter_rejection_comments}','',false).then(function(comment) {
    			var rejectionComment = comment;
    			var esigMap = new Map();

                for(let i = 0; i < jsonPayload.length; i++){
                    var esigName = jsonPayload[i].esigName;
                    var esigValue = esigMap.get(esigName);
                    if(!esigValue) {
                        var esigMeaning = jsonPayload[i].esigMeaning;
                        esigMap.set(esigName,esigMeaning);
                    }
                }

    			for(let i = 0; i < jsonPayload.length; i++){
            		jsonPayload[i].rejectionComment = rejectionComment;
            	}

                payload = {}
                payload ["data"] = jsonPayload;

                var rejected = 0;
                if(esigMap != 0) {
                    esigMap.forEach(function(value, key) {
                        electronicSignatureService.openDialog(value).then(function(result) {
                            rejected++;
                            payload ["signatureUsername"] = result.username;
                            payload ["signaturePassword"] = result.password;

                            if(rejected == esigMap.size) {
                                sendRejectionRequest(payload);
                            }
                        });
                    });
                }else {
                    sendRejectionRequest(payload);
                }
    		});
    	}
    }

    showCommentDialog = function(title, description, comments, readOnly) {
        return spModal.open({
                title: 'ui_comments',
                templateUrl: COMMENT_DIALOG_TEMPLATE_URL,
                dialogId: 'CommentDialog',
                controller: 'CommentDialogCtrl',
                controllerAs: 'dialogCtrl',
                backdrop: 'static',
                autoFocus: true,
                resolve: {
                    description: function() { return description},
                    comments: function() {return comments},
                    readOnly: function() {return !!readOnly}
                },
                buttons: [{
                    displayValue: (readOnly) ? 'ui_button_close' : 'ui_button_cancel',
                    cancel: true
                }, {
                    displayValue: 'bulkapprovals_button_submit',
                    primary: true,
                    disabled: function() {
                        return readOnly || this.dialogCtrl.comments.length === 0;
                    },
                    action: function() {
                        return this.dialogCtrl.complete();
                    }
                }]
        }).result
    }

    me.findSelectedItems = function() {
        var jsonPayload = [];
        
        Object.keys(me.workItems).forEach(function(entry) {
            var selectedValue = me.selected[me.workItems[entry].fixedRowID];
           
            if(selectedValue){
                var workItemId = me.workItems[entry].workItemID;
                var approvalItemId = me.workItems[entry].approvalItemID;
                var rowID = me.workItems[entry].fixedRowID;
                var esigMeaning = me.workItems[entry].esigMeaning;
                var esigName = me.workItems[entry].esigName;
                
                console.log("workItemId in findSelectedItems: "+workItemId);
                console.log("approvalItemId in findSelectedItems: "+approvalItemId);
                payLoadItem = {};
                payLoadItem ["workItemId"] = workItemId;
                payLoadItem ["approvalItemId"] = approvalItemId;
                payLoadItem ["fixedRowID"] = rowID;
                payLoadItem ["esigMeaning"] = esigMeaning;
                payLoadItem ["esigName"] = esigName;

                jsonPayload.push(payLoadItem);
            }
        });

        if(jsonPayload == 'undefined' || jsonPayload.length == 0){
            me.alerts.push({ type: 'danger', msg: '#{msgs.bulkapprovals_select_atleastone}'});
            return '';
        }

        var payload = JSON.stringify(jsonPayload);

        return payload;
    }

    me.applyAlerts = function(data) {
        for (var id in data.messages) {
            var alert = {};
            var type = data.messages[id].type.toLowerCase();

            if(type === "error") {
                type = "danger";
            }

            alert.type = type;
            alert.msg = data.messages[id].messageOrKey;

            me.alerts.push(alert);
        }
    }

    $scope.closeAlert = function(index) {
        me.alerts.splice(index, 1);
    };

    $scope.refreshList = function() {

        me.getAllWorkItemsPayload();
        me.selectAll = false;
   	 	$scope.dtInstance.reloadData();
   	 	$window.location.reload();
   	 	
    }

    $scope.selectCurrentPage = function() {

        if(me.selectedPage) {

        	Object.keys(me.workItems).forEach(function(entry) {
        	
        		console.log("entry is "+ entry);
        		me.workItems[entry].selected = true;
                
            });
        	me.workItems.selected = true;
        }else {

        	Object.keys(me.workItems).forEach(function(entry) {

        		me.workItems[entry].selected = false;
            });
        }
    };
    
   
	
	me.toggleAll = function(selectAll, selectedItems) {

    	if(selectAll) {
        	Object.keys(me.workItems).forEach(function(entry) {

        		me.selected[me.workItems[entry].fixedRowID] = true;
  
            });

        }else {
        	Object.keys(me.workItems).forEach(function(entry) {
        		
				me.selected[me.workItems[entry].fixedRowID] = false;

            });
        }
    };
	
	me.toggleOne = function(selectedItems) {

        for (var id in selectedItems) {
        	

            if (selectedItems.hasOwnProperty(id)) {
                if(!selectedItems[id]) {
                	me.selectAll = false;
                    return;
                    
                }
            }
        }
        me.selectAll = true;
    };
  
    $scope.optionToggled = function(){

    	me = Object.keys(me.workItems).forEach(function(entry) {
    		return me.selected[me.workItems[entry].fixedRowID];
    	});
    	
    }
    

 // I18N options mentioned here : https://datatables.net/manual/i18n
  //Defining column properties

    $scope.dtOptions = DTOptionsBuilder.fromFnPromise(function() {
        var defer = $q.defer();
        
        fetchAllWorkItemsPayload().then(function(data) {

      	  var payload = JSON.stringify(data); 
        	defer.resolve(data);
        	  
        });
        return defer.promise;
    })
    .withOption('createdRow', function(row, data, dataIndex) {
        // Recompiling so we can bind Angular directive to the DT
        $compile(angular.element(row).contents())($scope);
    })
    .withOption('headerCallback', function(header) {
        if (!$scope.headerCompiled) {
            // Use this headerCompiled field to only compile header once
        	$scope.headerCompiled = true;
            $compile(angular.element(header).contents())($scope);
        }
        
       
    })
    .withPaginationType('full_numbers')
    .withOption('order', [[1, 'asc']]) //ID column
    .withLanguage({
            "sSearch":     "#{msgs.label_search}",
            "emptyTable": "#{msgs.bulkapprovals_emptyTable}",
            "lengthMenu":     "#{msgs.bulkapprovals_lengthMenu}",
            "infoEmpty":     "#{msgs.bulkapprovals_infoEmpty}",
            "info":     "#{msgs.bulkapprovals_info}",
            "paginate": {
                        "first": '#{msgs.nav_first}',
                        "last": '#{msgs.nav_prev}',
                        "next": "#{msgs.nav_next}",
                        "previous": "#{msgs.nav_last}"
                       }


            });



    $scope.dtColumns = getDTColumns();
    
    $scope.dtColumnDefs = getDTColumnDefs();
    
    
  
    function getDTColumns() {
        var defer = $q.defer();
        fetchShowColumnList().then(function(showCol) {

        var attrDisplayName = '';
        var titleHtml = '<input type="checkbox" ng-model="ctrl.selectAll" ng-click="ctrl.toggleAll(ctrl.selectAll,ctrl.selected)">';
        var dtColumns_init = [
			DTColumnBuilder.newColumn(null).withTitle(titleHtml).notSortable()
			.renderWith(function(data, type, full, meta) {

				me.selected[full.fixedRowID] = false;
				return '<input type="checkbox" ng-model="ctrl.selected[' + data.fixedRowID + ']" ng-click="ctrl.toggleOne(ctrl.selected)">';

			}),

			DTColumnBuilder.newColumn(null).withTitle('ID').renderWith(function(data, type, full, meta) {

			return '<a target="_blank" href="'+ me.contextPath + '/workitem/workItem.jsf?id='+data.workItemID+'&reset=true"> ' + data.workItemName + '</a> ';
			}),
		  

			DTColumnBuilder.newColumn('requesteeIdentityDisplayName').withTitle('#{msgs.access_request_hdr_requestee}'),
			DTColumnBuilder.newColumn('approvalItemApplicationId').withTitle('#{msgs.access_provisioning_grid_hdr_application}').withOption('defaultContent', ''),
			DTColumnBuilder.newColumn('approvalItem').withTitle('#{msgs.item}').withOption('defaultContent', ''),
			DTColumnBuilder.newColumn('approvalItemOperation').withTitle('#{msgs.label_operation}'),
			DTColumnBuilder.newColumn('approvalItemAccount').withTitle('#{msgs.approvalitem_account_name}').withOption('defaultContent', ''),
			DTColumnBuilder.newColumn('approvalItemValue').withTitle('#{msgs.approvalitem_values}').withOption('defaultContent', ''),
			DTColumnBuilder.newColumn('approvalItemDescription').withTitle('#{msgs.ui_entitlements_table_description}').renderWith(function(data, type, full, meta) {
				var content = "";
				if(data) {
				    content = '<sp-more-less-toggle large-max-length="100" text="' + Ext.String.htmlEncode(data) + '" sr-label="test description"></sp-more-less-toggle>';
				}

				return content;

			}),
			DTColumnBuilder.newColumn('approvalItemOwner').withTitle('#{msgs.ui_work_item_details_owner}'),
			DTColumnBuilder.newColumn('approvalItemCreated').withTitle('#{msgs.ui_work_item_details_created}'),
			DTColumnBuilder.newColumn('approvalItemRequester').withTitle('#{msgs.ui_work_item_details_requester}'),
			DTColumnBuilder.newColumn('approvalItemManager').withTitle('#{msgs.ui_access_manager}').withOption('defaultContent', ''),
			DTColumnBuilder.newColumn('approvalItemJustification').withTitle('#{msgs.bulkapprovals_justification}').renderWith(function(data, type, full, meta) {
			    var content = "";
			    if(data) {
			       content = '<sp-more-less-toggle large-max-length="100" text="' + Ext.String.htmlEncode(data) + '" sr-label="test description"></sp-more-less-toggle>';
			    }

                return content;
            })

    	];

		if(showCol && showCol.length >0 ){
			for (var colIdx = 0; colIdx < showCol.length; colIdx++) {	

				dtColumns_init.push(DTColumnBuilder.newColumn(showCol[colIdx].trim().split(":")[0]).withTitle(showCol[colIdx].trim().split(":")[1]).withOption('defaultContent', ''));

			}
		}

   
        defer.resolve(dtColumns_init);
        });
        return defer.promise;
          
   
    }


    
    function getDTColumnDefs() {
        var defer = $q.defer();
        
        fetchHideColumnList().then(function(data) {

        	var dtColumnDefs_init = [
        			{ "width": "10px", "targets": 0 },
        			{ "width": "15px", "targets": 1 },
        			{"className": "dt-left", "targets": "_all"},
        	    ];
        	  
			//Extending column properties
			for (var colIdx = 0; colIdx < data.length; colIdx++) {	
				console.log("Column to hide : "+data[colIdx]);
				dtColumnDefs_init.push(DTColumnDefBuilder.newColumnDef(data[colIdx]).notVisible());
			}
        	
          	defer.resolve(dtColumnDefs_init);
          	  
        });
        
        return defer.promise;
         
    }

	$scope.dtInstance = {};

	$q.all(promises).then(function(result) {
	});
  
	promises = {

		workItemsPayload: me.getAllWorkItemsPayload(),

	}; 
  
})   
 
/**
 * Service that handles functionality around members, makes rest call
 */
bulkApprovalsModule.service('bulkApprovalsService', function($http) {

	var config = {
		headers: {
		}
	};

	return {

		addApprovalCommentandApprove: function(payload) {
			var WORK_ITEMS_URL = PluginHelper.getPluginRestUrl('bulkApprovals/addApprovalCommentandApprove');

			return $http.post(WORK_ITEMS_URL, payload, config).then(function(response) {
				return response.data;
			}).catch(function(response) {
				return response;
			});
		},
		
		addRejectionCommentAndReject: function(payload) {
			var WORK_ITEMS_URL = PluginHelper.getPluginRestUrl('bulkApprovals/addRejectionCommentAndReject');

			return $http.post(WORK_ITEMS_URL, payload, config).then(function(response) {
				return response.data;
			}).catch(function(response) {
				return response;
			});
		},

		getToHideColumnList: function() {
			
			var SETTINGS_URL = PluginHelper.getPluginRestUrl('bulkApprovals/getToHideColumnList');

			return $http.get(SETTINGS_URL, config).then(function(response) {
				return response.data;
			});
		},
		
		getToShowColumnList: function() {
			
			var SETTINGS_URL = PluginHelper.getPluginRestUrl('bulkApprovals/getToShowColumnList');

			return $http.get(SETTINGS_URL, config).then(function(response) {
				return response.data;
			});
		},
		
		getAllWorkItemsPayload: function() {
			
			var WORK_ITEMS_URL = PluginHelper.getPluginRestUrl('bulkApprovals/allWIPayloadForCurrentUser');

			return $http.get(WORK_ITEMS_URL, config).then(function(response) {
 
				return response.data;
			});
		},
        getContextPath: function() {
            var GET_CONTEXT_PATH_URL = PluginHelper.getPluginRestUrl('bulkApprovals/getContextPath');
            return $http.get(GET_CONTEXT_PATH_URL, config).then(function(response) {
                return response.data;
            });
        }
		
		

	};

});