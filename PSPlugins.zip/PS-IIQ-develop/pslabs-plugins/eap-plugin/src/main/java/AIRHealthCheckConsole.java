
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.HashMap;

import org.apache.commons.cli.Option;
import org.apache.commons.cli.Options;
import org.apache.commons.lang.StringUtils;

import com.sailpoint.pse.plugin.air.console.AIRBaseContextConsole;

import sailpoint.api.SailPointContext;
import sailpoint.object.Rule;
import sailpoint.object.TaskResult;
import sailpoint.tools.xml.XMLReferenceResolver;

public class AIRHealthCheckConsole extends AIRBaseContextConsole {

    public static final String HEALTH_CHECK_RULE = "Sailpoint Health Check Information Rule";

    @Override
    public String getCommandName() {

        return "AirHealthCheck";
    }

    @Override
    protected Options getOptions() {

        Options options = new Options();

        Option basePath = new Option("o", "outputPath", true, "Path for health check output file");
        basePath.setRequired(true);
        options.addOption(basePath);

        return options;
    }

    @Override
    public void execute() throws Exception {

        TaskResult taskResult = new TaskResult();

        HashMap<String, Object> args = new HashMap<String, Object>();
        args.put("taskResult", taskResult);
        args.put("config", new HashMap());

        SailPointContext context = getContext();
        Rule rule = context.getObjectByName(Rule.class, HEALTH_CHECK_RULE);
        Rule ruleCopy = (Rule) rule.deepCopy((XMLReferenceResolver) context);

        context.decache(rule);

        String source = ruleCopy.getSource();

        // functions that crashes running on console mode
        source = StringUtils.replace(source, "import sailpoint.environmentMonitoring.MonitoringUtil;", "");
        source = StringUtils.replace(source, "MonitoringUtil.getQuartzThreads()", "\"not supported in console mode\"");
        source = StringUtils.replace(source, "MonitoringUtil.getRequestProcessorThreads()", "\"not supported in console mode\"");
        ruleCopy.setSource(source);

        String returnedObj = (String) context.runRule(ruleCopy, args);

        this.logDebugMessage("returnedObj:");
        this.logDebugMessage("" + returnedObj);

        String outputPath = (String) getArgumentValue("outputPath");
        Files.write(Paths.get(outputPath), returnedObj.getBytes());

        this.logMessage("=============================================");
        this.logMessage("AIR Health Check has finished processing");
        this.logMessage("Report has been generated at location: " + outputPath);

    }

    public static void main(String[] args) throws Exception {

        AIRHealthCheckConsole console = null;

        try {
            console = new AIRHealthCheckConsole();
            console.setCommandLineArgs(args);
            console.process();
        } catch (Exception e) {
            console.logMessage("An exception has occurred:" + e.getMessage());
        } finally {
            console.destroyConsole();
        }

        System.exit(1);
    }
}
