
import java.util.Date;
import java.util.Map;

import org.apache.commons.cli.Option;
import org.apache.commons.cli.Options;

import com.sailpoint.pse.plugin.air.console.AIRBaseContextConsole;
import com.sailpoint.pse.plugin.eap.constants.PluginName;
import com.sailpoint.pse.plugin.objectexporter.util.ObjectExporterUtil;

import sailpoint.object.Attributes;
import sailpoint.object.TaskResult;
import sailpoint.object.TaskSchedule;

public class AIRObjectExporterConsole extends AIRBaseContextConsole {

    @Override
    public String getCommandName() {

        return "AirObjectExporter";
    }

    @Override
    public void execute() throws Exception {

        TaskResult taskResult = new TaskResult();
        TaskSchedule taskSchedule = null;
        Attributes<String, Object> taskArguments = new Attributes<String, Object>();

        Map<String, Object> argumentMap = getArguments();

        if (argumentMap != null) {
            taskArguments.putAll(argumentMap);
        }

        ObjectExporterUtil exportXml = new ObjectExporterUtil();
        exportXml.execute(getContext(), taskSchedule, taskResult, taskArguments, PluginName.PLUGIN_NAME);

        if (taskResult != null) {
            String exportDetails = (String) taskResult.getAttribute("exportDetails");
            Integer objectsExported = (Integer) taskResult.getAttribute("objectsExported");

            logMessage("Export Details:");
            logMessage(exportDetails);
            logMessage("Objects Exported:");
            logMessage("" + objectsExported);
        }

        String basePath = (String) getArgumentValue(ObjectExporterUtil.ARG_BASE_PATH);
        this.logMessage("=============================================");
        this.logMessage("AIR Object Exporter has finished processing");
        this.logMessage("Exports have been generated at location: " + basePath);
    }

    @Override
    protected Options getOptions() {

        Options options = new Options();

        Option basePath = new Option("b", ObjectExporterUtil.ARG_BASE_PATH, true, "Base path for export");
        basePath.setRequired(true);
        options.addOption(basePath);

        Option removeIDs = new Option("r", ObjectExporterUtil.ARG_REMOVE_IDS, true, "Remove IDs from exported XML");
        removeIDs.setType(Boolean.class);
        options.addOption(removeIDs);

        Option classNames = new Option("c", ObjectExporterUtil.ARG_CLASS_NAMES, true, "Classes to export (leave blank for all, use 'default' for a default set of classes)");
        options.addOption(classNames);

        Option fromDate = new Option("f", ObjectExporterUtil.ARG_FROM_DATE, true, "Only include objects updated or created after this date");
        fromDate.setType(Date.class);
        options.addOption(fromDate);

        Option targetPropsFile = new Option("t", ObjectExporterUtil.ARG_TARGET_PROPS_FILE, true, "target.properties file for reverse-tokenization for SSB");
        options.addOption(targetPropsFile);

        Option namingFormat = new Option("n", ObjectExporterUtil.ARG_CUSTOM_NAMING_FORMAT, true, "Naming format (see help text for variables)");
        options.addOption(namingFormat);

        Option mergeCompareDirPath = new Option("m", ObjectExporterUtil.ARG_MERGE_COMPARE_DIR_PATH, true, "Directory containing original XML files for comparison when creating merge files");
        options.addOption(mergeCompareDirPath);

        Option addCData = new Option("cdata", ObjectExporterUtil.ARG_ADD_CDATA, true, "Add CDATA sections");
        addCData.setType(Boolean.class);
        options.addOption(addCData);

        Option regexFilter = new Option("regex", ObjectExporterUtil.ARG_REGEX_FILTER, true, "Only include objects with names matching this regular expression");
        options.addOption(regexFilter);

        Option stripMetadata = new Option("s", ObjectExporterUtil.ARG_STRIP_METADATA, true, "Strip environment-specific metadata");
        stripMetadata.setType(Boolean.class);
        options.addOption(stripMetadata);

        Option noIdNameMap = new Option("noIdNameMap", ObjectExporterUtil.NO_ID_NAME_MAP, true, "Do not use id name mapping");
        noIdNameMap.setType(Boolean.class);
        options.addOption(noIdNameMap);

        return options;
    }

    public static void main(String[] args) throws Exception {

        AIRObjectExporterConsole console = null;

        try {
            console = new AIRObjectExporterConsole();
            console.setCommandLineArgs(args);
            console.process();
        } catch (Exception e) {
            console.logMessage("An exception has occurred:" + e.getMessage());
        } finally {
            console.destroyConsole();
        }

        System.exit(1);
    }
}
