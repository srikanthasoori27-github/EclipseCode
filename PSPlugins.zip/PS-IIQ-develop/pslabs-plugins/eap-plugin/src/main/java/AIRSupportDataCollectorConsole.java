
import java.util.Map;

import org.apache.commons.cli.Option;
import org.apache.commons.cli.Options;

import com.sailpoint.pse.plugin.air.console.AIRBaseContextConsole;
import com.sailpoint.pse.plugin.eap.service.AIRSupportDataCollectorService;

import sailpoint.api.SailPointContext;
import sailpoint.object.Attributes;
import sailpoint.support.plugin.util.SupportPluginUtil;

public class AIRSupportDataCollectorConsole extends AIRBaseContextConsole {

    @Override
    public String getCommandName() {

        return "AIRSupportDataCollector";
    }

    @Override
    public void execute() throws Exception {

        SailPointContext context = getContext();

        // These attachments come from a default collect data from a select all,
        // and was collected from the custom object result
        Attributes<String, Object> args = new Attributes<String, Object>();
        args.put(SupportPluginUtil.ARG_DO_DB_PERFORMANCE, false);
        args.put(SupportPluginUtil.ARG_DO_SYSTEM_PROPERTIES, false);
        args.put(SupportPluginUtil.ARG_DO_THREAD_DUMPS, false);

        String zipOutputPath = (String) getArgumentValue("outputPath");

        AIRSupportDataCollectorService service = new AIRSupportDataCollectorService(context, zipOutputPath);
        service.setAttributes(args);
        Map<String, Object> resultMap = service.execute();

        this.logMessage("=============================================");
        this.logMessage("AIR Support Data Collector Plugin has finished processing");
        this.logMessage("Exports have been generated at location: " + resultMap.get("outputPath"));
    }

    @Override
    protected Options getOptions() {

        Options options = new Options();

        Option basePath = new Option("o", "outputPath", true, "Path for support data collector output ZIP file");
        basePath.setRequired(true);
        options.addOption(basePath);

        return options;
    }

    public static void main(String[] args) throws Exception {

        AIRSupportDataCollectorConsole console = null;

        try {
            console = new AIRSupportDataCollectorConsole();
            console.setCommandLineArgs(args);
            console.process();
        } catch (Exception e) {
            console.logMessage("An exception has occurred:" + e.getMessage());
        } finally {
            console.destroyConsole();
        }

        System.exit(1);
    }
}
