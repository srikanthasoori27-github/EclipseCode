//<script src="ui/js/jquery.min.js"></script>

/*

Other available values to build paths, etc. that are obtained from the server and set in the PluginFramework JS object

PluginFramework.PluginBaseEndpointName = '#{pluginFramework.basePluginEndpointName}';
PluginFramework.PluginEndpointRoot = '#{pluginFramework.basePluginEndpointName}/#{pluginFramework.basePluginEndpointName}';
PluginFramework.PluginFolderName = '#{pluginFramework.pluginFolderName}';
PluginFramework.CurrentPluginUniqueName = '#{pluginFramework.uniqueName}';
PluginFramework.CsrfToken = Ext.util.Cookies.get('CSRF-TOKEN');

 */


var jQueryClone = jQuery;
var statusClass = '';
var CsrfToken = Ext.util.Cookies.get('CSRF-TOKEN');

function refreshMenuSessionData() {
	var params = "";
  jQueryClone.ajax({
        method: "GET",
        beforeSend: function (request) {
            request.setRequestHeader("X-XSRF-TOKEN", CsrfToken);
        },
        url: SailPoint.CONTEXT_PATH + "/plugin/rest/menurefreshplugin/refreshMenu"
  })
  .done(function (msg) {
    	if (msg === "OK") {
					location.reload();
					return;
			} else {
	    		alert("Error refreshing menu session data");
			}
		});
}

jQuery(document).ready(function(){

	var menuItem = '<li role="presentation">' +
    '  <a href="#" role="menuitem" tabindex="0" onclick="refreshMenuSessionData(); return true;">' +
    '    <i role="presentation" aria-hidden="true" class="fa fas fa-bars m-r-xs"></i>' +
		' Refresh QuickLinks ' +
		'  </a>' +
		'</li>' +
	  '<li role="presentation" aria-hidden="true" class="divider"></li>';

	jQuery("ul.navbar-right li.dropdown:last-child > ul > li:last-child").before(menuItem);
});
