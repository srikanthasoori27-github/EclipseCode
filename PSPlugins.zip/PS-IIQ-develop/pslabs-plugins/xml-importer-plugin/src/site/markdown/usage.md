### Features
The XML Importer plugin installs a workflow that can be invoked to import XML configuration objects into the IdentityIQ environment that it is running on.

The workflow will import files that are referenced by a file named `sp.init-custom.xml` present under the `WEB-INF/config` directory of the server instance that executes the workflow. A snippet of how the `sp.init-custom.xml` file looks like is as below. In the below example, the workflow will effectively import the `custom/Application/Application_EnterpriseAD.xml` that is present under the `WEB-INF/config` directory of the server instance that executes the workflow.

```xml
<?xml version='1.0' encoding='UTF-8'?>
<!DOCTYPE sailpoint PUBLIC 'sailpoint.dtd' 'sailpoint.dtd'>
<sailpoint>
  <ImportAction name='include' value='custom/Application/Application_EnterpriseAD.xml'/>
</sailpoint>
```

The preferred method of invoking the workflow is through the [SCIM API](https://developer.sailpoint.com/SCIM/index.html#launch-a-workflow). The API endpoint is `scim/v2/LaunchedWorkflows`. The endpoint must be invoked using the HTTP POST method and the below payload is to be passed. The client may use either HTTP Basic or OAuth to [authenticate](https://developer.sailpoint.com/SCIM/index.html#authentication) to the workflow. It is strongly recommended that this invocation occur over an encrypted channel.

```json
{
    "schemas": [
        "urn:ietf:params:scim:schemas:sailpoint:1.0:LaunchedWorkflow",
        "urn:ietf:params:scim:schemas:sailpoint:1.0:TaskResult"
    ],
    "urn:ietf:params:scim:schemas:sailpoint:1.0:LaunchedWorkflow": {
        "workflowName": "XML Importer",
        "input": [
            {
                "key": "flow",
                "value": "Import XML"
            }
        ]
    }
}
```

An example invocation via Postman with request/response is shown below.

![directory_layout](images/xml-importer-sample.png)