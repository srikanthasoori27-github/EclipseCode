(function () {
    'use strict';

    var app = angular.module('velocityTemplateApp', ['ngRoute', 'ui.bootstrap', 'textAngular', 'mgcrea.ngStrap']);
    //this is the route provider. Here, we register our anchor links and bind them to 
    //an angular controller and a html page to use as a template
    app.config(function ($routeProvider) {
        $routeProvider
            .when('/', {
                templateUrl: PluginHelper.getPluginFileUrl('velocity_template_plugin', 'ui/partials/home.html'),
                controller: 'HomeController'
            })

            .when('/home', {
                templateUrl: PluginHelper.getPluginFileUrl('velocity_template_plugin', 'ui/partials/home.html'),
                controller: 'HomeController'
            })

            .when('/evaluateTemplate', {
                templateUrl: PluginHelper.getPluginFileUrl('velocity_template_plugin', 'ui/partials/evaluateTemplate.html'),
                controller: 'TemplateController'
            })

            .when('/createTemplate', {
                templateUrl: PluginHelper.getPluginFileUrl('velocity_template_plugin', 'ui/partials/createTemplate.html'),
                controller: 'TemplateController'
            })

            .when('/modifyTemplate', {
                templateUrl: PluginHelper.getPluginFileUrl('velocity_template_plugin', 'ui/partials/modifyTemplate.html'),
                controller: 'TemplateController'
            })

            .otherwise({redirectTo: '/'});
    });

    app.config(['$provide', function ($provide) {
        // this demonstrates how to register a new tool and add it to the default toolbar
        $provide.decorator('taOptions', ['$delegate', function (taOptions) {
            // $delegate is the taOptions we are decorating
            // here we override the default toolbars and classes specified in taOptions.
            taOptions.forceTextAngularSanitize = true; // set false to allow the textAngular-sanitize provider to be replaced
            taOptions.keyMappings = []; // allow customizable keyMappings for specialized key boards or languages
            taOptions.toolbar = [
                ['h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'p', 'pre'],
                ['bold', 'italics', 'underline', 'ul', 'ol', 'redo', 'undo', 'clear'],
                ['justifyLeft', 'justifyCenter', 'justifyRight', 'justifyFull'],
                ['html', 'insertImage', 'insertLink']
            ];
            taOptions.classes = {
                focussed: 'focussed',
                toolbar: 'btn-toolbar',
                toolbarGroup: 'btn-group',
                toolbarButton: 'btn btn-default',
                toolbarButtonActive: 'active',
                disabled: 'disabled',
                textEditor: 'form-control',
                htmlEditor: 'form-control'
            };
            return taOptions; // whatever you return will be the taOptions
        }]);
    }]);

    //this fixes the escaped slashes
    app.config(['$locationProvider', function ($locationProvider) {
        $locationProvider.hashPrefix('');
    }]);
}());
