jQuery(document).ready(function () {
    //adds a nice icon to the top navigation bar
    var velocityTemplatePluginPageUrl = SailPoint.CONTEXT_PATH + '/plugins/pluginPage.jsf?pn=velocity_template_plugin';
    jQuery("ul.navbar-right li:first")
        .before(
            '<li class="dropdown">' +
            '        <a href="' + velocityTemplatePluginPageUrl + '" tabindex="0" role="menuitem" title="Email Template Editor Plugin">' +
            '            <i role="presenation" class="fa fa-pencil-square fa-lg example"></i>' +
            '        </a>' +
            '</li>'
        );
});
