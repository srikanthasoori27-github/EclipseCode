(function () {
    'use strict';

    var app = angular.module('velocityTemplateApp');
    app.directive('vtpMessages', function () {
        return {
            controller: 'TemplateController',
            controllerAs: 'controller',
            bindToController: true,
            templateUrl: PluginHelper.getPluginFileUrl('velocity_template_plugin', 'ui/directiveTemplates/messageDirectiveTemplate.html')
        };
    });

    app.directive('vtpArgumentTable', function () {
        return {
            controller: 'TemplateController',
            controllerAs: 'controller',
            bindToController: true,
            templateUrl: PluginHelper.getPluginFileUrl('velocity_template_plugin', 'ui/directiveTemplates/argumentsTableDirectiveTemplate.html')
        };
    });

    app.directive('vtpAddArgument', function () {
        return {
            controller: 'TemplateController',
            controllerAs: 'controller',
            bindToController: true,
            templateUrl: PluginHelper.getPluginFileUrl('velocity_template_plugin', 'ui/directiveTemplates/addArgumentDirectiveTemplate.html')
        };
    });

    app.directive('vtpTemplateEditor', function () {
        return {
            controller: 'TemplateController',
            controllerAs: 'controller',
            bindToController: true,
            templateUrl: PluginHelper.getPluginFileUrl('velocity_template_plugin', 'ui/directiveTemplates/editorDirectiveTemplate.html')
        };
    });

    app.directive('vtpSaveTemplate', function () {
        return {
            controller: 'TemplateController',
            controllerAs: 'controller',
            bindToController: true,
            templateUrl: PluginHelper.getPluginFileUrl('velocity_template_plugin', 'ui/directiveTemplates/saveTemplateDirectiveTemplate.html')
        };
    });

    app.directive('vtpUpdateTemplate', function () {
        return {
            controller: 'TemplateController',
            controllerAs: 'controller',
            bindToController: true,
            templateUrl: PluginHelper.getPluginFileUrl('velocity_template_plugin', 'ui/directiveTemplates/updateTemplateDirectiveTemplate.html')
        };
    });

    app.directive('vtpPreviewTemplate', function () {
        return {
            controller: 'TemplateController',
            controllerAs: 'controller',
            bindToController: true,
            templateUrl: PluginHelper.getPluginFileUrl('velocity_template_plugin', 'ui/directiveTemplates/previewTemplateDirectiveTemplate.html')
        };
    });

    app.directive('vtpTemplateSelector', function () {
        return {
            controller: 'TemplateController',
            controllerAs: 'controller',
            bindToController: true,
            templateUrl: PluginHelper.getPluginFileUrl('velocity_template_plugin', 'ui/directiveTemplates/templateSelectorDirectiveTemplate.html')
        };
    });

}());
