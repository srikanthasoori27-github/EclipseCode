(function () {
    'use strict';

    var app = angular.module('velocityTemplateApp');

    app.service('TemplateService', function ($http, $q) {
        /*
         * return all template names found in the system
         */
        this.getTemplateNames = function () {
            var deferred = $q.defer();
            return $http({
                method: "GET",
                withCredentials: true,
                xsrfHeaderName: "X-XSRF-TOKEN",
                xsrfCookieName: "CSRF-TOKEN",
                url: PluginHelper.getPluginRestUrl('velocity-template') + '/getTemplateNames'
            }).then(function mySuccess(response) {
                deferred.resolve(response.data);
                return deferred.promise;
            }, function myError(response) {
                // the following line rejects the promise 
                deferred.reject(response);
                // promise is returned
                return deferred.promise;
            });
        };

        /*
         * get the input parameters of a template
         */
        this.getTemplateParameters = function (templateName) {
            var deferred = $q.defer();
            return $http({
                method: "GET",
                withCredentials: true,
                xsrfHeaderName: "X-XSRF-TOKEN",
                xsrfCookieName: "CSRF-TOKEN",
                url: PluginHelper.getPluginRestUrl('velocity-template') + '/getTemplateParameters/' + templateName
            }).then(function mySuccess(response) {
                deferred.resolve(response.data);
                return deferred.promise;
            }, function myError(response) {
                deferred.reject(response);
                return deferred.promise;
            });
        };

        /*
         * get the content of a template (subject and body)
         */
        this.getTemplateContent = function (templateName) {
            var deferred = $q.defer();
            return $http({
                method: "GET",
                withCredentials: true,
                xsrfHeaderName: "X-XSRF-TOKEN",
                xsrfCookieName: "CSRF-TOKEN",
                url: PluginHelper.getPluginRestUrl('velocity-template') + '/getTemplate/' + templateName
            }).then(function mySuccess(response) {
                deferred.resolve(response.data);
                return deferred.promise;
            }, function myError(response) {
                deferred.reject(response);
                return deferred.promise;
            });
        };

        /*
         * evaluate a template with an argument array
         */
        this.evaluateTemplate = function (templateName, argumentArray) {
            var deferred = $q.defer();
            return $http({
                method: "POST",
                withCredentials: true,
                xsrfHeaderName: "X-XSRF-TOKEN",
                xsrfCookieName: "CSRF-TOKEN",
                url: PluginHelper.getPluginRestUrl('velocity-template') + '/evaluateTemplate',
                headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                transformRequest: function (obj) {
                    var str = [];
                    for (var p in obj) {
                        str.push(encodeURIComponent(p) + "=" + encodeURIComponent(obj[p]));
                    }
                    return str.join("&");
                },
                data: {
                    templateName: templateName,
                    arguments: angular.toJson(argumentArray)
                }
            }).then(function mySuccess(response) {
                deferred.resolve(response.data);
                return deferred.promise;
            }, function myError(response) {
                deferred.reject(response);
                return deferred.promise;
            });
        };

        /*
         * evaluates a new email template
         */
        this.evaluateNewTemplate = function (subjectTemplate, bodyTemplate, argumentArray) {
            var deferred = $q.defer();
            return $http({
                method: "POST",
                withCredentials: true,
                xsrfHeaderName: "X-XSRF-TOKEN",
                xsrfCookieName: "CSRF-TOKEN",
                url: PluginHelper.getPluginRestUrl('velocity-template') + '/evaluateSource',
                headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                transformRequest: function (obj) {
                    var str = [];
                    for (var p in obj) {
                        str.push(encodeURIComponent(p) + "=" + encodeURIComponent(obj[p]));
                    }
                    return str.join("&");
                },
                data: {
                    subjectTemplate: subjectTemplate,
                    bodyTemplate: bodyTemplate,
                    arguments: angular.toJson(argumentArray)
                }
            }).then(function mySuccess(response) {
                deferred.resolve(response.data);
                return deferred.promise;
            }, function myError(response) {
                deferred.reject(response);
                return deferred.promise;
            });
        };

        /*
         * saves a template to the database
         */
        this.saveTemplate = function (templateName, subjectTemplate, bodyTemplate, argumentArray, html) {
            var deferred = $q.defer();
            return $http({
                method: "POST",
                withCredentials: true,
                xsrfHeaderName: "X-XSRF-TOKEN",
                xsrfCookieName: "CSRF-TOKEN",
                url: PluginHelper.getPluginRestUrl('velocity-template') + '/saveTemplate',
                headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                transformRequest: function (obj) {
                    var str = [];
                    for (var p in obj)
                        str.push(encodeURIComponent(p) + "=" + encodeURIComponent(obj[p]));
                    return str.join("&");
                },
                data: {
                    templateName: templateName,
                    subjectTemplate: subjectTemplate,
                    bodyTemplate: bodyTemplate,
                    arguments: angular.toJson(argumentArray),
                    html: html
                }
            }).then(function mySuccess(response) {
                deferred.resolve(response.data);
                return deferred.promise;
            }, function myError(response) {
                deferred.reject(response);
                return deferred.promise;
            });
        };

        /*
         * updates an existing template
         */
        this.updateTemplate = function (templateName, subjectTemplate, bodyTemplate, argumentArray, html) {
            var deferred = $q.defer();
            return $http({
                method: "POST",
                withCredentials: true,
                xsrfHeaderName: "X-XSRF-TOKEN",
                xsrfCookieName: "CSRF-TOKEN",
                url: PluginHelper.getPluginRestUrl('velocity-template') + '/updateTemplate',
                headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                transformRequest: function (obj) {
                    var str = [];
                    for (var p in obj)
                        str.push(encodeURIComponent(p) + "=" + encodeURIComponent(obj[p]));
                    return str.join("&");
                },
                data: {
                    templateName: templateName,
                    subjectTemplate: subjectTemplate,
                    bodyTemplate: bodyTemplate,
                    arguments: angular.toJson(argumentArray),
                    html: html
                }
            }).then(function mySuccess(response) {
                deferred.resolve(response.data);
                return deferred.promise;
            }, function myError(response) {
                deferred.reject(response);
                return deferred.promise;
            });
        };

        /*
         * shows a modal with the compiled email template
         */
        this.showCompiledTemplate = function (templateName, compiledSubject, compiledTemplate, showHtml, $scope, $uibModal) {
            var modalScope = $scope.$new();
            var modalInstance = $uibModal.open({
                templateUrl: PluginHelper.getPluginFileUrl('velocity_template_plugin', 'ui/modal/templatePreview.html'),
                controller: 'ModalViewController',
                windowClass: 'app-modal-window',
                scope: modalScope
            });
            if (typeof showHtml === 'undefined' || showHtml === null) {
                showHtml = false;
            }
            modalScope.templateName = templateName;
            modalScope.compiledSubject = compiledSubject;
            modalScope.compiledTemplate = compiledTemplate;
            modalScope.modalInstance = modalInstance;
            modalScope.showHTML = showHtml;
        };
    });
}());
