jQuery(document).ready(function () {
    //this prevents the form from being submitted accidentally
    document.addEventListener('keydown', function (event) {
        var esc = event.which == 27,
            nl = event.which == 13,
            el = event.target,
            input = el.nodeName != 'INPUT' && el.nodeName != 'TEXTAREA' && el.nodeName != 'DIV',
            data = {};

        if (input) {
            if (esc) {
                // restore state
                document.execCommand('undo');
                el.blur();
            } else if (nl) {
                el.blur();
                event.preventDefault();
            }
        }
    }, true);
});