(function () {
    'use strict';

    var app = angular.module('velocityTemplateApp');

    /** HOME Controller **/
    app.controller('HomeController', function ($scope) {
        $scope.currentUser = PluginHelper.getCurrentUserDisplayableName();
    });

    /** ModalViewController **/
    app.controller('ModalViewController', function ($scope, $sce) {
        var controller = this;
        controller.showHTML = $scope.showHTML;
        if (controller.showHTML) {
            controller.togglePreviewButtonMessage = "Switch to Text view";
        } else {
            controller.togglePreviewButtonMessage = "Switch to HTML view";
        }

        //controller.compiledTemplateHtml = $sce.trustAsHtml($scope.compiledTemplate);
        controller.compiledTemplateHtml = $scope.compiledTemplate;
        controller.compiledTemplateText = $scope.compiledTemplate;
        controller.templateName = $scope.templateName;
        controller.compiledSubject = $scope.compiledSubject;

        controller.close = function () {
            $scope.modalInstance.close('close');
        };

        controller.cancel = function () {
            $scope.modalInstance.dismiss('cancel');
        };

        controller.toggleHtml = function () {
            controller.showHTML = !controller.showHTML;
            if (controller.showHTML) {
                controller.togglePreviewButtonMessage = "Switch to Text view";
            } else {
                controller.togglePreviewButtonMessage = "Switch to HTML view";
            }
        }
    });

    app.controller('TemplateController', ['$scope', '$http', '$uibModal', '$timeout', 'textAngularManager', 'TemplateService', function ($scope, $http, $uibModal, $timeout, textAngularManager, TemplateService) {
        var controller = this;
        //ALL the types of arguments one can set
        controller.argumentTypes = ['string',
            'AccountGroup', 'ActivityDataSource', 'Alert', 'AlertDefinition', 'Application',
            'ApplicationActivity', 'ApplicationScorecard', 'AuditConfig', 'AuditEvent',
            'AuthenticationQuestion', 'BatchRequest', 'Bundle', 'BundleArchive', 'Category',
            'Capability', 'Certification', 'CertificationArchive', 'CertificationDefinition',
            'CertificationGroup', 'Configuration', 'CorrelationConfig', 'Custom', 'DashboardContent',
            'DashboardLayout', 'DatabaseVersion', 'Dictionary', 'DynamicScope', 'EmailTemplate',
            'Form', 'FullTextIndex', 'GroupFactory', 'GroupDefinition', 'GroupIndex', 'Identity',
            'IdentityArchive', 'IdentityEntitlement', 'IdentityHistoryItem', 'IdentityRequest',
            'IdentitySnapshot', 'IdentityTrigger', 'IdentityDashboard', 'IntegrationConfig',
            'JasperResult', 'JasperTemplate', 'LocalizedAttribute', 'ManagedAttribute',
            'MessageTemplate', 'MiningConfig', 'MitigationExpiration', 'ObjectConfig',
            'PasswordPolicy', 'Plugin', 'Policy', 'PolicyViolation', 'ProcessLog', 'Profile',
            'ProvisioningRequest', 'ProvisioningTransaction', 'QuickLink', 'Request',
            'RequestDefinition', 'ResourceEvent', 'RightConfig', 'RoleChangeEvent', 'RoleIndex',
            'RoleMetadata', 'RoleMiningResult', 'RoleScorecard', 'Rule', 'RuleRegistry', 'Scope',
            'Scorecard', 'ScoreConfig', 'SPRight', 'ServiceDefinition', 'ServiceStatus', 'Server',
            'SyslogEvent', 'Target', 'TargetAssociation', 'TargetSource', 'TaskDefinition',
            'TaskResult', 'TaskSchedule', 'TimePeriod', 'UIConfig', 'UIPreferences', 'Widget',
            'Workflow', 'WorkflowCase', 'WorkflowRegistry', 'WorkflowTestSuite', 'Workgroup',
            'WorkItem', 'WorkItemArchive'
        ];

        //toggle HTML editor
        controller.editorButtonMessage = "Switch to Text Mode";
        controller.textModeHint = "If you need to edit a text template, please switch the editor to Text Mode.";
        controller.showHTMLEditor = true;

        controller.switchEditor = function () {
            controller.showHTMLEditor = !controller.showHTMLEditor;
            if (controller.showHTMLEditor) {
                controller.editorButtonMessage = "Switch to Text Mode";
                controller.textModeHint = "If you need to edit a text template, please switch the editor to Text Mode.";
            } else {
                controller.editorButtonMessage = "Switch to HTML Mode";
                controller.textModeHint = "If you need to edit a html template, please switch the editor to HTML Mode.";
            }
        };

        controller.getArgToolContentValue = function (argName, argType) {
            var returnValue = null;
            switch (argType.toLowerCase()) {
                case "string"   :
                    returnValue = "${" + argName + "}";
                    break;
                case "identity" :
                    returnValue = "${" + argName + ".getDisplayName()}";
                    break;
                default :
                    returnValue = "${" + argName + ".getName()}";
                    break;
            }

            return returnValue;
        };

        controller.buildArgToolContent = function () {
            var contentArray = [];
            for (var i = 0; i < controller.arguments.length; i++) {
                var argName = controller.arguments[i].name;
                var argType = controller.arguments[i].type;
                var argValue = controller.arguments[i].value;

                var content = {
                    text: argName,
                    value: controller.getArgToolContentValue(argName, argType),
                    click: 'action(item)'
                };
                contentArray.push(content);
            }

            return contentArray;
        };

        // add tool option to wysiwyg editor
        controller.updateArgTool = function () {
            var toolDefinition = {
                display: '<button class="btn" type="button" data-animation="am-fade" bs-dropdown="content" aria-haspopup="true" aria-expanded="false">insert parameter</button>',
                content: controller.buildArgToolContent(),
                action: function (item) {
                    if (item.text) {
                        this.$editor().wrapSelection('insertHtml', item.value);
                    }
                }
            };
            var toolKey = "parameterscombo";
            // dunno why, but need to remove 2x
            textAngularManager.removeTool(toolKey);
            textAngularManager.removeTool(toolKey);
            textAngularManager.addTool(toolKey, toolDefinition);


        };

        //argument handling
        controller.arguments = [];
        controller.errorMessages = [];
        controller.successMessages = [];

        //clear arguments
        controller.clearArguments = function () {
            controller.arguments = [];
            controller.successMessages.push({message: "Parameters were cleared"});
            controller.updateArgTool();
            $timeout(function () {
                controller.successMessages.shift();
            }, 5000);
        };

        //adds an attribute to the array
        controller.addArgument = function () {
            if (controller.arguments == null) {
                controller.arguments = [];
            }
            controller.arguments.push({
                name: controller.argumentName,
                value: controller.argumentValue,
                type: controller.argumentType
            });
            controller.updateArgTool();
            controller.argumentName = null;
            controller.argumentType = null;
            controller.argumentValue = null;
        };

        //removes an attribute from the array
        controller.removeArgument = function (index) {
            controller.arguments.splice(index, 1);
            controller.updateArgTool();
            controller.successMessages.push({message: "Parameter has been removed"});
            $timeout(function () {
                controller.successMessages.shift();
            }, 5000);
        };

        //update all arguments on the page
        controller.updateAllArguments = function () {
            for (var i = 0; i < controller.arguments.length; i++) {
                controller.updateArgumentValue(i, false);
            }
            controller.updateArgTool();
            controller.successMessages.push({message: "All parameters have been updated"});
            $timeout(function () {
                controller.successMessages.shift();
            }, 5000);
        };

        //updates the value found on the supplied index
        controller.updateArgumentValue = function (index, showMessage) {
            //type span
            var typespan = $('span[id^="mappingtype-' + index + '"]');
            var typespanvalue = typespan[0].innerHTML;
            //name span
            var namespan = $('span[id^="mappingname-' + index + '"]');
            var namespanvalue = namespan[0].innerHTML;
            //value span
            var valuespan = $('span[id^="mappingvalue-' + index + '"]');
            var valuespanvalue = valuespan[0].innerHTML;

            controller.arguments[index].type = typespanvalue;
            controller.arguments[index].name = namespanvalue;
            controller.arguments[index].value = valuespanvalue;

            controller.updateArgTool();
            if (showMessage) {
                controller.successMessages.push({message: "Parameter " + namespanvalue + " of type " + typespanvalue + " set to value " + valuespanvalue});
                $timeout(function () {
                    controller.successMessages.shift();
                }, 5000);
            }
        };

        //template name handling
        controller.templateName = null;
        controller.templateNames = [];

        //get ALL the template names from the database
        controller.reloadTemplateNames = function () {
            TemplateService.getTemplateNames().then(function (result) {
                controller.templateNames = result;
            });
        };


        //use selected template, set content to editor
        controller.useSelectedTemplate = function () {
            if (controller.templateName != null) {
                controller.getTemplateContent();
            }
        };

        //content handling
        controller.subjectTemplate = null;
        controller.bodyTemplate = null;
        controller.compiledTemplate = null;

        //compile editor content and arguments, show in modal
        controller.evaluateNewTemplate = function () {
            if (controller.arguments == null) {
                controller.arguments = [];
            }
            TemplateService.evaluateNewTemplate(controller.subjectTemplate, controller.bodyTemplate, controller.arguments).then(function (result) {
                controller.compiledTemplate = result.body;
                controller.compiledSubject = result.subject;
                controller.showCompiledTemplate();
            }, function (error) {
                controller.errorMessages.push({message: "There was an error compiling the template: " + error.data.message});
                $timeout(function () {
                    controller.errorMessages.shift();
                }, 5000);
            });
        };

        //updates editor fields with the content of the selected template
        controller.getTemplateContent = function () {
            TemplateService.getTemplateContent(controller.templateName).then(function (result) {
                controller.subjectTemplate = result.subjectTemplate;
                controller.bodyTemplate = result.bodyTemplate;
                controller.arguments = result.arguments;
                controller.updateArgTool();
            }, function (error) {
                controller.errorMessages.push({message: "There was an error retrieving the template content: " + error.data.message});
                $timeout(function () {
                    controller.errorMessages.shift();
                }, 5000);
            });
        };

        //compile selected template and arguments, show in modal
        controller.evaluateTemplate = function () {
            if (controller.arguments == null) {
                controller.arguments = [];
            }
            TemplateService.evaluateTemplate(controller.templateName, controller.arguments).then(function (result) {
                controller.compiledTemplate = result.body;
                controller.compiledSubject = result.subject;
                controller.showCompiledTemplate();
            }, function (error) {
                controller.errorMessages.push({message: "There was an error compiling the template: " + error.data.message});
                $timeout(function () {
                    controller.errorMessages.shift();
                }, 5000);
            });
        };

        //saves the template to the database
        controller.saveTemplate = function () {
            if (controller.arguments == null) {
                controller.arguments = [];
            }
            TemplateService.saveTemplate(controller.templateName, controller.subjectTemplate, controller.bodyTemplate, controller.arguments, controller.showHTMLEditor).then(function (result) {
                controller.successMessages.push({message: "Template has been successfully saved"});
                $timeout(function () {
                    controller.successMessages.shift();
                }, 5000);
                controller.templateName = null;
                controller.subjectTemplate = null;
                controller.bodyTemplate = null;
                controller.arguments = null;

            }, function (error) {
                controller.errorMessages.push({
                    message: "There was an error saving the template: "
                        + error.data.message + " - probably a template with the same name already exists?"
                });
                $timeout(function () {
                    controller.errorMessages.shift();
                }, 5000);
            });
        };

        //updates an existing template in the database
        controller.updateTemplate = function () {
            if (controller.arguments == null) {
                controller.arguments = [];
            }
            TemplateService.updateTemplate(controller.templateName, controller.subjectTemplate, controller.bodyTemplate, controller.arguments, controller.showHTMLEditor).then(function (result) {
                controller.successMessages.push({message: "Template has been successfully updated"});
                $timeout(function () {
                    controller.successMessages.shift();
                }, 5000);
                controller.templateName = null;
            }, function (error) {
                controller.errorMessages.push({message: "There was an error updating the template: " + error.data.message});
                $timeout(function () {
                    controller.errorMessages.shift();
                }, 5000);
            });
        };

        //shows the compiled template
        controller.showCompiledTemplate = function () {
            TemplateService.showCompiledTemplate(controller.templateName, controller.compiledSubject, controller.compiledTemplate, controller.showHTMLEditor, $scope, $uibModal);
        };

        //gets the parameters of an existing email template
        controller.getTemplateParameters = function () {
            TemplateService.getTemplateParameters(controller.templateName).then(function (result) {
                controller.arguments = result;
                controller.updateArgTool();
                controller.successMessages.push({message: "Template has been successfully updated"});
                $timeout(function () {
                    controller.successMessages.shift();
                }, 5000);
            }, function (error) {
                controller.errorMessages.push({
                    message: "There was an error retrieving the template input parameters: "
                        + error.data.message
                });
                $timeout(function () {
                    controller.errorMessages.shift();
                }, 5000);
            });
        };
    }]);
}());
