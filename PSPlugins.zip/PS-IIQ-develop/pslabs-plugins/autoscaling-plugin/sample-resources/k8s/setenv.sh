NODE=$(hostname)
if [[ $NODE =~ "task" ]]
then
	export JAVA_OPTS="$JAVA_OPTS -Xms4096m -Xmx8192m -Doracle.jdbc.javaNetNio=false"
else
	export JAVA_OPTS="$JAVA_OPTS -Xms256m -Xmx3072m -Doracle.jdbc.javaNetNio=false"
fi
