#!/bin/bash

export IIQ_HOME=/sp01/apache-tomcat/webapps/identityiq
export IIQ_PLUGIN_LOCATION=/sp01/stage/autoscaling-plugin-1.0.1-bin.zip
export IIQ_USER=spadmin
export IIQ_PASSWORD=admin
export IIQ_CONTAINER_HOST_SERVICES=Task,Request
export IIQ_CONTAINER_HOSTNAME_DYNAMIC_TYPE=ts