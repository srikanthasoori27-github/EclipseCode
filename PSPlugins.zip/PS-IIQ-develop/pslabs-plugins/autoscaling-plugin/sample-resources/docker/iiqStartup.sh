#!/bin/bash

function generateHostName(){

  pluginInstalled=$(checkPluginStatus)
  if [[ "${pluginInstalled}" == *"ServerAutoScaling is currently enabled"* ]]; then
    pluginInstalled="true"
  elif [[ "${pluginInstalled}" == *"unable to find plugin with id or name: ServerAutoScaling"* ]]; then
    pluginInstalled=$(installPlugin)
    if [[ "${pluginInstalled}" == *"successfully installed ServerAutoScaling"* ]]; then
      pluginInstalled="true"
    fi
  fi

  iiqHostName=""
  if [[ ( -n "$pluginInstalled" ) && ( "$pluginInstalled" = "true" ) ]]; then
    iiqHostName=$(printf "rule \"ServerAutoscaling Allocate Hostname\"" |  "$IIQ_HOME/WEB-INF/bin/iiq" console -u $IIQ_USER -p $IIQ_PASSWORD | sed -n 's/.*IIQ_HOSTNAME_VAL=\(.*\)/\1/p')
  fi
  echo $iiqHostName
}

function checkPluginStatus(){

  pluginStatus=$(printf "plugin status ServerAutoScaling" |  "$IIQ_HOME/WEB-INF/bin/iiq" console -u $IIQ_USER -p $IIQ_PASSWORD)
  echo $pluginStatus
}

function installPlugin(){

  pluginStatus="No zip file found"
  if [[ -f "$IIQ_PLUGIN_LOCATION" ]]; then
    pluginStatus=$(printf "plugin install $IIQ_PLUGIN_LOCATION" |  "$IIQ_HOME/WEB-INF/bin/iiq" console -u $IIQ_USER -p $IIQ_PASSWORD)
  fi
  echo $pluginStatus
}

# Start mysql
chown -R mysql /var/lib/mysql
mysqld --user mysql &

echo "Running Autoscaling plugin checks"

# source ~/iiqenv.sh

IIQ_CONTAINER_HOSTNAME=$(generateHostName)
echo "$IIQ_CONTAINER_HOSTNAME"
if [[ ( -n "$IIQ_CONTAINER_HOSTNAME" )  && ( "NO_HOSTNAME" != "$IIQ_CONTAINER_HOSTNAME" ) ]]; then
  JAVA_OPTS="$JAVA_OPTS -Diiq.hostname=$IIQ_CONTAINER_HOSTNAME"
  export JAVA_OPTS
fi

# Start Tomcat
cd $CATALINA_HOME/bin
sh startup.sh
echo 'Started Tomcat Server'
tail -f $CATALINA_HOME/logs/catalina.out