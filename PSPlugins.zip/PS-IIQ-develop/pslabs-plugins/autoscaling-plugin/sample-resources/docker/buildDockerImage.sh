#!/bin/sh

# Details to use SSB for build
DO_BUILD=true
CODE_BASE=/Users/saikiran.revuru/workspace/UNM
SPTARGET=srevuru

# Docker image and container names
DOCKER_IMAGE_NAME=sp/unm:v1
DOCKER_CONTAINER_NAME=unm

# Global variable
BUILD_IMAGE=true

# Run the ssb build - generate the war file
WORKINGDIR=`pwd`
echo $WORKINGDIR
if [ "$DO_BUILD" = "true" ] ; then
  # Build the war file using SSB for the target specified
  export SPTARGET
  cd $CODE_BASE
  ./build.sh clean war
  if [[ "$?" -ne 0 ]] ; then
     echo 'Errors occurred while running the ssb build. Aborting.'
     BUILD_IMAGE=false
  else
    # Delete the exising war file
    rm -rf $WORKINGDIR/stage/identityiq.war
    # When the build is complete - copy the generated war file to the docker folder
    cp build/deploy/identityiq.war $WORKINGDIR/stage/
  fi
else
  # using an existing build if located in the staging directory
  if [[ -f $WORKINGDIR/stage/identityiq.war ]]; then
    echo 'Using the exising identity war file in the staging directory'
  else
    BUILD_IMAGE=false
    echo 'No war file present in the staging location'
  fi
fi


if [[ "$BUILD_IMAGE" = "false" ]] ; then
     echo 'Mandatory details are missing for the build. Check the configuration.'
else
  # Move to docker location
  cd $WORKINGDIR
  # Run the docker build image command
  docker build -t $DOCKER_IMAGE_NAME .
  
  # Create a container
  docker create -P --name $DOCKER_CONTAINER_NAME $DOCKER_IMAGE_NAME
  
  # Start the container
  docker start $DOCKER_CONTAINER_NAME
  
  echo 'Docker container ' $DOCKER_CONTAINER_NAME ' is now ready. Run docker ps for port information'
fi
