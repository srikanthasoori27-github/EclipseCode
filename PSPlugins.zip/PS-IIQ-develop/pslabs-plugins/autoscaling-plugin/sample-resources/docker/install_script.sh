#!/bin/bash

STAGE_HOME=/sp/stage
INSTALL_HOME=/sp

cd $INSTALL_HOME
# Install java
rpm -ivh $STAGE_HOME/jdk*.rpm

# Unzip tomcat
mkdir apache-tomcat && tar zxf $STAGE_HOME/apache-tomcat*.tar.gz -C apache-tomcat --strip-components 1

CATALINA_HOME=$INSTALL_HOME/apache-tomcat
cd $CATALINA_HOME/bin
cp $INSTALL_HOME/scripts/setenv.sh $CATALINA_HOME/bin/
chmod +x catalina.sh
chmod +x setenv.sh

# Do a base installation
cd $CATALINA_HOME/webapps
mkdir identityiq

# If a war file is already avaialble (generated using ssb or other build process - use it to build the environment)
if ls $STAGE_HOME/identityiq.war 1> /dev/null 2>&1; then
	cd $CATALINA_HOME/webapps/identityiq
	jar -xf $STAGE_HOME/identityiq.war
else
# Do a base install and apply patches,efixes etc
	mkdir -p $INSTALL_HOME/iiqstage
	cd $INSTALL_HOME/iiqstage
	jar -xf $STAGE_HOME/ga/identityiq-*.zip
	cd $CATALINA_HOME/webapps/identityiq
	jar -xf $INSTALL_HOME/iiqstage/identityiq.war
	# Apply the patch
	if ls $STAGE_HOME/patch/identityiq-*.jar 1> /dev/null 2>&1; then
		cd $CATALINA_HOME/webapps/identityiq
		jar -xf $STAGE_HOME/patch/identityiq-*.jar
	fi

	# Apply the efixes now
	if ls $STAGE_HOME/efixes/*.zip 1> /dev/null 2>&1; then
		for efix in $STAGE_HOME/efixes/*.zip; do
		  jar -xf $efix
		done
	fi
fi

cd $CATALINA_HOME/webapps/identityiq/WEB-INF/bin
chmod +x iiq

rpm -ivh $INSTALL_HOME/mysql-community-release.noarch.rpm
yum update
yum install -y mysql-server
yum clean all

# This is for 5.7
cd /var/lib/
chown mysql:mysql mysql-files
chmod 750 mysql-files/
mysqld --initialize-insecure
chown -R mysql /var/lib/mysql
mysqld --user mysql &

#These are only for 5.6
#mysql_install_db --user mysql 
#chown -R mysql /var/lib/mysql
#mysqld --user mysql &
#mysqladmin password root

# Generate schema
cd  $CATALINA_HOME/webapps/identityiq/WEB-INF/bin
./iiq schema
echo 'Completed Schema Generation'

# Create identityiq schema
echo 'Start of Identity IQ Schema Creation'
cd $CATALINA_HOME/webapps/identityiq/WEB-INF/database
mysql -f < create_identityiq_tables.mysql;
mysql -u root --skip-password <<-EOF
GRANT ALL PRIVILEGES ON *.* TO 'root'@'%'  identified by 'root' WITH GRANT OPTION;
GRANT ALL PRIVILEGES ON *.* TO 'identityiq'@'%'  identified by 'identityiq' WITH GRANT OPTION;
ALTER USER 'root'@'localhost' IDENTIFIED BY 'root';
EOF
echo 'End of IdentiyIQ Schema Creation'

# Importing IIQ Configuration Files
echo 'Importing of IIQ Configuration files'
cd $CATALINA_HOME/webapps/identityiq/WEB-INF/bin
./iiq console -u $IIQ_USER -p $IIQ_PASSWORD<<-IIQCONSOLE
import init.xml
exit
IIQCONSOLE

# Delete the staging file
rm -rf $STAGE_HOME/jdk*
rm -rf $STAGE_HOME/apache*
rm -rf $INSTALL_HOME/mysql-community-release.noarch.rpm
rm -rf $INSTALL_HOME/iiqstage
rm -rf $INSTALL_HOME/scripts/setenv.sh
rm -rf $INSTALL_HOME/scripts/install_script.sh
cd $CATALINA_HOME/webapps/
rm -rf manager host-manager examples docs