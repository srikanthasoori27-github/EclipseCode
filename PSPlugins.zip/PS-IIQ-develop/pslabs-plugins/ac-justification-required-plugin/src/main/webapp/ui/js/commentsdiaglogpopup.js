/**
 *
 * @author Annie Hwang (annie.hwang@sailpoint.com)
 *------------------------------------------------*
 * Date: 01-15-2020
 * @author Ricardo Miquilarena (ricardo.miquilarena@sailpoint.com)
 * Changes for FDIC - Zendesk case #51231:
 * - A tooltip is added to the Comment fields indicating where a mandatory justification needs to be entered
 * - Allow for the Access Request Review tab Submit button to not be disabled by default
 * - Plugin configuration parameters have been added to allow the submit button to either be enabled or disabled
 *   - If it is disabled by default then it remains disabled until all comments are entered - Current default behavior
 *   - If it is enable by default then a new button is added to run
 *     a function that will verify if all comments have been entered
 *   - Once all comments have been entered the OOTB Submit button will be programatically clicked
 * - Eliminate initial popup, firstPop is set to true by default
 */

var isDefaultDisabled = true, /* Indicates if Access Request Review tab Submit button is disabled by default */
    itemsMissingComment = new Array(), navigationBarDiv;

jQuery(document).ready(function(){
	var saveClicked = true;
	var firstPop = true;
  var requiredMessage = "";
  var ootbSubmitBtn;
	top.cmt4all = "MANDATORY";

	MutationObserver = window.MutationObserver || window.WebKitMutationObserver || window.MozMutationObserver;
	var observer = new MutationObserver(function(mutations, observer){
    try
    {
      isDefaultDisabled = getConfigAttr('getSubmitDisabled', true);
    }
    catch(e)
    {
      isDefaultDisabled = false;
      if(isDebugEnabled) console.log(e);
    }

    for(var i = 0; i < mutations.length; i++){
			var mutation = mutations[i];
			var cd = jQuery.find("button[ng-click*='reviewCtrl.showCommentDialog(requestedItem)']");
			var cd2 = jQuery.find("button[ng-click*='reviewCtrl.showCommentDialog(removedItem)']");
			var sd = jQuery.find("button[ng-disabled*='reviewCtrl.getSubmitDisabled()']");
			if(sd.length >= 1){
				sd[0].disabled = isDefaultDisabled;
				var ab=document.createAttribute("ng-items");
				ab.value="reviewCtrl.getRequestedItems()";
				sd[0].attributes.setNamedItem(ab);
			}

      itemsMissingComment = new Array();
			if(cd.length >= 1)
      {
				saveClicked = true;
				for(var j=0; j<cd.length; j++){
					var lbl = cd[j].getAttribute("aria-label");
					var a = document.createAttribute("ng-class");

					a.value="{'btn-success' : requestedItem.hasCommentsOrNotes(), 'btn-danger' : !requestedItem.hasCommentsOrNotes()}";

					cd[j].attributes.setNamedItem(a);

					if (lbl.indexOf("Comment for") != -1)
          {
						saveClicked = saveClicked && false;
						cd[j].className="btn btn-sm m-l-xs btn-danger";
            /* #51231: Add a tooltip to the Comment field indicating that a justification must be entered for this item */
            requiredMessage = lbl + " must be entered";
            cd[j].setAttribute("title", requiredMessage);
            /* #51231: Populate array that will be used to display the entitlements/roles that are missing a justification text */
            itemsMissingComment.push(requiredMessage);
					} else {
						saveClicked = saveClicked && true;
						cd[j].className = "btn btn-sm m-l-xs btn-success";
            /* #51231: Removes the tooltip from the Comment field for this item */
            cd[j].setAttribute("title", "");
					}
					if (!firstPop) {
            cd[0].click(function(){console.log("pop!")});
            firstPop = true;
					}
				}
			}
			if (cd2.length >= 1) {
				saveClicked = true;
				for (var j2=0; j2<cd2.length; j2++) {
					var lbl = cd2[j2].getAttribute("aria-label");
					var a2=document.createAttribute("ng-class");

					a2.value="{'btn-success' : requestedItem.hasCommentsOrNotes(), 'btn-danger' : !requestedItem.hasCommentsOrNotes()}";

					cd2[j2].attributes.setNamedItem(a2);
					if (lbl.indexOf("Comment for") != -1) {
						saveClicked = saveClicked && false;
						cd2[j2].className="btn btn-sm m-l-xs btn-danger";
            /* #51231: Add a tooltip to the Comment field indicating that a justification must be entered for this item */
            requiredMessage = lbl + " must be entered";
            cd2[j2].setAttribute("title", requiredMessage);
            itemsMissingComment.push(requiredMessage);
					} else {
						saveClicked = saveClicked && true;
						cd2[j2].className="btn btn-sm m-l-xs btn-success";
            /* #51231: Removes the tooltip from the Comment field for this item */
            cd2[j2].setAttribute("title", "");
					}
          if (!firstPop) {
            cd2[0].click(function(){console.log("pop!")});
						firstPop = true;
					}
				}
			}

      var sd = jQuery.find("button[ng-disabled*='reviewCtrl.getSubmitDisabled()']");
      if(sd.length >= 1)
      {
        /* #51231: If Submit button is enable by default then when the button is
         * clicked it runs a function to check for any missing justification text
         */
        if(isDebugEnabled) console.log("Number of missing justification comments:" + itemsMissingComment.length);
        if(!isDefaultDisabled)
        {
          if(!submitBtnReconfigured)
          {
            submitBtnReconfigured = reconfigureSubmitButton(sd, submitBtnReconfigured);
          }
          toggleSubmitButtons(sd);
        }

        if(saveClicked){
          sd[0].disabled = false;
        } else {
          sd[0].disabled = isDefaultDisabled;
        }
      }
    }
	});

	// define what element should be observed by the observer
	// and what types of mutations trigger the callback
	observer.observe(document, {
		childList: true,
		subtree: true,
		attributes: false
		//...
	});
});
