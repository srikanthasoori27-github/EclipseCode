/**
 * (c) Copyright 2019 SailPoint Technologies, Inc., All Rights Reserved.
 */

var jQueryClone = jQuery;
var CsrfToken = Ext.util.Cookies.get('CSRF-TOKEN');
var identityId = "";
var taskResultId = "";
var taskError = "";
var taskComplete = false;
var taskSuccess = false;
var checkResultTimer = undefined;
var messageCatalog = {};

function loadIdentityRefreshMessageCatalog() {
	jQueryClone.ajax({
		'async': false,
		'method': "GET",
        'beforeSend': function (request) {
            request.setRequestHeader("X-XSRF-TOKEN", CsrfToken);
        },
        'url': SailPoint.CONTEXT_PATH + "/ui/rest/messageCatalog?lang=" + SailPoint.SYSTEM_LOCALE,
        'success': function(msg) {
        	messageCatalog = msg; 
        }
    });
}

function spTranslateMessage(key) {
	var value = messageCatalog[key];
	if (typeof value === 'string' && value != '') {
		return value;
	}
	return key;
}

function checkResult() {
	if (taskResultId !== undefined) {
	    jQueryClone.ajax({
	        method: "GET",
	        beforeSend: function (request) {
	            request.setRequestHeader("X-XSRF-TOKEN", CsrfToken);
	        },
	        url: SailPoint.CONTEXT_PATH + "/plugin/rest/identityRefreshPlugin/status/" + taskResultId
	    }).done(function (msg) {
	    	if (msg.complete === true) {
	    		var cancelBtn = document.getElementById('identityRefreshPluginCancelButton');
	    		cancelBtn.style.display = "none";
	    		var closeBtn = document.getElementById('identityRefreshPluginCloseButton');
	    		closeBtn.style.display = "block";
	    		stopCheckResult();
	    	}
	    	if (msg.success) {
	    		taskSuccess = true;
	    		jQuery("div#identityRefreshStatus").text("Success");
	    	} else if (msg.failed) {
	    		if (msg.error) {
		    		jQuery("div#identityRefreshStatus").text(msg.error);
	    		} else {
		    		jQuery("div#identityRefreshStatus").text("Error");
	    		}
	    	} else if (msg.warning) {
	    		if (msg.warnings) {
		    		jQuery("div#identityRefreshStatus").text(msg.warnings);
	    		} else {
		    		jQuery("div#identityRefreshStatus").text("Warning");
	    		}
	    	}
	    });			
	}
}

function startCheckResult() {
	checkResultTimer = setInterval(checkResult, 1000);
}

function stopCheckResult() {
	if (checkResultTimer !== undefined) {
		clearInterval(checkResultTimer);
	}
	checkResultTimer = undefined;
}

function showRefreshModal() {
	var modal = document.getElementById('identityRefreshModalBackground');
	modal.style.display = "block";
	var cancelBtn = document.getElementById('identityRefreshPluginCancelButton');
	cancelBtn.style.display = "block";
	var closeBtn = document.getElementById('identityRefreshPluginCloseButton');
	closeBtn.style.display = "none";
	
	jQuery("div#identityRefreshStatus").text("...");

	// Start waiting for result
	startCheckResult();
}

function hideRefreshModal() {
	var modal = document.getElementById('identityRefreshModalBackground');
	modal.style.display = "none";
	taskError = "";
	taskResultId = "";
	taskComplete = false;
	stopCheckResult();
}

function initiateIdentityRefresh(identityId) {
    jQueryClone.ajax({
        method: "GET",
        beforeSend: function (request) {
            request.setRequestHeader("X-XSRF-TOKEN", CsrfToken);
        },
        url: SailPoint.CONTEXT_PATH + "/plugin/rest/identityRefreshPlugin/refresh/" + identityId
    })
    .done(function (msg) {
    	taskResultId = msg.taskResultId;
    	error = msg.error;
    });
}

function cancelIdentityRefresh(taskResultId) {
    jQueryClone.ajax({
        method: "GET",
        beforeSend: function (request) {
            request.setRequestHeader("X-XSRF-TOKEN", CsrfToken);
        },
        url: SailPoint.CONTEXT_PATH + "/plugin/rest/identityRefreshPlugin/cancel/" + taskResultId
    })
    .done(function (msg) {
    });	
}

function startRefresh() {
	// Get Identity ID
	var identityId = document.getElementById('editForm:id').value;
	// Start the refresh
	taskSuccess = false;
	initiateIdentityRefresh(identityId)
	// Open dialog
	showRefreshModal();
}

function cancelRefresh() {
	// Cancel task if needed
	if (taskResultId !== "" && taskResultId !== undefined) {
		cancelIdentityRefresh(taskResultId);
	}
	// Close dialog
	hideRefreshModal();
	if (taskSuccess) {
		 location.reload();
	}
}

jQuery(document).ready(function(){
	loadIdentityRefreshMessageCatalog();
	var modal =
	  '<div id="identityRefreshModalBackground" class="identityRefreshModalBackground">' + 
	  '  <div id="identityRefreshModalContent" class="identityRefreshModalContent x-window x-window-default">' +
	  '    <h4>' + spTranslateMessage('id_refresh_plugin_refreshing') + '</h4>' +
	  '    <div id="identityRefreshStatus"></div><br/>' +
	  '    <input id="identityRefreshPluginCancelButton" class="primaryBtn" name="identityRefreshPluginCancelButton" type="button" value="' + spTranslateMessage('ui_button_cancel') + '"/>' +
	  '    <input id="identityRefreshPluginCloseButton" class="primaryBtn" name="identityRefreshPluginCloseButton" type="button" value="' + spTranslateMessage('ui_button_close') + '"/>' +
	  '  </div>'
	  '</div>';
	var refreshButton = '<input id="identityRefreshPluginButton" class="secondaryBtn" name="identityRefreshPluginButton" type="button" value="' + spTranslateMessage('ui_manage_accounts_op_refresh') + '"/>'
	jQuery('div#bodyDivContent form#editForm div.buttonRow').append(refreshButton);
	jQuery("div.classic-body table#appTable").before(modal);
	
	jQuery('input#identityRefreshPluginButton').on('click', function() {
		startRefresh();
	});
	jQuery('input#identityRefreshPluginCancelButton').on('click', function() {
		cancelRefresh();
	});
	jQuery('input#identityRefreshPluginCloseButton').on('click', function() {
		cancelRefresh();
	});
	
    jQuery("#impersonateSelectorModalContent").keydown(function(event) {
    	if (event.which == 27) {
    		// Escape
    		cancelRefresh();
    	}
    });
});