/**
 * (c) Copyright 2019 SailPoint Technologies, Inc., All Rights Reserved.
 */

var jQueryClone = jQuery;
var CsrfToken = Ext.util.Cookies.get('CSRF-TOKEN');
var identityId = "";
var taskResultId = "";
var taskError = "";
var taskComplete = false;
var taskSuccess = false;
var checkResultTimer = undefined;
var messageCatalog = {};

var callBackLock = false;

//For observer
var idRefreshTargetNode = undefined;
var idRefreshObserverconfig = {
	attributes : false,
	childList : true,
	subtree : true
};

function loadIdentityRefreshMessageCatalog() {
	jQueryClone.ajax({
		'async': false,
		'method': "GET",
        'beforeSend': function (request) {
            request.setRequestHeader("X-XSRF-TOKEN", CsrfToken);
        },
        'url': SailPoint.CONTEXT_PATH + "/ui/rest/messageCatalog?lang=" + SailPoint.SYSTEM_LOCALE,
        'success': function(msg) {
        	messageCatalog = msg; 
        }
    });
}

function spTranslateMessage(key) {
	var value = messageCatalog[key];
	if (typeof value === 'string' && value != '') {
		return value;
	}
	return key;
}

function checkResult() {
	if (taskResultId !== undefined) {
	    jQueryClone.ajax({
	        method: "GET",
	        beforeSend: function (request) {
	            request.setRequestHeader("X-XSRF-TOKEN", CsrfToken);
	        },
	        url: SailPoint.CONTEXT_PATH + "/plugin/rest/identityRefreshPlugin/status/" + taskResultId
	    }).done(function (msg) {
	    	if (msg.complete === true) {
	    		var cancelBtn = document.getElementById('identityRefreshPluginCancelButton');
	    		cancelBtn.style.display = "none";
	    		var closeBtn = document.getElementById('identityRefreshPluginCloseButton');
	    		closeBtn.style.display = "block";
	    		stopCheckResult();
	    	}
	    	if (msg.success) {
	    		taskSuccess = true;
	    		jQuery("div#identityRefreshStatus").text("Success");
	    	} else if (msg.failed) {
	    		if (msg.error) {
		    		jQuery("div#identityRefreshStatus").text(msg.error);
	    		} else {
		    		jQuery("div#identityRefreshStatus").text("Error");
	    		}
	    	} else if (msg.warning) {
	    		if (msg.warnings) {
		    		jQuery("div#identityRefreshStatus").text(msg.warnings);
	    		} else {
		    		jQuery("div#identityRefreshStatus").text("Warning");
	    		}
	    	}
	    });			
	}
}

function startCheckResult() {
	checkResultTimer = setInterval(checkResult, 1000);
}

function stopCheckResult() {
	if (checkResultTimer !== undefined) {
		clearInterval(checkResultTimer);
	}
	checkResultTimer = undefined;
}

function showRefreshModal() {
	var modal = document.getElementById('identityRefreshModalBackground');
	modal.style.display = "block";
	var cancelBtn = document.getElementById('identityRefreshPluginCancelButton');
	cancelBtn.style.display = "block";
	var closeBtn = document.getElementById('identityRefreshPluginCloseButton');
	closeBtn.style.display = "none";

	jQuery("div#identityRefreshStatus").text("...");
	
	// Start waiting for result
	startCheckResult();
}

function hideRefreshModal() {
	var modal = document.getElementById('identityRefreshModalBackground');
	modal.style.display = "none";
	taskError = "";
	taskResultId = "";
	taskComplete = false;
	stopCheckResult();
}

function initiateIdentityRefresh(identityId) {
    jQueryClone.ajax({
        method: "GET",
        beforeSend: function (request) {
            request.setRequestHeader("X-XSRF-TOKEN", CsrfToken);
        },
        url: SailPoint.CONTEXT_PATH + "/plugin/rest/identityRefreshPlugin/refresh/" + identityId
    })
    .done(function (msg) {
    	taskResultId = msg.taskResultId;
    	error = msg.error;
    });
}

function cancelIdentityRefresh(taskResultId) {
    jQueryClone.ajax({
        method: "GET",
        beforeSend: function (request) {
            request.setRequestHeader("X-XSRF-TOKEN", CsrfToken);
        },
        url: SailPoint.CONTEXT_PATH + "/plugin/rest/identityRefreshPlugin/cancel/" + taskResultId
    })
    .done(function (msg) {
    });	
}

function startRefresh() {
	// Get Identity ID
	var locationHash = document.location.hash;
	var identityId = /\#\/identities\/([0-9a-f]+)\//.exec(locationHash)[1];
	// Start the refresh
	taskSuccess = false;
	initiateIdentityRefresh(identityId)
	// Open dialog
	showRefreshModal();
}

function cancelRefresh() {
	// Cancel task if needed
	if (taskResultId !== "" && taskResultId !== undefined) {
		cancelIdentityRefresh(taskResultId);
	}
	// Close dialog
	hideRefreshModal();
	if (taskSuccess) {
		 location.reload();
	}
}

function initIdentityRefreshElements() {	
	var modal =
	  '<div id="identityRefreshModalBackground" class="identityRefreshModalBackground">' + 
	  '  <div id="identityRefreshModalContent" class="identityRefreshModalContent x-window x-window-default">' +
	  '    <h4>' + spTranslateMessage('id_refresh_plugin_refreshing') + '</h4>' +
	  '    <div id="identityRefreshStatus"></div><br/>' +
	  '    <input id="identityRefreshPluginCancelButton" class="primaryBtn" name="identityRefreshPluginCancelButton" type="button" value="' + spTranslateMessage('ui_button_cancel') + '"/>' +
	  '    <input id="identityRefreshPluginCloseButton" class="primaryBtn" name="identityRefreshPluginCloseButton" type="button" value="' + spTranslateMessage('ui_button_close') + '"/>' +
	  '  </div>'
	  '</div>';
	jQuery("div.sp-body div.sp-ui-app").before(modal);
	
	jQuery('button#btn-identity-refresh-plugin').on('click', function() {
		startRefresh();
	});
	jQuery('input#identityRefreshPluginCancelButton').on('click', function() {
		cancelRefresh();
	});
	jQuery('input#identityRefreshPluginCloseButton').on('click', function() {
		cancelRefresh();
	});
	
    jQuery("#impersonateSelectorModalContent").keydown(function(event) {
    	if (event.which == 27) {
    		// Escape
    		cancelRefresh();
    	}
    });
}


/**
 * Simple sleep method.
 * 
 * @param millisecs
 * @returns
 */
function idrefresh_sleep_ms(millisecs) {
    var initiation = new Date().getTime();
    while ((new Date().getTime() - initiation) < millisecs);
}

// ----------------------------------------------------------------------------
// On completion of the load start an observer is instantiated to wait for the 
// field(s) to appear.
// The observer will also monitor page elements being removed. The callback
// method will respond to such changes and maintain form elements where
// necessary.
// ----------------------------------------------------------------------------
var identityRefreshInjectionCallback = function(mutationsList, observer) {
	while (callBackLock == true) {
		idrefresh_sleep_ms(100);
	}
	callBackLock = true;
	console.log("identityRefreshInjectionCallback");
	
	var identityNameField = jQuery("div.sidebar div.text-center div#identity-name.ng-binding")[0];
	if (identityNameField !== undefined) {
		console.log("identityRefreshInjectionCallback: identity name field found");
		var refreshButton = jQuery("button#btn-identity-refresh-plugin")[0];
		if (refreshButton === undefined) {
			var refreshButtonHtml = '<button class="btn btn-white btn-sm icon-btn" id="btn-identity-refresh-plugin" style=""><i class="fa fa-refresh fa-lg stop-spin" role="presentation"></i></button>';
			jQuery("div.sidebar div.text-center div#identity-name.ng-binding").after(refreshButtonHtml);
			initIdentityRefreshElements();
		}
	}
	
	callBackLock = false;
}

//Page Observer
var observer = new MutationObserver(identityRefreshInjectionCallback);
jQuery(document).ready(function(){
	idRefreshTargetNode = jQuery("div.sp-body-container div.sp-body div.sp-ui-app")[0];
	loadIdentityRefreshMessageCatalog();
	observer.observe(idRefreshTargetNode, idRefreshObserverconfig);
});
