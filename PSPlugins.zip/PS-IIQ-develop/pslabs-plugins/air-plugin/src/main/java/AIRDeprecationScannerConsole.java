
import org.apache.commons.cli.Option;
import org.apache.commons.cli.Options;

import com.sailpoint.pse.plugin.air.console.AIRBaseContextConsole;
import com.sailpoint.pse.plugin.air.ds.util.DeprecationScannerUtil.ConfigurationParam;
import com.sailpoint.pse.plugin.air.task.DeprecationScannerTask;

import sailpoint.object.Attributes;
import sailpoint.object.TaskResult;
import sailpoint.object.TaskSchedule;

public class AIRDeprecationScannerConsole extends AIRBaseContextConsole {

    public AIRDeprecationScannerConsole() {

        super(true);
    }

    @Override
    public String getCommandName() {

        return "AirDeprecationChecker";
    }

    @Override
    public void execute() throws Exception {

        TaskResult taskResult = new TaskResult();
        TaskSchedule taskSchedule = null;

        Attributes<String, Object> taskArguments = new Attributes<String, Object>();
        taskArguments.put(ConfigurationParam.PARAM_XML_FILE_LOCATION, getArgumentValue("folderToScan"));
        taskArguments.put(ConfigurationParam.PARAM_REPORT_FILE_LOCATION, getArgumentValue("reportLocation"));
        taskArguments.put(ConfigurationParam.PARAM_IGNORE_FOLDER_LIST, getArgumentValue("ignoreFolderList"));
        taskArguments.put(ConfigurationParam.PARAM_DTD_FILE_LOCATION, getArgumentValue("dtdLocation"));

        DeprecationScannerTask deprecationScanner = new DeprecationScannerTask();
        deprecationScanner.execute(getContext(), taskSchedule, taskResult, taskArguments);

        if (taskResult != null) {

            if (this.debugMode) {
                logDebugMessage("taskResult:");
                logDebugMessage(taskResult.toXml());
            }

            String bshReportName = (String) taskResult.getAttribute("bshReportName");
            String deprecationStringReportName = (String) taskResult.getAttribute("deprecationStringReportName");

            this.logMessage("=============================================");
            this.logMessage("AIR Deprecation Scanner has finished processing");
            this.logMessage("BSH Report has been generated at location: " + bshReportName);
            this.logMessage("Deprecation Report has been generated at location: " + deprecationStringReportName);
        }
    }

    @Override
    protected Options getOptions() {

        Options options = new Options();

        Option basePath = new Option("f", "folderToScan", true, "DeprecationScannerTask XML Folder Location");
        basePath.setRequired(true);
        options.addOption(basePath);

        Option removeIDs = new Option("r", "reportLocation", true, "Report Location");
        options.addOption(removeIDs);

        Option classNames = new Option("i", "ignoreFolderList", true, "Ignore Folder list");
        options.addOption(classNames);

        Option fromDate = new Option("d", "dtdLocation", true, "DTD File Location");
        options.addOption(fromDate);

        return options;
    }

    public static void main(String[] args) throws Exception {

        AIRDeprecationScannerConsole console = null;

        try {
            console = new AIRDeprecationScannerConsole();
            console.setCommandLineArgs(args);
            console.process();
        } catch (Exception e) {
            console.logMessage("An exception has occurred:" + e.getMessage());
        } finally {
            console.destroyConsole();
        }

        System.exit(1);
    }
}
