
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.Arrays;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.sailpoint.pse.plugin.air.object.Occurrence;
import com.sailpoint.pse.plugin.air.object.Occurrence.BaseType;
import com.sailpoint.pse.plugin.air.util.CodeReviewUtil;

import sailpoint.tools.Util;

public class AIRConsole {

    public static boolean debugMode = false;
    public static boolean writeToFile = false;
    public static boolean writeToConsole = true;
    private static final Log _log = LogFactory.getLog(AIRConsole.class);

    @SuppressWarnings({ "unchecked" })
    public static void main(String[] args) throws Exception {

        String base = System.getProperty("user.dir");
        String outputFile = null;
        String baseXmlFilePath = null;
        String baseBuildFilePath = null;
        String baseJavaFilePath = null;
        String configurationFilePath = null;
        String dtdFilePath = null;
        String baseTypesCSV = null;
        boolean validateCode = false;

        String error = null;
        logMessage("Enter Main");
        logMessage("Args: " + Arrays.toString(args));

        if (args.length > 0) {
            boolean expectedArgsIsEven = true;
            /*
             * All options should come with an additional arg except the following which would all flip the even/odd number
             */
            int i = 0;

            if ("AIRConsole".equals(args[0])) {
                expectedArgsIsEven = !expectedArgsIsEven;
                logMessage("Ignore the AIRConsole string ... start at 1");
                i = 1;
            }
            String argsString = Arrays.toString(args);

            if (argsString.contains("-h,") || argsString.contains("-h]")) {
                expectedArgsIsEven = !expectedArgsIsEven;
                logMessage("-h is in the args");
            }

            if (argsString.contains("-v,") || argsString.contains("-v]")) {
                expectedArgsIsEven = !expectedArgsIsEven;
                logMessage("-v is in the args");
            }

            if (argsString.contains("-validate,") || argsString.contains("-validate]")) {
                expectedArgsIsEven = !expectedArgsIsEven;
                logMessage("-validate is in the args");
            }
            logMessage("args length: " + args.length);
            logMessage("expectedArgsIsEven: " + expectedArgsIsEven);

            if (args.length % 2 != (expectedArgsIsEven ? 0 : 1)) {
                error = "Invalid Arguments ... see help (-h)";

            }

            while (error == null && i < args.length) {
                String option = args[i++];
                logMessage("Process Option: " + option);

                switch (option) {
                    case "-h":
                        error = "Help Option selected";
                        logMessage("Found Help Option");
                        break;

                    case "-xmlPath":
                        baseXmlFilePath = args[i++];
                        logMessage("Set baseXmlFilePath to " + baseXmlFilePath);
                        break;

                    case "-buildPath":
                        baseBuildFilePath = args[i++];
                        logMessage("Set baseBuildFilePath to " + baseBuildFilePath);
                        break;

                    case "-javaPath":
                        baseJavaFilePath = args[i++];
                        logMessage("Set baseJavaFilePath to " + baseJavaFilePath);
                        break;

                    case "-configPath":
                        configurationFilePath = args[i++];
                        logMessage("Set configurationFilePath to " + configurationFilePath);
                        break;

                    case "-dtd":
                        dtdFilePath = args[i++];
                        logMessage("Set dtdFilePath to " + dtdFilePath);
                        break;

                    case "-scan":
                        baseTypesCSV = args[i++];

                        logMessage("Set baseTypes to " + baseTypesCSV);
                        break;

                    case "-o":
                        outputFile = args[i++];
                        logMessage("Set outputFile to " + outputFile);
                        break;

                    case "-mode":
                        String mode = args[i++];
                        if ("console".equals(mode)) {
                            writeToFile = false;
                            writeToConsole = true;
                            logMessage("Include output in the console only");
                        } else if ("file".equals(mode)) {
                            writeToFile = true;
                            writeToConsole = false;
                            logMessage("Include output in the file only");
                        } else if ("both".equals(mode)) {
                            writeToFile = true;
                            writeToConsole = true;
                            logMessage("Include output in the file and console");
                        }
                        break;

                    case "-v":
                        logMessage("Set verbose output");
                        debugMode = true;
                        break;

                    case "-validate":
                        logMessage("Set verbose output");
                        validateCode = true;
                        break;

                    default:
                        error = "Invalid Arguments ... -h is the only acceptable option without an argument and can only be used alone";
                }
            }
        }

        if (error != null) {
            logErrorMessage(error);
            String helpMessage = printHelp();
            System.out.println(helpMessage);
            return;
        }

        if (baseBuildFilePath == null) {
            baseBuildFilePath = base;
            logMessage("Set default baseBuildFilePath: " + baseBuildFilePath);
        }

        if (baseXmlFilePath == null) {
            baseXmlFilePath = baseBuildFilePath + "\\build\\extract\\WEB-INF\\config\\custom";
            ;
            logMessage("Set default baseXmlFilePath: " + baseXmlFilePath);
        }

        if (outputFile == null) {
            outputFile = base + "\\AIRConsole.out";
            logMessage("Set default outputFile: " + outputFile);
        }

        if (baseJavaFilePath == null) {
            baseJavaFilePath = baseBuildFilePath + "\\src";
            logMessage("Set default baseJavaFilePath: " + baseJavaFilePath);
        }

        if (configurationFilePath == null) {
            configurationFilePath = baseBuildFilePath + "\\servicestools\\AIR_Configuration.ser";
            logMessage("Set default configurationFilePath: " + configurationFilePath);
        }

        if (dtdFilePath == null) {
            dtdFilePath = baseBuildFilePath + "\\build\\extract\\sailpoint.7.3p2.dtd";
            logMessage("Set default dtdFilePath: " + dtdFilePath);
        }

        if (baseTypesCSV == null) {
            baseTypesCSV = "ConfigBase";
            logMessage("Set default baseTypesCSV: " + baseTypesCSV);
        }

        Map<String, Object> map = null;

        try {
            FileInputStream fis = new FileInputStream(configurationFilePath);
            ObjectInputStream ois = new ObjectInputStream(fis);
            map = (Map<String, Object>) ois.readObject();

            ois.close();
            fis.close();
        } catch (IOException ioe) {
            logErrorMessage(null, ioe);
            ioe.printStackTrace();
            return;
        } catch (ClassNotFoundException c) {
            logErrorMessage("Class not found", c);
            c.printStackTrace();
            return;
        }

        if (debugMode) {
            logMessage("Deserialized HashMap..");
            // Display content using Iterator
            Set<Map.Entry<String, Object>> set = map.entrySet();
            Iterator<Map.Entry<String, Object>> iterator = set.iterator();

            while (iterator.hasNext()) {
                Map.Entry<String, Object> entry = (Map.Entry<String, Object>) iterator.next();
                Object val = entry.getValue();
                logMessage("key: " + entry.getKey() + " & Value: " + ((val != null) ? val.toString() : "NULL"));
            }
        }

        FileWriter fw = null;

        try {

            if (writeToFile) {
                fw = new FileWriter(new File(outputFile));
                logMessage("Open FileWriter for: " + outputFile);
            } else {
                logMessage("Using Console Mode Only: " + outputFile);
            }
        } catch (Exception e) {
            logErrorMessage("Error creating out file: ", e);
            return;
        }
        boolean throwShowStopperError = false;

        try {
            List<String> baseTypeStringList = Util.csvToList(baseTypesCSV);

            writeMessage(fw, "Setting baseXmlFilePath: " + baseXmlFilePath, true, false);
            writeMessage(fw, "Setting baseBuildFilePath: " + baseBuildFilePath, true, false);
            writeMessage(fw, "Setting baseJavaFilePath: " + baseJavaFilePath, true, false);
            writeMessage(fw, "Setting baseTypeStringList: " + baseTypeStringList, true, false);

            CodeReviewUtil.loadFlags(map);
            CodeReviewUtil.loadBaseTypes(baseTypeStringList);

            List<BaseType> baseTypes = CodeReviewUtil.getBaseTypes();
            writeMessage(fw, "baseTypes: " + baseTypes, true, false);

            List<Occurrence> occurrences = CodeReviewUtil.findAllConfiguredFlags(baseTypes, baseXmlFilePath, baseBuildFilePath, baseJavaFilePath, null);

            if (occurrences != null) {
                Collections.sort(occurrences);

                for (Occurrence occ : occurrences) {
                    String mess = occ.getStringMessage();

                    if (validateCode && occ.isShowStopper()) {
                        throwShowStopperError = true;
                    }
                    writeMessage(fw, mess, true);
                }
            }
        } catch (Exception e) {
            logErrorMessage(null, e);
        } finally {
            logMessage("Flush and close files");

            if (fw != null) {
                fw.flush();
                fw.close();
            }
        }

        if (throwShowStopperError) {
            throw new Exception("Found show stopper in Configurations");
        }
        logMessage("Review done");
    }

    private static String printHelp() {

        StringBuilder sb = new StringBuilder("");
        sb.append("\nPlease type your options");
        sb.append("\nAvailable Commands are as follows:\n");
        sb.append("\n-h          ... Help                                  ... AIRConsole -h");
        sb.append("\n-xmlPath    ... XML Path                              ... AIRConsole -xmlPath <path to XML files (default current directory\\build\\extract\\WEB-INF\\config\\custom)>");
        sb.append("\n-buildPath  ... Build Path                            ... AIRConsole -buildPath <path to XML files (default current directory)>");
        sb.append("\n-javaPath   ... Java Source Path                      ... AIRConsole -javaPath <path to java src files (default current directory\\src)>");
        sb.append("\n-configPath ... Configuration File Path               ... AIRConsole -configPath <path to Configuration file (default current directory\\servicestools\\AIR_Configuration.ser)>");
        sb.append("\n-dtd        ... DTD File Path                         ... AIRConsole -dtd <path to dtd file (default current directory\\build\\extract\\sailpoint.7.3p2.dtd)>");
        sb.append("\n-scan       ... Types to scan                         ... AIRConsole -scan <ConfigBase, BuildBase, JavaBase (default ConfigBase)>");
        sb.append("\n-mode       ... Output mode                           ... AIRConsole -mode <console, file (default file)>");
        sb.append("\n-validate   ... Throw error on show stopper           ... AIRConsole -validate");
        sb.append("\n-o          ... Output file                           ... AIRConsole -o <output file (default current directory\\AIRConsole.out)>");
        sb.append("\n-v          ... Provide console output with file mode ... AIRConsole -v");
        sb.append("\n");
        sb.append("\nExample commands:\n");
        sb.append("\nAIRConsole -h\n\t\tPrint this help text");
        sb.append("\nAIRConsole -configPath doc\\AIR-Config.ser\n\t\tScan files in this directory assuming ConfigBase using configuration at specified serialized file");
        sb.append("\nAIRConsole -v -scan ConfigBase,BuildBase\n\t\tScan files in this directory for ConfigBase and BuildBase flags using configuration at default file using verbose mode to print to the console and file");
        sb.append("\nAIRConsole -validate -scan ConfigBase,BuildBase\n\t\tScan files in this directory for ConfigBase and BuildBase flags using configuration at default file and throw an exception if there is a show stopper");

        return sb.toString();
    }

    private static void writeMessage(FileWriter fw, String message, boolean newLine) throws IOException {

        writeMessage(fw, message, newLine, true);
    }

    private static void writeMessage(FileWriter fw, String message, boolean newLine, boolean write) throws IOException {

        if (writeToFile && fw != null && write) {

            if (newLine) {
                fw.write(System.lineSeparator() + message);
            } else {
                fw.write(message);
            }
            logMessage("Wrote message: " + message);
        }

        if (writeToConsole) {
            System.out.println(message);
        }
    }

    private static void logMessage(String message) {

        _log.debug(message);

        if (debugMode) {
            System.out.println(message);
        }
    }

    private static void logErrorMessage(String message) {

        _log.error(message);

        if (debugMode) {
            System.err.println(message);
        }
    }

    private static void logErrorMessage(String message, Exception e) {

        _log.error(message, e);

        if (debugMode) {

            if (message != null && e != null) {
                System.err.println(message + ": " + e.getMessage());
            } else if (e != null) {
                System.err.println(e.getMessage());
            } else if (message != null) {
                System.err.println(message);
            }
        }
    }
}
