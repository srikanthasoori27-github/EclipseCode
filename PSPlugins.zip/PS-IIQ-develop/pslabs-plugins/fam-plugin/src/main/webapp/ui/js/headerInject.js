var famUrl;


$.ajax({
    //Rest call to Plugin endpoint
    url: PluginHelper.getPluginRestUrl('fam/famUrl'),
    headers:
        {
            //Used so we don't get CSRF errors
            'X-XSRF-TOKEN': PluginHelper.getCsrfToken()
        },
    dataType: 'text',
    success: function (data) {
        //This is the famUrl we get back from the REST call
        famUrl = data;
        //Modify IIQ pages to stuff in the SecurityIQ dropdowns
        jQuery(document).ready(function () {
            jQuery("ul.navbar-right li:first")
                .before(
                    '<li class="dropdown">' +
                    ' <a href="#" class="dropdown-toggle" role="menuitem" data-toggle="dropdown" aria-haspopup="true" id="siqmenu">' +
                    ' File Access Manager Dashboard' +
                    ' <span class="sr-only">' +
                    '   menu. Press ENTER or space to access submenu. To move through items press up or down arrow.' +
                    ' </span>' +
                    '  <span role="presentation" aria-hidden="true" class="caret"></span> ' +
                    ' </a>' +
                    '      <ul class="dropdown-menu" role="menu" aria-expanded="false">' +
                    '       <li role="presentation">' +
                    '        <a href="' + famUrl + '#/dashboard/admin-dashboard" role="menuitem" class="menuitem">Governance</a>' +
                    '       </li>' +
                    '       <li role="presentation">' +
                    '        <a href="' + famUrl + '#/forensics/activity" role="menuitem" class="menuitem">Activity</a>' +
                    '       </li>' +
                    '       <li role="presentation">' +
                    '        <a href="' + famUrl + '#/forensics/data-classification" role="menuitem" class="menuitem">Data Classification</a>' +
                    '       </li>' +
                    '       <li role="presentation">' +
                    '        <a href="' + famUrl + '#/goals/running-goals" role="menuitem" class="menuitem">Owner Election</a>' +
                    '       </li>' +
                    '       <li role="presentation">' +
                    '        <a href="' + famUrl + '#/resources/" role="menuitem" class="menuitem">Resources</a>' +
                    '       </li>' +
                    '       <li role="presentation">' +
                    '        <a href="' + famUrl + '#/reports/my-reports" role="menuitem" class="menuitem">Reports</a>' +
                    '       </li>' +
                    '       <li role="presentation">' +
                    '        <a href="' + famUrl + '#/tasks/access-certification/overview" role="menuitem" class="menuitem">Tasks</a>' +
                    '       </li>' +

                    '      </ul>' +
                    '</li>'
                );
        });


    },
    type: 'GET'
});
//console.log("famUrl = " + famUrl);

