//console.log("Loading kpisModule.js");


/**
 * Create the module.
 */

var myApp = angular.module('KPIs', ['ui.bootstrap', 'sailpoint.i18n',
    'sailpoint.comment', 'sailpoint.email', 'sailpoint.esig',
    'sailpoint.identity.account', 'sailpoint.modal',
    'sailpoint.util', 'sailpoint.tree', 'sailpoint.ui.bootstrap.carousel',
    'sailpoint.dataview', 'sailpoint.config']);

myApp.config(['$httpProvider', function ($httpProvider) {
    $httpProvider.defaults.xsrfCookieName = "CSRF-TOKEN";
}])

myApp.controller('KPIsControler', function ($scope, $http, $q, navigationService) {
    //console.log("Starting KPIsControler");

    var config = {
        headers: {
            'X-XSRF-TOKEN': PluginHelper.getCsrfToken()
        }
    }, promises;

    $scope.showDashboard = true;
    $scope.notDirectAccess = true;
    $scope.description = "";

    var myChart;

    $scope.categories = [{
        displayName: 'Select a familly first...',
        id: 'Select a familly first...'
    }];
    $scope.categoryFilterInput = "";


    $scope.goToURL = function (goToURL) {
        //console.log("goToUrl: " + goToURL);

        navigationService.go({
            url: goToURL
        });
    };

    //Calling this function when filtering the categories
    $scope.searchCategories = function () {
        //console.log("Starting searchCategories with filter: #" + this.categoryFilterInput + "#");
    };
    $scope.setCategory = function (cardCat) {
        //console.log("Starting setCategory with category: #" + cardCat + "#");
        $scope.category = cardCat;
        $scope.changeCategory();
    }

    //Calling that function when changing familly
    $scope.changeFamilly = function () {
        //console.log("Starting changeFamilly with familly: #" + this.familly + "#");

        if (this.familly != null && this.familly != '-- All') {
            $http.get(PluginHelper.getPluginRestUrl('kpis/categoriesFromFamillies/' + encodeURIComponent($scope.familly)), config).then(function (response) {
                //console.log("Got a response for changeFamilly");
                //console.log(response);
                $scope.categories = response.data;
                $scope.categories.unshift({id: "--", displayName: "-- KPIs Dashboard"});
                $scope.category = "--";
                //Getting lasts kpis
                $scope.showDashboard = true;
                $scope.notDirectAccess = true;
                $http.get(PluginHelper.getPluginRestUrl('kpis/lasts/' + encodeURIComponent($scope.familly)), config).then(function (response) {
                    //console.log("Got a response for lasts");
                    //console.log(response);
                    $scope.lasts = response.data.kpis;
                });
            });
        } else if (this.familly == '-- All') {
            //console.log("All famillies!!");
            $http.get(PluginHelper.getPluginRestUrl('kpis/categories/'), config).then(function (response) {
                //console.log("Got a response for changeFamilly");
                //console.log(response);
                $scope.categories = response.data;
                $scope.categories.unshift({id: "--", displayName: "-- KPIs Dashboard"});
                $scope.category = "--";
                //Getting lasts kpis
                $scope.showDashboard = true;
                $scope.notDirectAccess = true;
                $http.get(PluginHelper.getPluginRestUrl('kpis/lasts'), config).then(function (response) {
                    //console.log("Got a response for lasts");
                    //console.log(response);
                    $scope.lasts = response.data.kpis;
                });
            });
        } else {
            //console.log("No Familly.");
            $scope.showDashboard = true;
        }

    };

    //Calling that function when changing category
    $scope.changeCategory = function () {
        //console.log("Starting changeCategory with category: #" + this.category + "#");
        $scope.kpiFilterName = "";

        if (this.category != null && this.category != '--') {
            $scope.showDashboard = false;
            $http.get(PluginHelper.getPluginRestUrl('kpis/kpi/' + encodeURIComponent(this.category)), config).then(function (response) {
                //console.log("Got a response for changeCategory");
                //console.log(response);
                $scope.kpis = response.data;
                
                formatGraphData();
                
                if ($scope.kpis.kpis.length > 0) {
                    $http.get(PluginHelper.getPluginRestUrl('kpis/description/' + encodeURIComponent($scope.kpis.kpis[0].configurationName) + '/' + encodeURIComponent($scope.category)), config).then(function (response) {
                        $scope.description = response.data;
                        console.log("Got a response for description: " + $scope.description);
                    })
                } else {
                    $scope.description = "";
                    console.log("No kpis so not looking for description...");
                }
            });
        } else {
            //console.log("No category.");
            $scope.showDashboard = true;
        }

    };

    //Function updating the graph data
    function formatGraphData() {
        //console.log("Starting formatGraphData");

        //Reseting the cavans
        $('#canvas').remove(); // this is my <canvas> element
        $('#canvasContainer').append('<canvas id="canvas"></canvas>');
        canvas = document.querySelector('#canvas');
        ctx = canvas.getContext('2d');

        var newDataset = [];
        $scope.originalData = [];

        $scope.last = {};
        //console.log("kpis::::: "+$scope.kpis);
        //console.log("kpi::::: "+$scope.kpis.kpis);
        //the data is ordered by name and date
        $scope.kpis.kpis.forEach(function (kpi) {
        	//console.log("KPI: "+kpi);
            if (newDataset.length > 0 && newDataset[newDataset.length - 1].label == kpi.name) {
                //this is the same name
                newDataset[newDataset.length - 1].data.push({x: kpi.date, y: kpi.result});
                $scope.originalData[$scope.originalData.length - 1].data.push({x: kpi.date, y: kpi.result});
            } else {
                //this is a new name
                newDataset.push({
                    label: kpi.name,
                    fill: false,
                    borderColor: getRandomColor(),
                    data: [{x: kpi.date, y: kpi.result}]
                });
                $scope.originalData.push({
                    label: kpi.name,
                    fill: false,
                    borderColor: getRandomColor(),
                    data: [{x: kpi.date, y: kpi.result}]
                });
                $scope.last.result = kpi.result;
                $scope.last.date = kpi.date;
            }
        });
        $scope.data = {datasets: newDataset};
        //console.log("$scope.data");
        //console.log($scope.data);
        $scope.options = {
            responsive: true,
            tooltips: {
                enabled: true
            },
            title: {
                display: true,
                fontSize: 20,
                text: $scope.kpis.category
            },
            scales: {
                yAxes: [{
                    scaleLabel: {
                        display: true,
                        labelString: '#',
                        fontSize: 20
                    },
                    ticks: {
                        beginAtZero: true
                    }
                }],
                xAxes: [{
                    type: "time",
                    time: {
                        parser: 'x',
                        tooltipFormat: 'll'
                    },
                    scaleLabel: {
                        display: true,
                        labelString: 'Date'
                    }
                }],

            }
        };

        if ($scope.data.datasets.length > 5 || $scope.data.datasets.length == 1) {
            $scope.options.legend = {display: false};
        }

        //console.log("$scope.options");
        //console.log($scope.options);
        var canvas = document.getElementById("canvas");
        var ctx = canvas.getContext('2d');

        // Chart declaration:
        myChart = new Chart(ctx, {
            type: 'line',
            data: $scope.data,
            options: $scope.options
        });
        $scope.graph = true;
        //console.log("Ending formatGraphData");
    };

    //Getting random colors
    function getRandomColor() {
        var letters = '0123456789ABCDEF'.split('');
        var color = '#';
        for (var i = 0; i < 6; i++) {
            color += letters[Math.floor(Math.random() * 16)];
        }
        return color;
    }

    //Getting the request paramenters
    function getRequestParameter(name) {
        if (name = (new RegExp('[?&]' + encodeURIComponent(name) + '=([^&]*)')).exec(location.search))
            return decodeURIComponent(name[1]);
    }

    //Getting famillies
    $http.get(PluginHelper.getPluginRestUrl('kpis/famillies'), config).then(function (response) {
        //console.log("Got a response for famillies");
        //console.log(response);
        $scope.famillies = response.data;
        $scope.famillies.unshift("-- All");

        //Looking if any valid familly or category has been passed in the request as a parameter
        if (getRequestParameter("familly") != undefined) {
            //console.log("Got a familly from the request: " + getRequestParameter("familly"));
            $scope.famillies.forEach(function (fam) {
                if (fam == getRequestParameter("familly")) {
                    console.log("We got a match from an existing familly");
                    $scope.showDashboard = false;
                    $scope.notDirectAccess = false;
                    $scope.familly = fam;
                    $scope.changeFamilly();
                }
            });
        } else if (getRequestParameter("category") != undefined) {
            //console.log("Got a category from the request: " + getRequestParameter("category"));
            //$scope.changeFamilly();
            $scope.category = getRequestParameter("category");
            $scope.changeCategory();
        } else {
            if ($scope.famillies.length > 0) {
                $scope.familly = $scope.famillies[0];
                //console.log("default $scope.familly: " + $scope.familly);
            } else {
                console.log("There are no familly defined....");
            }
            $scope.changeFamilly();
        }
    });


    //Calling that function when changing category to refresh the grah
    $scope.filterGraph = function () {
        //console.log("Starting filterGraph with " + $scope.category + " " + $scope.kpiFilterName);

        var newDataset = [];
        $scope.originalData.forEach(function (dataset) {
            if (dataset.label.toUpperCase().includes($scope.kpiFilterName.toUpperCase())) {
                newDataset.push(dataset);
                //console.log("Got a match on " + dataset.label);
            }
        });
        myChart.data.datasets = newDataset;
        myChart.update();
    };


    //console.log("Ending KPIsControler");
}); 