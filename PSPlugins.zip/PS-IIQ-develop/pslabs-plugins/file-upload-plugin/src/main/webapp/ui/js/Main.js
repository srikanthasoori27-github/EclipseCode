/**
 * Main entry point for the Angular Application.
 * The "app" variable is used to register the Controllers, Directivesd
 * and services used in this solution.
 */
var app = angular.module('FileUploadApplication', ['ui.bootstrap','sailpoint.i18n',
	'sailpoint.util', 'sailpoint.ui.bootstrap.carousel', 'sailpoint.dataview', 'sailpoint.config',
	'sailpoint.modal']);

var pluginName = "fileUploadPlugin";
var debug = true;

app.config(
	function ($httpProvider) {
		$httpProvider.defaults.xsrfCookieName = "CSRF-TOKEN";
	}
);