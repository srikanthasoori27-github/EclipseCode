var jQueryClone = jQuery;
var CsrfToken = Ext.util.Cookies.get('CSRF-TOKEN');
var pluginPage = SailPoint.CONTEXT_PATH + '/plugins/pluginPage.jsf?pn=objectinspectorplugin';

jQuery(document).ready(function(){
	jQuery("ul.navbar-right li:first").before(
		'<li class="dropdown">' +
		'		<a href="' + pluginPage + '" tabindex="0" role="menuitem" data-snippet-debug="off">' +
		'			<i id="objectInspectorIcon" role="presenation" class="fa fa-check-square-o fa-lg"></i>' +
		'		</a>' +
		'</li>'
	);
});

