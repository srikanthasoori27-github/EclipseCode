package com.test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.TimeZone;

import sailpoint.api.SailPointContext;
import sailpoint.object.Application;
import sailpoint.object.Filter;
import sailpoint.object.GroupDefinition;
import sailpoint.object.Identity;
import sailpoint.object.Link;
import sailpoint.object.QueryOptions;
import sailpoint.tools.GeneralException;
import sailpoint.tools.Util;

public class Test {

  // returns empty string if string passed in is null
  String returnBlank(Object value) {
    String newValue = "";

    if (value != null) {
      newValue = (value.toString()).trim();
    }

    return newValue;
  }

  /****************************************************************************************************************
   * Returns list of all the applications a user doesn't have by getting a list of all
   * applications in the system and then removing the applications that a user has links
   * for
   ****************************************************************************************************************/
  List allApplicationsUserDoesNotHave(SailPointContext context, Identity identity) throws GeneralException {

    Iterator iterApps = null;
    Iterator iterLinks = null;

    Map allAppNames = new HashMap();

    try {
      // search for all apps with non null ids, which should be all of them
      QueryOptions qo = new QueryOptions();
      qo.addFilter(Filter.notnull("id"));
      iterApps = context.search(Application.class, qo, Arrays.asList("name"));
      // map of all appNames, using it for non-duplicate storing the value doesn't matter

      while (iterApps != null && iterApps.hasNext()) {
        String appName = (String) ((Object[]) iterApps.next())[0];
        allAppNames.put(appName, "true");
      }

    } finally {
      Util.flushIterator(iterApps);
    }

    try {
      QueryOptions qoLinks = new QueryOptions();
      qoLinks.add(Filter.ignoreCase(Filter.eq("identity.id", identity.getId())));

      List qoLinksSearch = new ArrayList();
      qoLinksSearch.add("application.name");

      iterLinks = context.search(Link.class, qoLinks, qoLinksSearch);

      while (iterLinks != null && iterLinks.hasNext()) {
        String appName = (String) ((Object[]) iterApps.next())[0];
        if (allAppNames.containsKey(appName))
          allAppNames.remove(appName);
      }
    } finally {
      Util.flushIterator(iterLinks);
    }

    List returnList = new ArrayList(allAppNames.keySet());

    return returnList;
  }

  /****************************************************************************************************************
   * Returns true if identity is in the population given, add's users id to the filter and queries for it, if any are returned then its in the population
   ****************************************************************************************************************/
  boolean isIdentityInPopulation(SailPointContext context, String identityName, String groupDefinitionName) throws GeneralException {
    boolean result = false;

    // if filter is empty then nothing to apply so user would be in the "filter"
    if (groupDefinitionName == null || groupDefinitionName.isEmpty()) {
      return true;
    }

    if (identityName != null && !identityName.isEmpty()) {
      Identity identity = context.getObjectByName(Identity.class, identityName);
      GroupDefinition groupDefinition = context.getObjectByName(GroupDefinition.class, groupDefinitionName);

      // if there's wrong identity or wrong group definition then they are not in the population
      if (identity != null && groupDefinition != null) {
        // get the id from the user
        String id = identity.getId();

        // get the filter from the population
        Filter filter = groupDefinition.getFilter();

        // make a query options and add the identity's id to it
        QueryOptions qo = new QueryOptions();
        qo.addFilter(filter);
        qo.addFilter(Filter.eq("id", id));

        int count = context.countObjects(Identity.class, qo);

        if (count > 0) {
          result = true;
        }
      }
    }
    return result;
  }

  /****************************************************************************************************************
   * Returns true if string1 contains string2 ignoring case
   ****************************************************************************************************************/
  boolean containsIgnoreCase(String string1, String string2) throws GeneralException {
    if (string1 != null && string2 != null) {
      string1 = string1.toLowerCase();
      string2 = string2.toLowerCase();

      return string1.contains(string2);
    }

    return false;
  }

  /****************************************************************************************************************
   * Method Name: returnLocale Parameters: -localeString: string indicator of the
   * locale, usually seperated by an underscore
   * 
   * Description: returns the locale based upon the string locale
   ****************************************************************************************************************/
  public Locale returnLocale(String localeString) {
    Locale locale = null;

    if (null == localeString || localeString.isEmpty()) {
      localeString = "en_US";
    }

    if (localeString.indexOf("_") < 0) {
      locale = new Locale(localeString);
    } else {
      String language = localeString.substring(0, localeString.indexOf("_"));
      String country = localeString.substring(localeString.indexOf("_") + 1);
      locale = new Locale(language, country);
    }

    return locale;
  }

  // TODO default to english
  /****************************************************************************************************************
   * Method Name: returnLocalizedMessage Parameters: messageString: messagekey in
   * iiqcustom.properties locale: either english string value of locale or actual
   * locale object
   * 
   * Description: Returns the translated message from the locale.
   ****************************************************************************************************************/
  String returnLocalizedMessage(String messageString, Object locale) {
    Locale localeObject = null;

    if (locale != null) {
      if (locale instanceof Locale) {
        localeObject = (Locale) locale;
      } else if (locale instanceof String) {
        localeObject = returnLocale(locale.toString());
      } else {
        return "Locale not correct";
      }

      return sailpoint.tools.Message.localize(messageString).getLocalizedMessage(localeObject, TimeZone.getDefault());
    }

    return "Locale not correct";
  }

}
