"use strict";
var seqApp = angular.module('sailpoint.plugin.sequencePlugin',
    [
        'ngTable',
        'ngResource',
    ]
).config(
    ['$locationProvider',
        function ($locationProvider) {
            $locationProvider.html5Mode({
                enabled: true,
                requireBase: false
            });
        }
    ]
);
