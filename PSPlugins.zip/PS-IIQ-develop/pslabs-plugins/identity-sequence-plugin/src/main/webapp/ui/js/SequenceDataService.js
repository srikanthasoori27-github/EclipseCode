/**
 *
 */
"use strict";
seqApp.factory('SequenceDataService', function ($http, $location) {
    var srv = {};

    // Service Implementations    	
    srv.getSequences = function () {
        var url = PluginHelper.getPluginRestUrl('sequence/list/all');
        var promise = $http.get(url).then(function (response) {
            var result = angular.copy(response.data.objects);
            //console.log( result );
            return result;
        });
        return promise;

    };
    srv.deleteSequence = function (tenant, name) {
        var url = PluginHelper.getPluginRestUrl('sequence/delete/' + tenant + '/' + name);
        return $http.post(url).then(function (result) {
            return {};
        });
    };
    srv.updateSequence = function (tenant, name, start) {
        var postConfig = {
            headers: {
                'X-XSRF-TOKEN': PluginHelper.getCsrfToken(),
                'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'
            }
        };
        var url = PluginHelper.getPluginRestUrl('sequence/update/' + tenant + '/' + name);
        var postData = '&start=' + start;
        console.log("postUrl: " + url);
        //console.log("postConfig: "  + JSON.stringify(postConfig));
        return $http.post(url, postData, postConfig).then(function (result) {
            return {};
        });
    };

    srv.createSequence = function (tenant, name, prefix, postfix, prefill, start, length) {
        var postData;
        if (null != prefix) {
            postData = '&prefix=' + prefix;
        }
        if (null != postfix) {
            postData += '&postfix=' + postfix;
        }
        postData += '&prefill=' + prefill;
        postData += '&start=' + start;
        postData += '&length=' + length;
        var postConfig = {
            headers: {
                'X-XSRF-TOKEN': PluginHelper.getCsrfToken(),
                'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'
            }
        };
        var url = PluginHelper.getPluginRestUrl('sequence/create/' + tenant + '/' + name);
        console.log("postData: " + postData);
        console.log("url: " + url);
        //console.log("postConfig: "  + JSON.stringify(postConfig));

        return $http.post(url, postData, postConfig).then(function (result) {
            return {};
        });
    };


    // public API
    return {
        getSequences: function () {
            return srv.getSequences();
        },
        createSequence: function (tenant, name, prefix, postfix, prefill, start, length) {
            return srv.createSequence(tenant, name, prefix, postfix, prefill, start, length);
        },
        updateSequence: function (tenant, name, start) {
            return srv.updateSequence(tenant, name, start);
        },
        deleteSequence: function (tenant, name) {
            return srv.deleteSequence(tenant, name);
        }
    };
});