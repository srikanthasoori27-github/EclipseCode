"use strict";
seqApp.controller('sequenceController',
    function ($scope, $location, $http, $filter, NgTableParams, SequenceDataService) {
        //  debugger;

        this.$inject = ['$scope', '$location', 'filter', 'NgTableParams', 'ngTableGroupedList'];

        //$scope.sequences = SequenceDataService.getSequences(); 

        $scope.isCreateFlag = false;

        $scope.sequencesTableParams = new NgTableParams({
            page: 1,
            count: 10,
            group: 'tenant'
        }, {
            getData: function (params) {
                var promise = SequenceDataService.getSequences().then(function (data) {
                    console.log(data);
                    console.log("Length:" + data.length);
                    params.total(data.length);
                    return data.slice((params.page() - 1) * params.count(), params.page() * params.count());
                });
                return promise;
            }
        });

        $scope.cancel = function cancel() {
            console.info("Cancel");
            window.location.href = SailPoint.CONTEXT_PATH + '/systemSetup/index.jsf';
        };

        $scope.cancelEdit = function cancelEdit() {
            console.info("CancelEdit");
            // just reload 
            window.location.href = SailPoint.CONTEXT_PATH + '/plugins/pluginPage.jsf?pn=sequence';
        };


        $scope.create = function create() {
            console.info("Create");
            $scope.isCreateFlag = true;
        };

        $scope.save = function save(row) {
            console.info("Save");
            console.debug(row);
            // just reload 
            SequenceDataService.updateSequence(row.tenant, row.name, row.start);
            window.location.href = SailPoint.CONTEXT_PATH + '/plugins/pluginPage.jsf?pn=sequence';
        };

        $scope.del = function del(row) {
            console.info("Delete");
            console.debug(row);
            SequenceDataService.deleteSequence(row.tenant, row.name);
            window.location.href = SailPoint.CONTEXT_PATH + '/plugins/pluginPage.jsf?pn=sequence';
        };


        $scope.isSaving = function () {
            //console.log('isSaving');
            return false;
        };

        $scope.isCreate = function () {
            //console.log('isCreate: ' + $scope.isCreateFlag );
            return $scope.isCreateFlag;
        };

        $scope.cancelCreate = function () {
            $scope.isCreateFlag = false;
        };

        $scope.addSequence = function createSequence(row) {
            console.info("createSequence");
            console.log(row);
            SequenceDataService.createSequence(row.tenant, row.name, row.prefix, row.postfix, row.prefill, row.start, row.length)
            $scope.isCreateFlag = false;
            window.location.href = SailPoint.CONTEXT_PATH + '/plugins/pluginPage.jsf?pn=sequence';
        };

    });
