console.log("Loading applicationRequestModule.js");

/**
 * Create the module.
 */

var myApp = angular.module('ApplicationRequest', ['ui.bootstrap',
    'sailpoint.i18n', 'sailpoint.comment', 'sailpoint.email',
    'sailpoint.esig', 'sailpoint.identity.account', 'sailpoint.modal',
    'sailpoint.util', 'sailpoint.tree', 'sailpoint.ui.bootstrap.carousel',
    'sailpoint.dataview', 'sailpoint.config', 'sailpoint.search']);

myApp.config(['$httpProvider', function ($httpProvider) {
    $httpProvider.defaults.xsrfCookieName = "CSRF-TOKEN";
}])

myApp
    .controller(
        'applicationRequestControler',
        function ($rootScope, $scope, $http, $q, navigationService,
                  $uibModal) {
            // console.log("Starting applicationRequestControler");

            $scope.isLoaded = false;
            
            /* paggination */
            if (localStorage.getItem("itemPerPage") === null) {
              localStorage.setItem("itemPerPage", 8);
            }
            function getPerPage(){		
              return parseInt(localStorage.itemPerPage);
            }
            $scope.changeNum = function (itemNum) {
              localStorage.itemPerPage = itemNum;
              $scope.numPerPage = getPerPage();
            };
            $scope.pageChanged = function() {
              // Equivalent to console.log
            };

            $scope.numsForPage = [4, 8, 12, 24, 48];
            $scope.pagination = {
               currentPage:  1,
               maxSize: 4
            };
            $scope.numPerPage = getPerPage();
            $scope.filteredTodos = [];
            $scope.filteredlist;

            //var applications = [];
            var config = {
                headers: {
                    'X-XSRF-TOKEN': PluginHelper.getCsrfToken()
                }
            }, promises;

            $scope.deleteIcon = PluginHelper.getPluginFileUrl(
                'iiqpluginapplicationrequest',
                'ui/images/delete.png');

            $scope.editIcon = PluginHelper.getPluginFileUrl(
                'iiqpluginapplicationrequest',
                'ui/images/edit.png');
            
            $scope.popoutIcon = PluginHelper.getPluginFileUrl(
                'iiqpluginapplicationrequest',
            	'ui/images/popout.png');
            
            $scope.types = [{
                displayName: 'Loading...',
                id: 'Loading...'
            }];
            // Calling this function when the application type is changed
            $scope.changeType = function () {
                config.params = {};
                config.params.filter = this.applicationFilterInput;
                if (this.AppType != null && this.AppType != '--') {
                    $http
                        .get(
                            PluginHelper
                                .getPluginRestUrl('iiqpluginapplicationrequest/searchByType/'
                                    + encodeURIComponent(this.AppType)
                                    + "/"), config)
                        .then(function (response) {
                            // console.log("Got a response for change type");
                            // console.log(response);
                            $scope.applications = response.data;
                            $scope.totalItems = $scope.applications.length;
                            $scope.isLoaded = true;
                        });
                } else {
                    $http
                        .get(
                            PluginHelper
                                .getPluginRestUrl('iiqpluginapplicationrequest/search'),
                            config).then(function (response) {
                        // console.log("Got a response for change type");
                        // console.log(response);
                        $scope.applications = response.data;
                        $scope.totalItems = $scope.applications.length;
                        $scope.isLoaded = true;
                    });
                }
            };
            // Calling that function when the search is needed
            $scope.search = function (event) {
                // console.log("Starting search with filter: #" +
                // this.applicationFilterInput+ "# and type: #" +
                // this.AppType + "#");
                // console.log(this.AppType);
                if (event == null || event.key == "Enter") {
                    //console.log("A search has been requested.");
                    config.params = {};
                    config.params.filter = this.applicationFilterInput;
                    if (this.AppType != null && this.AppType != '--') {
                        $http
                            .get(
                                PluginHelper
                                    .getPluginRestUrl('iiqpluginapplicationrequest/searchByType/'
                                        + encodeURIComponent(this.AppType)
                                        + "/"), config)
                            .then(
                                function (response) {
                                    //console.log("Got a response for search by type");
                                    // console.log(response);
                                    $scope.applications = response.data;
                                    $scope.totalItems = $scope.applications.length;
                                    $scope.isLoaded = true;
                                });
                    } else {
                        $http
                            .get(
                                PluginHelper
                                    .getPluginRestUrl('iiqpluginapplicationrequest/search'),
                                config)
                            .then(
                                function (response) {
                                    // console.log("Got a response for search");
                                    // console.log(response);
                                    $scope.applications = response.data;
                                    $scope.totalItems = $scope.applications.length;
                                    //console.log("search: "+$scope.totalItems);
                                    $scope.isLoaded = true;
                                });
                    }
                } else {
                    // console.log("No search tiggered...")
                }
            };

            $scope.filteredlist =$scope.applications;

            // Redirecting the user to the relevant page
            $scope.goToUrl = function (url) {
                // console.log("goToUrl: " + url);
                //if (url.includes("${selectedIdentityName}")) {
            	if (includes(url,"${selectedIdentityName}")) {
                    while ($scope.filter == "loading") {
                        // console.log("Waiting to get the Identity filter....");
                        sleep(100);
                    }
                    $scope.selectIdentity(url, $scope.filter);
                } else {
                    $scope.navigateTo(url);
                }
            };

            $scope.navigateTo = function (url) {
                navigationService.go({
                    url: url
                });
            };

            // Getting the request paramenters
            function getRequestParameter(name) {
                if (name = (new RegExp('[?&]'
                    + encodeURIComponent(name) + '=([^&]*)'))
                    .exec(location.search))
                    return decodeURIComponent(name[1]);
            }

            // Confirm deletion by calling a modal confirmation pop up
            $scope.confirmDelete = function (myAppName) {
                // console.log("Calling delete confirm for " + myAppName);
                $uibModal
                    .open({
                        animation: false,
                        controller: 'confirmApplicationDeletionControler as ctrl',
                        templateUrl: PluginHelper
                            .getPluginFileUrl(
                                'iiqpluginapplicationrequest',
                                'ui/html/modal-template.html'),
                        resolve: {
                            applicationName: function () {
                                return myAppName;
                            }
                        }
                    });
            };
            
            $scope.openExternal = function (link){
            	//console.log("Open external link: "+link);
            	var redirectWindow = window.open(link, '_blank');
                redirectWindow.location;
            };

            // Edit existing application definition
               $scope.openEdit = function (myAppName) {
                   //console.log("Calling modal to edit application named: "+myAppName);
                   //var escapedAppName = escape(myAppName);
                   //console.log("Escaped application name: "+myAppName);
                   //console.log("URL: " + 'iiqpluginapplicationrequest/applications/'+ encodeURIComponent(myAppName));

                   $http.get(
                       PluginHelper
                           .getPluginRestUrl('iiqpluginapplicationrequest/applications/'+ encodeURIComponent(myAppName)),
                       config).then(function (response) {
   		                //console.log("Got a response for get app to edit");
   		                //console.log(response);
   		                var appToEdit = response.data;
   		                $uibModal.open({
   		                    animation: false,
   		                    controller: 'editApplicationControler as ctrl',
   		                    templateUrl: PluginHelper.getPluginFileUrl(
   		                        'iiqpluginapplicationrequest',
   		                        'ui/html/modal-add.html'),
   		                    resolve: {
   		                    	appObj: function () {
   		                            return appToEdit;
   		                        }
   		                    }
   		                });
   		            },function (error){
   		                //console.log(error, 'can not get data.');
   		            });
               };
               
               function includes(container, value) {
            	   //console.log("includes for IE");
            		var returnValue = false;
            		var pos = container.indexOf(value);
            		if (pos >= 0) {
            			returnValue = true;
            		}
            		return returnValue;
            	}

             //Call this function to look for the application by name
               function getApp(applicationName) {
               	//console.log("GetApp URL: " + 'iiqpluginapplicationrequest/applications/'+ encodeURIComponent(applicationName));
               	$http
   	                .get(
   	                    PluginHelper
   	                        .getPluginRestUrl('iiqpluginapplicationrequest/applications/'+ encodeURIComponent(applicationName)),
   	                    config).then(function (response) {
   			                //console.log("Got a response for get app");
   			               // console.log(response);
   			                $scope.newApp = response.data;
   			            });

               }

            // Add a new application definition
            $scope.addNew = function () {
                // console.log("Calling modal to add a new application");
                $uibModal.open({
                    animation: false,
                    controller: 'addNewApplicationControler as ctrl',
                    templateUrl: PluginHelper.getPluginFileUrl(
                        'iiqpluginapplicationrequest',
                        'ui/html/modal-add.html')
                });
            };

            // Select Identity
            $scope.selectIdentity = function (inputUrl, inputFilter) {
                if (inputFilter == "self") {
                    // console.log("Only self service available, doing the substitution.");
                    inputUrl = inputUrl.replace(
                        "${selectedIdentityName}",
                        encodeURIComponent(PluginHelper
                            .getCurrentUsername()));
                    $scope.navigateTo(inputUrl);
                } else {
                    // console.log("Calling modal to select identity");
                    $uibModal.open({
                        animation: false,
                        controller: 'selectIdentityControler as ctrl',
                        templateUrl: PluginHelper.getPluginFileUrl(
                            'iiqpluginapplicationrequest',
                            'ui/html/modal-selectIdentity.html'),
                        resolve: {
                            url: function () {
                                return inputUrl;
                            },
                            filter: function () {
                                return inputFilter;
                            }
                        }
                    });
                }

            };

            // Calling this function when new application request need
            // to be added
            $scope.toggleAdd = function () {
                // console.log("toggleAdd: " + document.getElementById("addDiv").style.display);
                document.getElementById("addDiv").style.display = "block";
                // console.log("toggleAdd: " + document.getElementById("addDiv").style.display);
            };


            // Getting all_applications types and user permissions in the pageConfig object
            $http
                .get(
                    PluginHelper
                        .getPluginRestUrl('iiqpluginapplicationrequest/types'))
                .then(
                    function (response) {
                         //console.log("Got a response for all_applications types isLoaded " + $scope.isLoaded);
                         //console.log(response);
                        $scope.types = response.data;
                        $http
                            .get(
                                PluginHelper
                                    .getPluginRestUrl('iiqpluginapplicationrequest/pageConfig'))
                            .then(
                                function (response2) {
                                     //console.log("Got a response for page config");
                                     //console.log(response2);
                                    $scope.pageConfig = response2.data;
                                    var requestTypeParam = getRequestParameter("type");
                                    var requestFilterParam = getRequestParameter("filter");
                                    
                                    if (requestTypeParam != undefined) {
                                        $scope.types
                                            .forEach(function (
                                                typ) {
                                                if (typ.id == requestTypeParam) {
                                                    // console.log("We got a match from an existing application type: " + typ.id);
                                                    $scope.AppType = typ.id;
                                                    $("#dropdownApplicationType > div > div > input").val(typ.id);

                                                    if (requestFilterParam != undefined) {
                                                        // console.log("There is a filter in the request params: " + requestFilterParam);
                                                        $scope.applicationFilterInput = requestFilterParam;
                                                    }
                                                    $scope.changeType();
                                                } else {
                                                    // console.log("No match with: " + typ.id);
                                                }
                                            });
                                    } else if (requestFilterParam != undefined) {
                                        // console.log("There is a filter in the request params: " + requestFilterParam);
                                        $scope.applicationFilterInput = requestFilterParam;
                                        $scope.changeType();
                                    } else {
                                    	//console.log("Here was the error:");
                                    	$scope.AppType = "Home";
                                        $("#dropdownApplicationType > div > div > input").val("Home");
                                        $scope.changeType();
                                    }
                                    
                                    $scope.isLoaded = true;
                                    $scope.search(null);
                                    // Getting the identity filter
                                    $scope.filter = "loading";
                                    if (!$scope.pageConfig.isAdmin) {
                                        $http
                                            .get(
                                                PluginHelper
                                                    .getPluginRestUrl('iiqpluginapplicationrequest/identitiesFilter'))
                                            .then(
                                                function (
                                                    response3) {
                                                    //console.log(response3);
                                                    $scope.filter = response3.data;
                                                });
                                    } else {
                                        $scope.filter = "";
                                    }
                                });
                    });

            // getting arent history
            var historyList = getRequestParameter("history");
            if (historyList != undefined) {
                $scope.history = "";
                historyTab = historyList.split(",");
                historyTab
                    .forEach(function (history) {
                        if (historyList.substr(0, historyList
                            .indexOf(history) - 1).length > 0) {
                            newHistory = "&history="
                                + historyList
                                    .substr(
                                        0,
                                        historyList
                                            .indexOf(history) - 1);
                        } else {
                            newHistory = "";
                        }
                        $scope.history += "> <a href='"
                            + SailPoint.CONTEXT_PATH
                            + "/plugins/pluginPage.jsf?pn=iiqpluginapplicationrequest&type="
                            + history + newHistory + "'>"
                            + history + "</a> ";
                    });

            }

            $rootScope.$on('refreshSearch', function (event) {
                $scope.search(null);
            })

            $rootScope.$on('moveOn', function (event, url) {
                $scope.navigateTo(url);
            })

        }).filter('pagination', function() {
      	  return function(input, currentPage, pageSize) {
      	    if(angular.isArray(input)) {
      	      var start = (currentPage-1)*pageSize;
      	      var end = currentPage*pageSize;
      	      return input.slice(start, end);
      	    }
      	  };
      	});;

/**
 * The controller for the confirm deletion modal windows.
 */
myApp
    .controller(
        'confirmApplicationDeletionControler',
        function ($rootScope, $uibModalInstance, applicationName) {

            var me = this;
            me.applicationName = applicationName;
            me.close = function () {
                $uibModalInstance.close();
            };
            me.confirm = function () {
                confirmDelete();
                $uibModalInstance.close();
            };

            // Calling this function when deleting an application
            function confirmDelete() {
                // console.log("Deleting " + applicationName);
                $
                    .ajax({
                        url: PluginHelper
                            .getPluginRestUrl('iiqpluginapplicationrequest/applications/'
                                + encodeURIComponent(applicationName)),
                        type: 'DELETE',
                        headers: {
                            'X-XSRF-TOKEN': PluginHelper
                                .getCsrfToken()
                        },
                        data: {
                            'name': applicationName
                        },
                        success: function (dataDelete) {
                            // console.log("Application Request
                            // Definition: " + name + " deleted.");
                            location.reload(true);
                        }
                    });
            }
            ;
        });

/**
 * The controller for the add new application modal windows.
 */
myApp
    .controller(
        'addNewApplicationControler',
        function ($rootScope, $scope, $http, $uibModalInstance) {
            var me = this;
            $scope.newApp = {
                name: null,
                link: null
            }
            
            $scope.modalTitle = 'Create new Business Application definition';
            $scope.modalActionBtn = 'Add New Application';
            
            me.close = function () {
                $uibModalInstance.close();
            };
            me.confirm = function () {
                createNew();
                $uibModalInstance.close();
            };

            // Calling this function when deleting an application
            function createNew() {
                if ($scope.newApp.name != null
                    && $scope.newApp.link != null) {
                    // console.log("createNew");
                    // console.log($scope.newApp);
                    $http
                        .post(
                            PluginHelper
                                .getPluginRestUrl('iiqpluginapplicationrequest/applications'),
                            $scope.newApp)
                        .then(function (response) {
                            // console.log("Got a response for add
                            // new");
                            // console.log(response);
                            location.reload(true);
                            $scope.alertClass = 'alert-success';
                        	$scope.alertMssg = 'Successfully created New Application!!';
                        	$('#alertDiv').show();
                        });
                }
            }
            ;
        });

/**
 * The controller for the edit application modal window.
 */
myApp
    .controller(
        'editApplicationControler',
        function ($rootScope, $scope, $http, $uibModalInstance, appObj) {
            var me = this;
            //console.log("Got a response for edit in controller"+appObj);

            me.applicationName = appObj.name;

            $scope.newApp = appObj;
            //console.log("newApp in scope "+$scope.newApp);

            $scope.modalTitle = 'Edit Existing Application definition';
            $scope.modalActionBtn = 'Edit Application';

            me.close = function () {
                $uibModalInstance.close();
            };
            me.confirm = function () {
            	//console.log("oldName:  "+me.applicationName);
                editApp();
                $uibModalInstance.close();
            };


            // Calling this function when editing an application
            function editApp() {
            	 //console.log("In editApp "+appObj);
                if ($scope.newApp.name != null
                    && $scope.newApp.link != null) {
                    //console.log("app.oldname::: "+me.applicationName);
                    $http
                        .post(
                            PluginHelper
                                .getPluginRestUrl('iiqpluginapplicationrequest/applications/'+ encodeURIComponent(me.applicationName)),
                            $scope.newApp)
                        .then(function (response) {
                            // console.log("Got a response for edit ");
                            //console.log("response::  " +response);
                            location.reload(true);
                        }).catch(function() {
                        	//console.log("Error while trying to EDIT Application!!" );
                        	$scope.alertClass = 'alert-danger';
                        	$scope.alertMssg = 'Error while trying to EDIT Application!!';
                        	$('#alertDiv').show();
                        });
                }
            }
    });

/**
 * The controller for the select Identity modal windows.
 */
myApp.controller('selectIdentityControler', function ($rootScope, $scope,
                                                      $uibModalInstance, url, filter) {

    var me = this;
    $scope.filter = filter;
    me.close = function () {
        $uibModalInstance.close();
    };

    me.confirm = function () {
        $uibModalInstance.close();
        url = url.replace("${selectedIdentityName}",
            encodeURIComponent($scope.selectedIdentity.name));
        $rootScope.$broadcast('moveOn', url);
    };
});
