# Introduction

This project serves as a master project for modules related to creating reusable artifacts for the PS Labs.

#### Getting started
Please refer to the [Wiki](https://github.com/sailpoint/iiq-siq/wiki) pages on [Getting-Started](https://github.com/sailpoint/iiq-siq/wiki/Getting-Started)