#!/bin/bash
# This script will install the following Maven plugins locally.
# These plugins assist in the build of an IdentityIQ implementation project.

# Original Author: Indranil Chakraborty (indranil.chakraborty@sailpoint.com)
# Version: 0.1
# Date: 30-Jun-2020

# Usage:
# 1. Set the values for the below properties
# 2. Ensure that the execution environment has Maven installed and configured to write to the target repository
# 3. Execute script

# Note that the environment on which this script is run must have Maven in the path and
# the Maven settings.xml must have the target repository configured with write access to it.

### DO NOT CHANGE ANYTHING BELOW THIS LINE
# ****************************************

# The base directory in which the helper zip files are present
export BINARIES_PATH=.

# Clean up existing installs
rm -rf ~/.m2/repository/sailpoint/identityiq-config-files-helper-plugin
rm -rf ~/.m2/repository/sailpoint/identityiq-implementation-archetype
rm -rf ~/.m2/repository/sailpoint/junit-helper
rm -rf ~/.m2/repository/sailpoint/identityiq-plugin-archetype
rm -rf ~/.m2/repository/sailpoint/pse/devsecops/scm-change-detector-plugin

# Install the Maven plugins locally
mvn install:install-file -DgroupId=sailpoint -DartifactId=identityiq-config-files-helper-plugin -Dversion=1.0.0 -Dpackaging=jar -Dfile=$BINARIES_PATH/identityiq-config-files-helper-plugin-1.0.0.jar
mvn install:install-file -DgroupId=sailpoint -DartifactId=junit-helper -Dversion=1.0.0 -Dpackaging=jar -Dfile=$BINARIES_PATH/junit-helper-1.0.0.jar

mvn install:install-file -DgroupId=sailpoint -DartifactId=services-tools -Dversion=1.0.0 -Dpackaging=jar -Dfile=$BINARIES_PATH/services-tools.jar
mvn install:install-file -DgroupId=sailpoint -DartifactId=identityiq-implementation-archetype -Dversion=1.0.0 -Dpackaging=jar -Dfile=$BINARIES_PATH/identityiq-implementation-archetype-1.0.0.jar
mvn install:install-file -DgroupId=sailpoint -DartifactId=identityiq-plugin-archetype -Dversion=0.1 -Dpackaging=jar -Dfile=identityiq-plugin-archetype-0.1.jar
mvn install:install-file -DgroupId=sailpoint.pse.devsecops -DartifactId=scm-change-detector-plugin -Dversion=1.0.0-SNAPSHOT -Dpackaging=jar -Dfile=$BINARIES_PATH/scm-change-detector-plugin-1.0.0-SNAPSHOT.jar
