#!/bin/bash
# This script will upload all jar files in the WEB-INF/lib directory of an IdentityIQ release
# to a repository using the mvn:deploy command.

# Original Author: Indranil Chakraborty (indranil.chakraborty@sailpoint.com)
# Version: 0.1
# Date: 08-May-2020

# Author: Saikiran Revuru (saikiran.revuru@sailpoint.com)
# Version: 0.2
# Date: 15-February-2021
# Added code to upload minor patches and SailPointBundleLibrary js as dependencies

# Usage:
# 1. Set the values for the below properties
# 2. Ensure that the execution environment has Maven installed and configured to write to the target repository
# 3. Execute script

# The version of IdentityIQ; this is used to determine which zip file to extract and is used as a namespace separator
export IIQ_BASE_VERSION=8.1
export IIQ_PATCH_VERSION=p1

# The base, patch directories in which the IdentityIQ zip files are present
export IIQ_BASE_SOFTWARE_PATH=/Users/saikiran.revuru/git/iiq-binaries/base/ga
export IIQ_PATCH_SOFTWARE_PATH=/Users/saikiran.revuru/git/iiq-binaries/base/patch

# A working directory into which content is extracted; a subdirectory with version specific directory will be created under this base directory
# The sub working directory will be cleaned up later
export EXPORT_DIR=/Users/saikiran.revuru/sai/temp/iiqlibs

# Below are calculated from earlier values
export IIQ_BASE_ZIP_FILE=$IIQ_BASE_SOFTWARE_PATH/identityiq-${IIQ_BASE_VERSION}.zip

# Check the patch
if [ -z "${IIQ_PATCH_VERSION}" ]; then
	export IIQ_MAVEN_VERSION=${IIQ_BASE_VERSION}
	echo "No patch specified. Uploading for base version"
else
	export IIQ_MAVEN_VERSION=${IIQ_BASE_VERSION}"."$(sed 's/^.//' <<<${IIQ_PATCH_VERSION})
	export IIQ_PATCH_FILE=$IIQ_PATCH_SOFTWARE_PATH/identityiq-${IIQ_BASE_VERSION}${IIQ_PATCH_VERSION}.jar
fi

# Create the EXPORT_DIR
echo 'Deleting contents of ' $EXPORT_DIR/${IIQ_MAVEN_VERSION}
rm -rf $EXPORT_DIR/${IIQ_MAVEN_VERSION}
mkdir -p $EXPORT_DIR/${IIQ_MAVEN_VERSION}

# Extract to the EXPORT_DIR
unzip -q -o -d $EXPORT_DIR/${IIQ_MAVEN_VERSION} $IIQ_BASE_ZIP_FILE

# Extract the war file
unzip -q -o -d $EXPORT_DIR/${IIQ_MAVEN_VERSION} $EXPORT_DIR/${IIQ_MAVEN_VERSION}/identityiq.war WEB-INF/lib/*.jar

# Extract SailPointBundleLibrary
unzip -q -o -d $EXPORT_DIR/${IIQ_MAVEN_VERSION} $EXPORT_DIR/${IIQ_MAVEN_VERSION}/identityiq.war ui/js/bundles/SailPointBundleLibrary.js

# Apply the patch
if [ -z "${IIQ_PATCH_VERSION}" ]; then
	echo "Skipping patch extraction"
else
	echo "Extracting patch to " $EXPORT_DIR/${IIQ_MAVEN_VERSION} " from " $IIQ_PATCH_FILE
	unzip -q -o -d $EXPORT_DIR/${IIQ_MAVEN_VERSION} $IIQ_PATCH_FILE WEB-INF/lib/*.jar
    
    # If there is a patch, use the SailPointBundleLibrary from the patch
	unzip -q -o -d $EXPORT_DIR/${IIQ_MAVEN_VERSION} $IIQ_PATCH_FILE ui/js/bundles/SailPointBundleLibrary.js
fi

# Upload each file to the repository
for filename in $EXPORT_DIR/${IIQ_MAVEN_VERSION}/WEB-INF/lib/*.jar; do
    fname=`basename $filename .jar`
	mvn install:install-file -DgroupId=sailpoint -DupdateReleaseInfo=true -DartifactId=$fname -Dversion=${IIQ_MAVEN_VERSION} -Dpackaging=jar -Dfile=$filename 
done

# Upload each js file to the repository
# For now this will be one file, but later this can be many
for filename in $EXPORT_DIR/${IIQ_MAVEN_VERSION}/ui/js/bundles/*.js; do
    fname=`basename $filename .js`
	mvn install:install-file -DgroupId=sailpoint -DupdateReleaseInfo=true -DartifactId=$fname -Dversion=${IIQ_MAVEN_VERSION} -Dpackaging=js -Dfile=$filename 
done


# Create a BOM file, the quick and dirty way
echo "<?xml version=\"1.0\" encoding=\"UTF-8\"?><project xmlns=\"http://maven.apache.org/POM/4.0.0\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xsi:schemaLocation=\"http://maven.apache.org/POM/4.0.0 http://maven.apache.org/xsd/maven-4.0.0.xsd\"><modelVersion>4.0.0</modelVersion><groupId>sailpoint</groupId><artifactId>iiq-bom</artifactId><version>${IIQ_MAVEN_VERSION}</version><packaging>pom</packaging><name>IIQ BOM</name><description>IdentityIQ Bill of Material</description><dependencies>" > $EXPORT_DIR/${IIQ_MAVEN_VERSION}/pom.temp

for filename in $EXPORT_DIR/${IIQ_MAVEN_VERSION}/WEB-INF/lib/*.jar; do
   fname=`basename $filename .jar`
   echo "<dependency>" >> $EXPORT_DIR/${IIQ_MAVEN_VERSION}/pom.temp
   echo "<groupId>sailpoint</groupId>" >> $EXPORT_DIR/${IIQ_MAVEN_VERSION}/pom.temp
   echo "<artifactId>${fname}</artifactId>" >> $EXPORT_DIR/${IIQ_MAVEN_VERSION}/pom.temp
   echo "<version>${IIQ_MAVEN_VERSION}</version>" >> $EXPORT_DIR/${IIQ_MAVEN_VERSION}/pom.temp
   echo "</dependency>" >> $EXPORT_DIR/${IIQ_MAVEN_VERSION}/pom.temp
done

# Add the js dependency
for filename in $EXPORT_DIR/${IIQ_MAVEN_VERSION}/ui/js/bundles/*.js; do
   fname=`basename $filename .js`
   echo "<dependency>" >> $EXPORT_DIR/${IIQ_MAVEN_VERSION}/pom.temp
   echo "<groupId>sailpoint</groupId>" >> $EXPORT_DIR/${IIQ_MAVEN_VERSION}/pom.temp
   echo "<artifactId>${fname}</artifactId>" >> $EXPORT_DIR/${IIQ_MAVEN_VERSION}/pom.temp
   echo "<version>${IIQ_MAVEN_VERSION}</version>" >> $EXPORT_DIR/${IIQ_MAVEN_VERSION}/pom.temp
   echo "<type>js</type>" >> $EXPORT_DIR/${IIQ_MAVEN_VERSION}/pom.temp
   echo "</dependency>" >> $EXPORT_DIR/${IIQ_MAVEN_VERSION}/pom.temp
done

echo "</dependencies></project>" >> $EXPORT_DIR/${IIQ_MAVEN_VERSION}/pom.temp

# Pretty print and store the output
cat $EXPORT_DIR/${IIQ_MAVEN_VERSION}/pom.temp | xmllint --format - | tee $EXPORT_DIR/${IIQ_MAVEN_VERSION}/pom.xml

# Upload the BOM pom.xml to the repo
mvn install:install-file -DgroupId=sailpoint -DartifactId=iiq-bom -Dversion=${IIQ_MAVEN_VERSION} -DupdateReleaseInfo=true -Dpackaging=pom -Dfile=$EXPORT_DIR/${IIQ_MAVEN_VERSION}/pom.xml 

# Delete the working directory
rm -rf $EXPORT_DIR/${IIQ_MAVEN_VERSION}