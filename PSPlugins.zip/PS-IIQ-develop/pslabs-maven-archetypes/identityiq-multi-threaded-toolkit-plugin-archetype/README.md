#Usage

Use the below command to create a new IdentityIQ plugin project that will leverage the Multi-Threaded toolkit. You may replace the values for groupId, artifactId and version with values suitable for your implementation.

```shell script
mvn -U archetype:generate -DgroupId=sailpoint -DartifactId=mtt-plugin -Dversion=0.1 -DarchetypeGroupId=sailpoint -DarchetypeArtifactId=identityiq-multi-threaded-toolkit-plugin-archetype -DarchetypeVersion=0.1 -DinteractiveMode=false
```