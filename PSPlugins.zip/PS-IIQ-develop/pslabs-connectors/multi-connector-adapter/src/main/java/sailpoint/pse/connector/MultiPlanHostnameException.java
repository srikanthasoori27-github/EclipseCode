/**
 * 
 */
package sailpoint.pse.connector;

import sailpoint.tools.GeneralException;
import sailpoint.tools.Message;

/**
 * @author menno.pieters@sailpoint.com
 *
 */
public class MultiPlanHostnameException extends GeneralException {

	/**
	 * 
	 */
	private static final long serialVersionUID = -4218349865542298147L;

	/**
	 * 
	 */
	public MultiPlanHostnameException() {
		super();
	}

	/**
	 * @param message
	 */
	public MultiPlanHostnameException(String message) {
		super(message);
	}

	/**
	 * @param t
	 */
	public MultiPlanHostnameException(Throwable t) {
		super(t);
	}

	/**
	 * @param message
	 */
	public MultiPlanHostnameException(Message message) {
		super(message);
	}

	/**
	 * @param message
	 * @param t
	 */
	public MultiPlanHostnameException(String message, Throwable t) {
		super(message, t);
	}

	/**
	 * @param message
	 * @param t
	 */
	public MultiPlanHostnameException(Message message, Throwable t) {
		super(message, t);
	}

}
