/**
 * 
 */
package sailpoint.pse.connector;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Queue;
import java.util.Set;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.log4j.Logger;

import sailpoint.api.Aggregator;
import sailpoint.api.ObjectUtil;
import sailpoint.api.PersistenceManager;
import sailpoint.api.Provisioner;
import sailpoint.api.SailPointContext;
import sailpoint.api.SailPointFactory;
import sailpoint.connector.AbstractConnector;
import sailpoint.connector.Connector;
import sailpoint.connector.ConnectorException;
import sailpoint.connector.ConnectorFactory;
import sailpoint.connector.ConnectorProxy;
import sailpoint.object.Application;
import sailpoint.object.AttributeDefinition;
import sailpoint.object.Attributes;
import sailpoint.object.Configuration;
import sailpoint.object.Custom;
import sailpoint.object.Filter;
import sailpoint.object.Identity;
import sailpoint.object.Link;
import sailpoint.object.Partition;
import sailpoint.object.ProvisioningPlan;
import sailpoint.object.ProvisioningPlan.AbstractRequest;
import sailpoint.object.ProvisioningPlan.AccountRequest;
import sailpoint.object.ProvisioningPlan.AttributeRequest;
import sailpoint.object.ProvisioningPlan.ObjectRequest;
import sailpoint.object.ProvisioningProject;
import sailpoint.object.ProvisioningResult;
import sailpoint.object.QueryOptions;
import sailpoint.object.Resolver;
import sailpoint.object.ResourceObject;
import sailpoint.object.Rule;
import sailpoint.object.Schema;
import sailpoint.tools.CloseableIterator;
import sailpoint.tools.GeneralException;
import sailpoint.tools.Util;

/**
 * @author menno.pieters
 * 
 * 2020.01.08-0001: Group Provisioning works
 * 2020.01.09-0002: Account Provisioning works
 * 2020.01.28-0001: Sanity checks, tooling
 * 2020.01.31-0001: Basic connector done. 
 * 2020.02.01-0001: to be done: multi-threaded provisioning
 * 2020:04:29-0012: Aggregation retries
 * 2020.04.30-0001: Delta Aggregation Filter and support Delta+Partitioning
 * 2020.04.30-0002: List of systems to test during test connection
 * 2020.05.01-0001: Improved delta/test filtering
 * 2020.05.01-0005: Retryable aggregation errors configurable
 * 2020.05.04-0002: Initial threaded provisioning
 * 2020.05.07-0001: Added multi-threading for group provisioning
 * 2020.05.08-0001: Removed requirement to get template from the ConnectorRegistry
 * 2020.05.13-0001: Using ConnectorFactory with getInternalConnector
 * 2020.05.19-0001: Fix in BACKSLASH regex
 * 2020.05.20-0003: Fix in Format processing
 * 2020.05.20-0004: Initial attempt to save failed aggregations 
 * 2020.05.22-0008: Save and use information about failed and succeeded aggregations
 * 2020.05.28-0002: Fix for aggregation - never-ending loop, no longer calling hasNext in next to fix issue with delimited files
 * 2020.10.20-0001: SailPointContext no longer used in multi-threaded provisioner class
 * 2020.11.06-0001: Prevent passwords from being persisted in Custom object
 * 2021.02.10-0001: Catch exception on search for IDN
 * 2021.02.10-0003: Context handling for threads
 * 2021.02.25-0005: Explicitly call destroy() on the real connector, close iterator properly before creating the new one.
 * 2021.02.26-0001: Reset failures was done at the wrong moment for non-partitioned aggregations.
 * 2021.03.26-0001: Potential null pointer exception on test connection with incomplete configuration fixed.
 * 2021.05.01-0001: Fix in HASH regex
 */
public class MultiConnectorAdapter extends AbstractConnector {

	public final static String VERSION = "2021.05.05-0001";

	public final static String CONNECTOR_TYPE = "Multi Connector Adapter";

	public final static String ARG_APP_TEMPLATE = "multiApplicationTemplate";
	public final static String ARG_APP_CONNECTOR = "multiApplicationRealConnector";
	public final static String ARG_CONFIG_CUSTOM = "multiConfigurationCustom";
	public final static String ARG_CONFIG_RULE = "multiConfigurationRule";
	public final static String ARG_CREDENTIAL_RULE = "multiCredentialRule";
	public final static String ARG_OBJECT_NAME_FORMAT = "multiObjectNameFormat";
	public final static String ARG_MAX_TEST_CONNECTIONS = "multiMaxTestConnections";
	public final static String ARG_TEST_CONNECTION_HOSTS = "multiTestConnectionFilter";
	public final static String ARG_CHANGE_DISPLAY_NAME = "multiChangeDisplayName";
	public final static String ARG_SERVER_CONFIG_MAP = "multiServerConfigurationMap";
	public final static String ARG_SKIP_CHECK_AUTOCORRECTED = "multiSkipCheckAutoCorrected";
	public final static String ARG_MAX_AGGREGATION_RETRIES = "multiMaxAggregationRetries";
	public final static String ARG_DELAY_AGGREGATION_EXCEPTIONS = "multiDelayAggregationExceptions";
	public final static String ARG_DELTA_AGGREGATION_FILTER = "multiDeltaAggregationFilter";
	public final static String ARG_DELTA_AGGREGATION_FAILED = "multiDeltaAggregationIncludeFailed";
	public final static String ARG_DELTA_AGGREGATION_AGED = "multiDeltaAggregationIncludeAged";
	public final static String ARG_MAX_PROVISIONING_THREADS = "multiMaxProvisioningThreads";
	public final static String ARG_RETRYABLE_AGGREGATION_ERRORS = "multiRetryableAggregationErrors";
	
	public final static String ARG_REGISTER_AGGREGATION_RESULT = "multiRegisterAggregationResult";
	public final static String ARG_FAILED_AGGREGATIONS = "multiFailedAggregations";
	public final static String ARG_SUCCEEDED_AGGREGATIONS = "multiSucceededAggregations";
	
	public final static String ATTR_MULTI_HOSTID = "multiHostIdentifier";
	
	public final static String PLAN_ARG_AUTOCORRECTED = "multiPlanAutoCorrected";
	
	private Custom configurationCustom = null;
	private Application applicationTemplate = null;	
	private ObjectNameFormat objectNameFormat = null;
	private List<Map<String,Object>> serverList = null;

	private int maxTestedConfigurations = 50;

	private final static Logger log = Logger.getLogger(MultiConnectorAdapter.class);
	private SailPointContext context = null;
	
	public static String[] EXCLUDED_ATTRIBUTES = { 
			"acctAggregationEnd", 
			"acctAggregationStart", 
			"deltaAggregation", 
			"multiConfigurationCustom", 
			"multiConfigurationRule", 
			"multiCredentialRule",
			"multiObjectNameFormat", 
			"multiApplicationTemplate",
			"multiMaxTestConnections",
			"multiChangeDisplayName",
			"multiServerConfigurationMap",
			"multiSkipCheckAutoCorrected",
			"multiMaxAggregationRetries",
			"multiDelayAggregationExceptions",
			"multiDeltaAggregationFilter",
			"multiMaxProvisioningThreads",
			"multiRetryableAggregationErrors"
		};

	/**
	 * @param application
	 * @throws GeneralException 
	 */
	public MultiConnectorAdapter(Application application) throws GeneralException {
		super(application);
		if (log.isDebugEnabled()) {
			log.debug(String.format("Constructor: MultiConnectorAdapter(%s)", application));
		}
		init();
	}
	
	/**
	 * 
	 * @param application
	 * @param instance
	 * @throws GeneralException
	 */
	private MultiConnectorAdapter(Application application, String instance) throws GeneralException {
		super(application, instance);
		if (log.isDebugEnabled()) {
			log.debug(String.format("Constructor: MultiConnectorAdapter(%s, %s)", application, instance));
		}
		init();
	}
	
	/**
	 * Initialize the application.
	 * @throws GeneralException 
	 */
	private void init() throws GeneralException {
		if (log.isDebugEnabled()) {
			log.debug("Enter: init()");
			log.debug(String.format("Connector version: %s", VERSION));
		}
		try {
			// Get SailPointContext
			if (log.isTraceEnabled()) log.trace("Getting context");
			context = SailPointFactory.getCurrentContext();
			// Custom object
			if (log.isTraceEnabled()) log.trace("Getting Custom object");
			getConfigurationCustom();
			// Object Name Format
			if (log.isTraceEnabled()) log.trace("Getting object name format");
			String formatName = this.getApplication().getStringAttributeValue(ARG_OBJECT_NAME_FORMAT);
			if (formatName != null) {
				try {
					this.objectNameFormat = ObjectNameFormat.valueOf(formatName);
					if (log.isTraceEnabled()) log.trace(String.format("Using object name format: %s", this.objectNameFormat));
				} catch (IllegalArgumentException e) {
					throw new GeneralException(String.format("Invalid object name format: %s", formatName), e);
				}
			} else {
				if (log.isTraceEnabled()) log.trace("Using default object name format");
				this.objectNameFormat = ObjectNameFormat.AT;
			}
			// Maximum number of connections to test
			int maxTestedConfigurations = this.getApplication().getIntAttributeValue(ARG_MAX_TEST_CONNECTIONS);
			if (maxTestedConfigurations > 0) {
				this.maxTestedConfigurations = maxTestedConfigurations;
				if (log.isTraceEnabled()) log.trace(String.format("Maximum configurations to test: %d", maxTestedConfigurations));
			}
		} catch (GeneralException e) {
			throw new GeneralException(String.format("Error during initialization: %s", e.getMessage()), e);
		}
	}
	
	/**
	 * Check whether Delta aggregation has been requested.
	 * 
	 * @param options
	 * @return
	 */
	protected static boolean isDelta(Map<String, Object> options) {
		if (log.isDebugEnabled()) {
			log.debug(String.format("Enter: isDelta(%s)", options));
		}
		return (options != null && options.containsKey(Aggregator.ARG_DELTA_AGGREGATION) && Util.otob(options.get(Aggregator.ARG_DELTA_AGGREGATION)));
	}
	
	/**
	 * Check whether or not the failures and successes from aggregation should be recorded.
	 * 
	 * NOTE: this should only be done in IdentityIQ, never in IdentityNow.
	 * 
	 * @return
	 */
	protected boolean shouldRegisterAggregationResult() {
		if (log.isDebugEnabled()) {
			log.debug("Enter: shouldRegisterAggregationResult()");
		}
		Application application = getApplication();
		Object value = application.getAttributeValue(ARG_REGISTER_AGGREGATION_RESULT);
		if (value != null) {
			return Util.otob(value);
		}
		return false;
	}
	
	/**
	 * If configured, get the list of server names for "delta" aggregation.
	 * 
	 * @return
	 */
	@SuppressWarnings("unchecked")
	protected List<String> getDeltaFilterList(String objectType) {
		if (log.isDebugEnabled()) {
			log.debug("Enter: getDeltaFilterList()");
		}
		Set<String> filterSet = new HashSet<String>();
		Application app = getApplication();
		
		// Get the configured list
		String filterStr = app.getStringAttributeValue(ARG_DELTA_AGGREGATION_FILTER);
		if (Util.isNotNullOrEmpty(filterStr)) {
			if (log.isTraceEnabled()) log.trace(String.format("Configurations for delta: %s", filterStr));	
			filterSet.addAll(Util.csvToList(filterStr.toLowerCase()));
		}
		
		// Check for previous failures
		boolean includeFailed = app.getBooleanAttributeValue(ARG_DELTA_AGGREGATION_FAILED);
		if (includeFailed) {
			if (log.isTraceEnabled()) {
				log.trace("getDeltaFilterList: including previously failed servers");
			}
			String key = String.format("%s.%s", ARG_FAILED_AGGREGATIONS, objectType);
			Attributes<String, Object> attributes = app.getAttributes();
			if (attributes.containsKey(key)) {
				List<String> failures = attributes.getList(key);
				if (failures != null && !failures.isEmpty()) {
					for (String failure: failures) {						
						filterSet.add(failure.toLowerCase());
					}
				}
			}
		}
		
		// Check for servers that have not been successfully aggregated in X days
		int includeAge = app.getIntAttributeValue(ARG_DELTA_AGGREGATION_AGED);
		if (includeAge > 0) {
			if (log.isTraceEnabled()) {
				log.trace(String.format("getDeltaFilterList: including servers aggregated %d days ago", includeAge));
			}
			Calendar cal = Calendar.getInstance();
			cal.add(Calendar.DAY_OF_YEAR, -1 * includeAge);
			Date threshold = cal.getTime();
			String key = String.format("%s.%s", ARG_SUCCEEDED_AGGREGATIONS, objectType);
			Attributes<String, Object> attributes = app.getAttributes();
			if (attributes.containsKey(key)) {
				Object successData = attributes.get(key);
				if (successData instanceof Map) {
					Map<String,Object> successMap = (Map<String,Object>) successData;
					for (String successItem: successMap.keySet()) {
						Object d = successMap.get(successItem);
						if (d instanceof Date && ((Date) d).before(threshold)) {
							filterSet.add(successItem.toLowerCase());
						}
					}
				}
			}
		}
		
		// Compile and sort the list
		if (!filterSet.isEmpty()) {
			List<String> filterList = new ArrayList<String>();
			filterList.addAll(filterSet);
			Collections.sort(filterList);
			return filterList;
		}
		return null;
	}
	
	/**
	 * If configured, get the list of server names for "delta" aggregation.
	 * 
	 * @return
	 */
	protected List<String> getTestFilterList() {
		if (log.isDebugEnabled()) {
			log.debug("Enter: getTestFilterList()");
		}
		String filterStr = getApplication().getStringAttributeValue(ARG_TEST_CONNECTION_HOSTS);
		if (Util.isNotNullOrEmpty(filterStr)) {
			if (log.isTraceEnabled()) log.trace(String.format("Configurations to test: %s", filterStr));	
			return Util.csvToList(filterStr.toLowerCase());
		}
		return null;
	}
	
	/**
	 * Get the number of provisioning threads to use.
	 * 
	 * @param items
	 * @return
	 */
	protected int getMaxProvisioningThreads(int items) {
		if (log.isDebugEnabled()) {
			log.debug(String.format("Enter: getMaxProvisioningThreads(%d)", items));
		}
		int maxThreads = getApplication().getAttributes().getInt(ARG_MAX_PROVISIONING_THREADS, 1);
		if (maxThreads > 16) {
			maxThreads = 16;
		}
		if (maxThreads > items) {
			maxThreads = items;
		}
		return maxThreads;
	}
	
	/**
	 * Get a list of retryable aggregation errors.
	 * 
	 * @return
	 */
	@SuppressWarnings("unchecked")
	protected List<String> getRetryableAggregationErrors() {
		if (log.isDebugEnabled()) {
			log.debug("Enter: getRetryableAggregationErrors()");
		}
		Attributes<String,Object> attributes = getApplication().getAttributes();
		if (attributes != null) {
			List<String> retryables = attributes.getList(ARG_RETRYABLE_AGGREGATION_ERRORS);
			if (log.isTraceEnabled()) {
				log.trace(String.format("Retryable errors: %s", retryables));
			}
			return retryables;
		}
		return null;
	}

	/**
	 * Check server name against the filter list to determine whether a host should be excluded.
	 * 
	 * @param filter
	 * @param name
	 * @return
	 */
	protected boolean shouldExcludeServer(List<String> filter, String name) {
		if (log.isDebugEnabled()) {
			log.debug(String.format("Enter: shouldExcludeServer(%s, %s)", filter, name));
		}
		if (Util.isNullOrEmpty(name)) {
			return true;
		}
		if (filter == null || filter.isEmpty()) {
			return false;
		}
		return (!filter.contains(name.toLowerCase()));
	}

	@Override
	public ResourceObject getObject(final String objectType, final String identityName, final Map<String, Object> options) throws ConnectorException {
		if (log.isDebugEnabled()) {
			log.debug(String.format("Enter: getObject(%s, %s, %s)", objectType, identityName, options));
		}
		
		ObjectNameFormat f = MultiAppUtils.identifyNameFormat(identityName);
		if (f != null) {
			String objectName = f.getObjectName(identityName);
			String hostname = f.getHostName(identityName);
			if (Util.isNullOrEmpty(objectName)) {
				throw new ConnectorException("Could not get object name");
			}
			if (Util.isNullOrEmpty(hostname)) {
				throw new ConnectorException("Could not get host name");
			}
			Connector connector = null;
			try {
				Map<String,Object> server = getServerByName(hostname);
				if (server != null && !server.isEmpty()) {
					Application application = getServerApplication(server);
					if (application == null) {
						throw new ConnectorException(String.format("Cannot instantiate application for server %s", hostname));
					}
					connector = getRealConnectorFromBaseApplication(application);
					if (connector == null) {
						throw new ConnectorException(String.format("Cannot instantiate connector for server %s", hostname));						
					}
					ResourceObject object = connector.getObject(objectType, objectName, options);
					if (object != null) {
						MultiAppUtils.updateResourceObjectNames(getApplication(), this.objectNameFormat, object, hostname);
						MultiAppUtils.updateResourceObjectEntitlementNames(getApplication(), this.getObjectNameFormat(), object, hostname);
					}
					return object;
				} else {
					throw new ConnectorException(String.format("No configuration found for host %s", hostname));
				}
			} catch (GeneralException e) {
				log.error(e);
				throw new ConnectorException(e);
			} finally {
				connector.destroy(new HashMap<String, Object>());
				connector = null;
			}
		} else {
			throw new ConnectorException("Cannot parse object and host name");
		}
	}

	/**
	 * Get the configuration Custom object for server configurations.
	 * 
	 * @return
	 * @throws GeneralException
	 */
	private Custom getConfigurationCustom() throws GeneralException {
		if (log.isDebugEnabled()) {
			log.debug("Enter: getConfigurationCustom");
		}
		if (configurationCustom == null) {
			String customName = this.getApplication().getStringAttributeValue(ARG_CONFIG_CUSTOM);
			if (Util.isNotNullOrEmpty(customName)) {
				configurationCustom = context.getObject(Custom.class, customName);
			}
		}
		return configurationCustom;
	}
	
	/**
	 * Get the "real" connector class from the application definition.
	 * 
	 * @return the name of the connector class or null of not found.
	 * @throws GeneralException 
	 */
	protected String getRealConnectorClass() throws GeneralException {
		if (log.isDebugEnabled()) {
			log.debug("Enter: getRealConnectorClass()");
		}
		Application application = this.getApplication();
		if (application != null) {
			String connectorClassName = application.getStringAttributeValue(ARG_APP_CONNECTOR);
			if (Util.isNotNullOrEmpty(connectorClassName)) {
				return connectorClassName;
			}
			Application template = getTemplate(getApplication());
			if (template != null) {
				connectorClassName = template.getConnector();
			}
			if (Util.isNotNullOrEmpty(connectorClassName)) {
				return connectorClassName;
			}
		}
		return null;
	}
	
	/**
	 * Get the real connector from the specified template. This method will look up the template application in
	 * the connector registry and instantiate the connector.
	 * 
	 * @param serverApplication
	 * @return
	 * @throws GeneralException
	 */
	public Connector getRealConnectorFromBaseApplication(Application serverApplication) throws GeneralException {
		if (log.isDebugEnabled()) {
			log.debug(String.format("Enter: getRealConnectorFromBaseApplication(%s)", serverApplication));
		}
		if (serverApplication != null) {
			String connectorClassName = getRealConnectorClass();
			if (Util.isNullOrEmpty(connectorClassName)) {
				throw new GeneralException(String.format("Cannot retrieve connector class for application %s", serverApplication.getName()));
			}
			return MultiAppUtils.getConnectorFromTemplate(connectorClassName, serverApplication, this.getInstance());
		}
		return null;
	}
	
	/**
	 * Get the configuration rule to generate a list of server configurations.
	 * 
	 * @return
	 * @throws GeneralException
	 */
	private Rule getConfigurationRule() throws GeneralException {
		if (log.isDebugEnabled()) {
			log.debug("Enter: getConfigurationRule()");
		}
		String ruleName = this.getApplication().getStringAttributeValue(ARG_CONFIG_RULE);
		if (Util.isNotNullOrEmpty(ruleName)) {
			return this.context.getObject(Rule.class, ruleName);
		}
		return null;
	}

	private Rule getCredentialRule() throws GeneralException {
		if (log.isDebugEnabled()) {
			log.debug("Enter: getCredentialRule()");
		}
		String ruleName = this.getApplication().getStringAttributeValue(ARG_CREDENTIAL_RULE);
		if (Util.isNotNullOrEmpty(ruleName)) {
			return context.getObject(Rule.class, ruleName);
		}
		return null;
	}
	
	/**
	 * Get the list of server configurations from the embedded atributes map.
	 * Every server in the map will gave its own entry and must be a Map
	 * with settings to override the defaults.
	 * 
	 * @param attributes
	 * @return
	 */
	private List<Map<String,Object>> getServerList(Attributes<String, Object> attributes) {
		if (log.isDebugEnabled()) {
			log.debug(String.format("Enter: getServerList(%s)", attributes));
		}
		List<Map<String,Object>> servers = new ArrayList<Map<String,Object>>();
		if (attributes != null && attributes.containsKey(ARG_SERVER_CONFIG_MAP)) {
			Object list = attributes.get(ARG_SERVER_CONFIG_MAP);
			if (list instanceof List) {
				@SuppressWarnings("unchecked")
				List<Map<String,Object>> embeddedConfig = (List<Map<String,Object>>) list;
				servers.addAll(embeddedConfig);
			}
		}
		if (log.isTraceEnabled()) {
			log.trace(String.format("Returning servers from embedded configuration map:\n%s", servers));
		}
		return servers;
	}
	
	/**
	 * Get the list of server configurations from the configured custom object.
	 * Every server in the custom object will gave its own entry and must be a Map
	 * with settings to override the defaults.
	 * 
	 * @param custom
	 * @return
	 */
	@SuppressWarnings("unchecked")
	private List<Map<String,Object>> getServerList(Custom custom) {
		if (log.isDebugEnabled()) {
			log.debug(String.format("Enter: getServerList(%s)", custom));
		}
		List<Map<String,Object>> servers = new ArrayList<Map<String,Object>>();
		if (custom != null) {
			Attributes<String, Object> attributes = custom.getAttributes();
			if (attributes != null && !attributes.isEmpty()) {
				List<String> serverNames = attributes.getKeys();
				for (String serverName: serverNames) {
					Object serverData = attributes.get(serverName);
					if (serverData instanceof Map) {
						Map<String,Object> serverConfig = new HashMap<String,Object>();
						serverConfig.putAll((Map<String,Object>) serverData);
						serverConfig.put(ATTR_MULTI_HOSTID, serverName);
						servers.add(serverConfig);
					}
				}
			}
		}
		if (log.isTraceEnabled()) {
			log.trace(String.format("Returning servers from Custom object:\n%s", servers));
		}
		return servers;
	}

	/**
	 * Get the list of server configurations by running the configured rule.
	 * 
	 * @param rule
	 * @return
	 * @throws GeneralException 
	 */
	@SuppressWarnings("unchecked")
	private List<Map<String,Object>> getServerList(Rule rule) throws GeneralException {
		if (log.isDebugEnabled()) {
			log.debug(String.format("Enter: getServerList(%s)", rule));
		}
		List<Map<String,Object>> servers = new ArrayList<Map<String,Object>>();
		if (rule != null) {
			Map<String,Object> args = new HashMap<String,Object>();
			args.put("application", this.getApplication());
			Object ruleResultObject = context.runRule(rule, args);
			if (ruleResultObject instanceof List && !((List<?>) ruleResultObject).isEmpty()) {
				servers = (List<Map<String,Object>>) ruleResultObject;
			}

		}
		if (log.isTraceEnabled()) {
			log.trace(String.format("Returning servers from rule:\n%s", servers));
		}
		return servers;
	}

	/**
	 * Get the list of server configurations to process.
	 * 
	 * @param filter	List of server names to be included.
	 * @return
	 * @throws GeneralException
	 */
	@SuppressWarnings("unchecked")
	public List<Map<String,Object>> getServerList(List<String> filter) throws GeneralException {
		if (log.isDebugEnabled()) {
			log.debug(String.format("Enter: getServerList(%s)", filter));
		}
		if (serverList == null) {
			serverList = new ArrayList<Map<String,Object>>();
			
			// First try embedded configuration from the application object.
			Attributes<String,Object> appAttributes = getApplication().getAttributes();
			if (appAttributes != null) {
				List<Map<String,Object>> appResults = getServerList(appAttributes);
				if (appResults != null && !appResults.isEmpty()) {
					serverList.addAll(appResults);
				}
			}
			
			// Second, try the Custom object if configured
			Custom custom = getConfigurationCustom();
			if (custom != null) {
				List<Map<String,Object>> customResults = getServerList(custom);
				if (customResults != null && !customResults.isEmpty()) {
					serverList.addAll(customResults);
				}
			}
			
			// Lastly, try the configuration rule, if configured.
			Rule rule = getConfigurationRule();
			if (rule != null) {
				List<Map<String,Object>> ruleResultObject = getServerList(rule);
				if (ruleResultObject != null && !ruleResultObject.isEmpty()) {
					for (Object object: (List<?>) ruleResultObject) {
						if (object instanceof Map) {
							Map<String,Object> map = (Map<String,Object>) object;
							serverList.add(map);
						}
					}
				}
				context.decache(rule);
			}

			// Dump the list
			if (log.isTraceEnabled()) {
				log.trace(String.format("Servers from configurations and rule:\n%s", serverList));
			}
			// Check filters
			if (filter != null && !filter.isEmpty()) {
				Iterator<Map<String,Object>> i = serverList.iterator();
				while (i.hasNext()) {
					Map<String,Object> server = i.next();
					String serverName = Util.otos(server.get(ATTR_MULTI_HOSTID));
					if (shouldExcludeServer(filter, serverName)) {
						i.remove();
					}
				}
				if (log.isTraceEnabled()) {
					log.trace(String.format("Filtered servers:\n%s", serverList));
				}
			}

			// If a credential rule is configured, use that to overlay credentials for
			// each of the servers in the list.
			rule = getCredentialRule();
			if (rule != null && !serverList.isEmpty()) {
				for (Map<String, Object> server: serverList) {
					Map<String,Object> ruleArgs = new HashMap<String,Object>();
					ruleArgs.put("application", this.getApplication());
					ruleArgs.put("server", server);
					ruleArgs.put("serverName", server.get(ATTR_MULTI_HOSTID));
					Object creds = context.runRule(rule, ruleArgs);
					if (creds instanceof Map) {
						server.putAll((Map<String,Object>) creds);
					} else {
						log.error("Incorrect object for credentials, expecting a Map, ignoring");
					}
				}
				context.decache(rule);
			}
		}
		return serverList;
	}

	/**
	 * Get the list of server configurations to process.
	 * 
	 * @return
	 * @throws GeneralException
	 */
	public List<Map<String,Object>> getServerList() throws GeneralException {
		return getServerList(new ArrayList<String>());
	}

	/**
	 * Get the server definition for a specific hostname.
	 * 
	 * @param hostname
	 * @return
	 * @throws GeneralException
	 */
	private Map<String,Object> getServerByName(String hostname) throws GeneralException {
		if (log.isDebugEnabled()) {
			log.debug(String.format("Enter: getServerByName(%s)", hostname));
		}
		List<Map<String,Object>> serverList = getServerList((List<String>)null);
		return MultiAppUtils.getServerByName(serverList, hostname);
	}
	
	/**
	 * Get the ConnectorRegistry object.
	 * 
	 * @param context
	 * @return
	 * @throws GeneralException
	 */
	public static Configuration getConnectorRegistry(SailPointContext context) throws GeneralException {
		if (log.isDebugEnabled()) {
			log.debug(String.format("Enter: getConnectorRegistry(%s)", context));
		}
		return context.getObjectByName(Configuration.class, "ConnectorRegistry");
	}

	/**
	 * Get and cache the connector registry.
	 * 
	 * @return
	 * @throws GeneralException
	 */
	public Configuration getConnectorRegistry() throws GeneralException {
		if (log.isDebugEnabled()) {
			log.debug("Enter: getConnectorRegistry()");
		}
		return getConnectorRegistry(context);
	}
	
	public static Application getTemplate(SailPointContext context, Application base) throws GeneralException {
		if (log.isDebugEnabled()) {
			log.debug(String.format("Enter: getTemplate(%s, %s)", context, base));
		}
		String error = null;
		if (base != null) {
			String templateName = base.getStringAttributeValue(ARG_APP_TEMPLATE);
			if (log.isTraceEnabled()) {
				log.trace(String.format("Template to retrieve: %s", templateName));
			}
			if (Util.isNotNullOrEmpty(templateName)) {
				Configuration connectorRegistry = getConnectorRegistry(context);
				if (connectorRegistry == null) {
					throw new GeneralException("Cannot open ConnectorRegistry");
				}
				Attributes<String,Object> attributes = connectorRegistry.getAttributes();
				if (attributes != null && attributes.containsKey("applicationTemplates")) {
					@SuppressWarnings("unchecked")
					List<Application> templates = (List<Application>) attributes.get("applicationTemplates");
					if (templates != null) {
						for (Application template: templates) {
							if (templateName.equals(template.getName())) {
								return template;
							}
						}
						error = String.format("Template '%s' not found", templateName);
					} else {
						error = "Empty template list";
					}
				} else {
					error = "Empty connector registry";
				}
			} else {
				error = "No template configured";
			}
		} else {
			error = "Base application is null";
		}
		throw new GeneralException(String.format("Error getting application template: %s", error));
	}
	
	/**
	 * Get the configured application template from the base application.
	 * 
	 * @param base
	 * @return
	 * @throws GeneralException
	 */
	public Application getTemplate(Application base) throws GeneralException {
		if (log.isDebugEnabled()) {
			log.debug(String.format("Enter: getTemplate(%s)", base));
		}
		if (applicationTemplate != null) {
			return applicationTemplate;
		}		
		applicationTemplate = getTemplate(context, base);
		return applicationTemplate;
	}
	
	/**
	 * Get a server specific version of the application definition.
	 * 
	 * @param server
	 * @return
	 * @throws GeneralException
	 */
	public Application getServerApplication(Map<String, Object> server) throws GeneralException {
		if (log.isDebugEnabled()) {
			log.debug(String.format("Enter: getServerApplication(%s)", server));
		}
		if (server != null && !server.isEmpty()) {
			if (log.isTraceEnabled()) log.trace("Instantiating connector definition");
			String connectorClassName = this.getRealConnectorClass();
			if (Util.isNotNullOrEmpty(connectorClassName)) {
				return MultiAppUtils.createServerApplication(context, getApplication(), connectorClassName, server);
			}
		}
		return null;
	}
	
	/**
	 * Just before aggregation, reset the list of previously failed aggregations.
	 * 
	 * @param objectType
	 */
	private synchronized void resetFailedAggregations(String objectType) {
		if (log.isDebugEnabled()) {
			log.debug(String.format("Enter: resetFailedAggregations(%s)", objectType));
		}
		if (!shouldRegisterAggregationResult()) {
			// Ignore - should not be done
			return;
		}
		if (Util.isNotNullOrEmpty(objectType)) {
			Application application = getApplication();
			String key = ARG_FAILED_AGGREGATIONS + "." + objectType;
			if (application != null) {
				String lockMode = PersistenceManager.LOCK_TYPE_TRANSACTION;
				try {
					Map<String,Object> options = new HashMap<String,Object>();
			        options.put(SailPointContext.LOCK_TYPE, lockMode);
			        Application app = context.lockObjectById(Application.class, application.getId(), options);
					Attributes<String, Object> attributes = app.getAttributes();
					if (attributes == null) {
						attributes = new Attributes<String, Object>();
					}
					if (attributes.containsKey(key)) {
						attributes.remove(key);
					}
					app.setAttributes(attributes);
					context.saveObject(app);
					this.setApplication(app);
				} catch (GeneralException e) {
					log.error(e);
				} finally {
					if (application != null) {
						try {
							ObjectUtil.unlockObject(context, application, lockMode);
						} catch (GeneralException e) {
							log.error(e);
						}
					}
				}
			}
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * sailpoint.connector.Connector#getIteratorPartitions(java.lang.String,
	 * int, sailpoint.object.Filter, java.util.Map)
	 */
	@Override
	public List<Partition> getIteratorPartitions(String objectType, int suggestedPartitionCount, Filter filter, Map<String, Object> ops) throws ConnectorException {
		if (log.isDebugEnabled()) {
			log.debug(String.format("Enter: getIteratorPartitions(%s, %d, %s, %s)", objectType, suggestedPartitionCount, filter, ops));
		}
		
		// Build list of partitions
		List<Partition> partitions = new ArrayList<Partition>();
		
		try {
			List<String> serverFilter = null;
			if (isDelta(ops)) {
				serverFilter = this.getDeltaFilterList(objectType);
				if (log.isTraceEnabled()) {
					log.trace(String.format("Delta filter list: %s", serverFilter));
				}
			}
			// Reset previous failures
			resetFailedAggregations(objectType);
			// Get the list
			List<Map<String,Object>> servers = getServerList(serverFilter);
			if (servers != null && !servers.isEmpty()) {
				int count = servers.size();
				if (suggestedPartitionCount > count) {
					suggestedPartitionCount = count;
				}
				
				int partitionSize = (int) Math.ceil(( (double) count / (double) suggestedPartitionCount));
				int c = 0; // Count server
				int p = 0; // Count server per partition
				int n = 0; // Count partition
				List<Map<String,Object>> partitionServers = null;
				Partition partition = null;
				for (Map<String,Object> server: servers) {
					if (p == 0) {
						n++;
						partitionServers = new ArrayList<Map<String,Object>>();
						partition = new Partition();
						String name = String.format("Aggregate %s from %s (%d/%d)", objectType, this.getApplication().getName(), n, suggestedPartitionCount);
						partition.setName(name);
						partition.setObjectType(objectType);
						partition.setAttribute("partitionServers", (Object) partitionServers);
						partition.setAttribute("filter", filter);
						partition.setAttribute("options", ops);
						partitions.add(partition);
					}
					partitionServers.add(server);
					partition.setSize(partitionServers.size());
					
					c++;
					p++;
					if (log.isTraceEnabled()) {
						log.trace(String.format("Server count: %d; Partition Count: %d; Servers in Partition: %d", c, n, p)); 
					}
					if (p >= partitionSize) {
						p = 0;
					}
				}
			}
		} catch (GeneralException e) {
			throw new ConnectorException("Error getting server list", e);
		}
		
		return partitions;
	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see sailpoint.connector.Connector#iterateObjects(java.lang.String,
	 * sailpoint.object.Filter, java.util.Map)
	 */
	@SuppressWarnings("unchecked")
	@Override
	public CloseableIterator<ResourceObject> iterateObjects(final String objectType, final Filter filter, final Map<String, Object> options) throws ConnectorException {
		if (log.isDebugEnabled()) {
			log.debug(String.format("Enter: iterateObjects(%s, %s, %s)", objectType, filter, options));
		}
		// Create iterator
		try {
			List<String> serverFilter = null;
			if (isDelta(options)) {
				serverFilter = getDeltaFilterList(objectType);
			}
			// Reset previous failures
			resetFailedAggregations(objectType);
			MultiAppIterator iterator = new MultiAppIterator(this, this.getApplication(), this.getInstance(), objectType, getServerList(serverFilter), filter, options);
			return (CloseableIterator<ResourceObject>) iterator;
		} catch (GeneralException e) {
			throw new ConnectorException(e);
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * sailpoint.connector.Connector#iterateObjects(sailpoint.object.Partition)
	 */
	@SuppressWarnings("unchecked")
	@Override
	public CloseableIterator<ResourceObject> iterateObjects(Partition partition) throws ConnectorException {
		if (log.isDebugEnabled()) {
			log.debug(String.format("Enter: iterateObjects(%s)", partition));
		}
		if (partition != null) {
			// Extract information from partition
			String objectType = partition.getObjectType();
			List<Map<String,Object>> serverList = (List<Map<String,Object>>) partition.get("partitionServers");
			Filter filter = (Filter) partition.get("filter");
			Map<String,Object> options = (Map<String, Object>) partition.get("options");
			// Get iterator for this partition
			try {
				MultiAppIterator iterator = new MultiAppIterator(this, this.getApplication(), this.getInstance(), objectType, serverList, filter, options);
				return (CloseableIterator<ResourceObject>) iterator;
			} catch (GeneralException e) {
				throw new ConnectorException(e);
			}			
		}
		return null;
	}
	
	private Link getLinkFromAccountRequest(AccountRequest accountRequest) throws GeneralException {
		if (log.isDebugEnabled()) {
			log.debug(String.format("Enter: getLinkFromAccountRequest(%s)", accountRequest));
		}
		Link link = null;
		try {
		if (accountRequest != null) {
			String applicationName = accountRequest.getApplicationName();
			String nativeIdentity = accountRequest.getNativeIdentity();
			String instance = accountRequest.getInstance();
			
			List<Filter> filters = new ArrayList<Filter>();
			filters.add(Filter.eq("application.name", applicationName));
			filters.add(Filter.eq("nativeIdentity", nativeIdentity));
			if (Util.isNotNullOrEmpty(instance)) {
				filters.add(Filter.eq("instance", instance));
			}
			Filter filter = Filter.and(filters);
			QueryOptions qo = new QueryOptions();
			qo.addFilter(filter);
			qo.setResultLimit(1);
			Iterator<Link> iterator = context.search(Link.class, qo);
			if (iterator.hasNext()) {
				link = iterator.next();
			}
			Util.flushIterator(iterator);			
		}
		} catch (UnsupportedOperationException e) {
			// This can/will happen in IdentityNow, as the search operation is not supported.
			if (log.isInfoEnabled()) {
				log.info(String.format("Error searching for Link: %s", e.getMessage()), e);
			}
		}
		return link;
	}
	
	@Override
	public ProvisioningResult provision(ProvisioningPlan plan) throws ConnectorException {
		if (log.isDebugEnabled()) {
			log.debug(String.format("Enter: provision(%s)", plan));
		}
		ProvisioningResult result = new ProvisioningResult();
		if (plan == null) {
			log.warn("provision: Plan is null");
			result.addWarning("Null Provisioning Plan");
			result.setStatus(ProvisioningResult.STATUS_COMMITTED);
		} else if (plan.isEmpty()) {
			log.warn("provision: Plan is empty");
			result.setStatus(ProvisioningResult.STATUS_COMMITTED);
		} else {
			try {
				// Perform sanity check: entitlements must be related to the same server as the account
				MultiAppUtils.checkPlanPreProvisioning(context, getApplication(), plan, false, false);
			} catch (GeneralException e) {
				log.error(String.format("Sanity check failed: %s", e.getMessage()));
				throw new ConnectorException(e);
			}
			if (log.isTraceEnabled()) {
				try {
					log.trace(String.format("Plan verified: %s", (plan != null)?plan.toXml():"NULL"));
				} catch (GeneralException e) {
					log.error(e);
				}
			}
			
			List<AccountRequest> accountRequests = plan.getAccountRequests();
			List<ObjectRequest> objectRequests = plan.getObjectRequests();
			Attributes<String, Object> arguments = plan.getArguments();
			try {
				// Accounts
				if (accountRequests != null && !accountRequests.isEmpty()) {
					if (log.isDebugEnabled()) {
						log.debug(String.format("Nr. of Account Requests: %d", accountRequests.size()));
					}
					Identity identity = plan.getIdentity();
					if (identity == null) {
						String identityName = plan.getNativeIdentity();
						if (Util.isNullOrEmpty(identityName)) {
							log.warn("provision(): Cannot determine identity from plan");
						} else {
							try {
								identity = context.getObject(Identity.class, identityName);
								if (identity == null) {
									log.warn(String.format("Identity '%s' not found", identityName));
								}
							} catch (GeneralException e) {
								log.warn(String.format("Error looking up identity: %s", e.getMessage()));
							}
						}
					}
					// Prepare data for provisioning threads
					Queue<AbstractRequest> queue = new LinkedBlockingQueue<AbstractRequest>();
					queue.addAll(accountRequests);
					List<AbstractRequest> requestList = new ArrayList<AbstractRequest>();
					// Start the threads
					int threadCount = getMaxProvisioningThreads(accountRequests.size());
					List<MultiThreadedProvisioner> threads = new ArrayList<MultiThreadedProvisioner>();
					Application application = this.getApplication();
					String connectorClassName = getRealConnectorClass();
					for (int t = 0; t <= threadCount; t++ ) {
						MultiThreadedProvisioner provisioner = new MultiThreadedProvisioner(this.getObjectNameFormat(), application, connectorClassName, this.getInstance(), this.getServerList(), queue, arguments);
						threads.add(provisioner);
						provisioner.setIdentity(identity);
						provisioner.start();
					}
					// Monitor the threads
					while (!threads.isEmpty()) {
						Iterator<MultiThreadedProvisioner> iterator = threads.iterator();
						while (iterator.hasNext()) {
							MultiThreadedProvisioner thread = iterator.next();
							if (!thread.isAlive()) {
								if (log.isDebugEnabled()) {
									log.debug(String.format("Thread completed: %s", thread.getName()));
								}
								List<AbstractRequest> threadResults = thread.getResults();
								if (threadResults != null) {
									requestList.addAll(threadResults);
								}
								iterator.remove();
							}
						}
						try {
							Thread.sleep(100L);
						} catch (InterruptedException e) {
							log.warn("Sleep interrupted. Can't you just let me sleep for 100 ms?");
						}
					}
					// Process the results
					if (log.isTraceEnabled()) {
						log.trace("Account Provisioning Completed - Processing Results");
						log.trace(String.format("Number of results: %d", (requestList == null)?0:requestList.size()));
					}
					plan.setAccountRequests(new ArrayList<AccountRequest>());
					for (AbstractRequest request: requestList) {
						if (request != null) {
							AccountRequest accountRequest = (AccountRequest) request;
							if (log.isTraceEnabled()) {
								log.trace(String.format("AccountRequest being processed after provisioning: %s", accountRequest.toXml()));
							}
							ProvisioningResult accountResult = accountRequest.getResult();
							if (accountResult != null) {
								if (log.isTraceEnabled()) {
									log.trace(String.format("Result for AccountRequest '%s' on '%s':\n%s", accountRequest.getNativeIdentity(), accountRequest.getApplication(), accountResult.toXml()));
								}
								accountRequest.setResult(accountResult);
								if (accountResult.hasMessages()) {
									result.assimilateMessages(accountResult);
								}
							}
							plan.add(accountRequest);
							plan.setResult(result);
						}						
					}
				}
			
				// Group objects
				if (objectRequests != null && !objectRequests.isEmpty()) {
					if (log.isDebugEnabled()) {
						log.debug(String.format("Nr. of Object Requests: %d", objectRequests.size()));
					}
					// Prepare data for provisioning threads
					Queue<AbstractRequest> queue = new LinkedBlockingQueue<AbstractRequest>();
					queue.addAll(objectRequests);
					List<AbstractRequest> requestList = new ArrayList<AbstractRequest>();
					// Start the threads
					int threadCount = getMaxProvisioningThreads(objectRequests.size());
					List<MultiThreadedProvisioner> threads = new ArrayList<MultiThreadedProvisioner>();
					Application application = this.getApplication();
					String connectorClassName = getRealConnectorClass();
					for (int t = 0; t <= threadCount; t++ ) {
						MultiThreadedProvisioner provisioner = new MultiThreadedProvisioner(this.getObjectNameFormat(), application, connectorClassName, this.getInstance(), this.getServerList(), queue, arguments);
						threads.add(provisioner);
						provisioner.start();
					}
					// Monitor the threads
					while (!threads.isEmpty()) {
						Iterator<MultiThreadedProvisioner> iterator = threads.iterator();
						while (iterator.hasNext()) {
							MultiThreadedProvisioner thread = iterator.next();
							if (!thread.isAlive()) {
								if (log.isDebugEnabled()) {
									log.debug(String.format("Thread completed: %s", thread.getName()));
								}
								List<AbstractRequest> threadResults = thread.getResults();
								if (threadResults != null) {
									requestList.addAll(threadResults);
								}
								iterator.remove();
							}
						}
						try {
							Thread.sleep(100L);
						} catch (InterruptedException e) {
							log.warn("Sleep interrupted. Can't you just let me sleep for 100 ms?");
						}
					}
					// Process the results
					if (log.isTraceEnabled()) {
						log.trace("Group Provisioning Completed - Processing Results");
						log.trace(String.format("Number of results: %d", (requestList == null)?0:requestList.size()));
					}
					plan.setObjectRequests(new ArrayList<ObjectRequest>());
					for (AbstractRequest request: requestList) {
						if (request != null) {
							ObjectRequest objectRequest = (ObjectRequest) request;
							if (log.isTraceEnabled()) {
								log.trace(String.format("ObjectRequest being processed after provisioning: %s", objectRequest.toXml()));
							}
							ProvisioningResult objectResult = objectRequest.getResult();
							if (objectResult != null) {
								if (log.isTraceEnabled()) {
									log.trace(String.format("Result for ObjectRequest '%s' on '%s':\n%s", objectRequest.getNativeIdentity(), objectRequest.getApplication(), objectResult.toXml()));
								}
								objectRequest.setResult(objectResult);
								if (objectResult.hasMessages()) {
									result.assimilateMessages(objectResult);
								}
							}
							plan.add(objectRequest);
							plan.setResult(result);
						}						
					}
				}
				
				if (log.isTraceEnabled()) {
					log.trace(String.format("Plan after provisioning:\n%s", plan.toXml()));
				}
			} catch (GeneralException e) {
				log.error(String.format("Exception thrown during provisioning: %s", e.getMessage()));
				throw new ConnectorException(e);
			}
		}
		return result;
	}
	
	/**
	 * Test the connection for a specific server configuration.
	 *  
	 * @param hostConfiguration
	 * @throws ConnectorException
	 */
	private void testConfiguration(Map<String,Object> hostConfiguration) throws ConnectorException {
		if (log.isDebugEnabled()) {
			log.debug(String.format("Enter: testConfiguration(%s)", hostConfiguration));
		}
		if (hostConfiguration == null || hostConfiguration.isEmpty()) {
			throw new ConnectorException("Null or empty host configuration");
		}
		String hostId = (String) hostConfiguration.get(ATTR_MULTI_HOSTID);
		if (log.isDebugEnabled()) {
			log.debug(String.format("Testing connection for %s", hostId));
		}
		Connector connector = null;
		try {
			if (log.isTraceEnabled()) log.trace("Getting application definition");
			Application application = getServerApplication(hostConfiguration);
			if (application == null) {
				throw new ConnectorException("Null application retrieved");
			}
			if (log.isTraceEnabled()) log.trace("Instantiating connector definition");
			connector = this.getRealConnectorFromBaseApplication(application);
			if (log.isTraceEnabled()) log.trace("Testing connector configuration");
			connector.testConfiguration();
		} catch (Exception e) {
			log.error(String.format("testConfiguration(%s): %s", hostConfiguration, e.getMessage()));
			throw new ConnectorException(String.format("Error testing connection for %s: %s", hostId, e.getMessage()));
		} finally {
			if (connector != null) {
				connector.destroy(new HashMap<String, Object>());
				connector = null;
			}
		}
	}

	@Override
	public void testConfiguration() throws ConnectorException {
		if (log.isDebugEnabled()) {
			log.debug("Enter: testConfiguration()");
		}
		int c = 0;
		try {
			List<Map<String,Object>> hostConfigurations = getServerList(getTestFilterList());
			if (hostConfigurations == null || hostConfigurations.isEmpty()) {
				throw new GeneralException("No systems configured");
			}
			if (maxTestedConfigurations > 0) {
				if (log.isTraceEnabled()) log.trace("Testing connections to configured servers");
				for (Map<String,Object> hostConfiguration: hostConfigurations) {
					c++;
					if (c > maxTestedConfigurations) {
						log.warn("Maximum number of tested connections reached - aborting");
						break;
					}
					testConfiguration(hostConfiguration);
				}
			}
		} catch (Exception e) {
			log.error(String.format("testConfiguration(): %s", e.getMessage()));
			throw new ConnectorException(e);
		}
	}

	/**
	 * 
	 * @return
	 */
	public ObjectNameFormat getObjectNameFormat() {
		return objectNameFormat;
	}

	/**
	 * 
	 * @param objectNameFormat
	 */
	public void setObjectNameFormat(ObjectNameFormat objectNameFormat) {
		this.objectNameFormat = objectNameFormat;
	}
	
	/**
	 * Yes, we can.
	 */
	@Override
	public boolean supportsPartitionedDeltaAggregation() {
		return true;
	}


	@SuppressWarnings({ "rawtypes" })
	public class MultiAppIterator implements Iterator, CloseableIterator {

		private final Logger log = Logger.getLogger(MultiAppIterator.class);
		
		public final static String ARG_RETRY_COUNTER = "multiConnectorAggregationRetries";
		
		public final static int DEF_MAX_AGGREGATION_RETRIES = 10; 
		public final static int ABS_MAX_AGGREGATION_RETRIES = 1000; 

		private Queue<Map<String,Object>> hostConfigurations = null;
		private Map<String,Object> currentConfig = null;
		private Application application = null;
		private String hostname = null;
		private String instance = null;
		private String objectType = null;		
		private Map<String, Object> options = null;
		private MultiConnectorAdapter adapter = null;
		private Filter filter = null;
		private Connector connector = null; 
		private boolean isCallFromTestConnector = false; 
		private CloseableIterator<ResourceObject> iterator = null;
		private int maxRetries = DEF_MAX_AGGREGATION_RETRIES;
		private boolean delayExceptions = false;
		private List<String> errors = new ArrayList<String>();
		private List<String> failedHosts = new ArrayList<String>();
		private Map<String,Date> succeededHosts = new HashMap<String,Date>(); 

		public MultiAppIterator(MultiConnectorAdapter adapter, Application application, String instance, String objectType, List<Map<String,Object>> hostConfigurations, Filter filter, Map<String, Object> options) throws GeneralException {
			if (log.isDebugEnabled()) {
				log.debug(String.format("Constructor: MultiAppIterator(%s, %s, %s, %s, %s, %s, %s)", adapter, application, instance, objectType, hostConfigurations, filter, options));
			}
			if (adapter == null) {
				throw new GeneralException("MultiAppIterator: Null adapter");
			}
			if (application == null) {
				throw new GeneralException("MultiAppIterator: Null application");
			}
			if (Util.isNullOrEmpty(objectType)) {
				throw new GeneralException("MultiAppIterator: objectType not defined");
			}
			if (hostConfigurations == null || hostConfigurations.isEmpty()) {
				throw new GeneralException("MultiAppIterator: Null or empty hostConfigurations list");
			}
			this.adapter = adapter;
			this.application = application;
			this.options = options;
			this.isCallFromTestConnector = (options != null && options.containsKey("isCallFromTestConnector") && Util.otob(options.get("isCallFromTestConnector")));
			if (application.getAttributes() != null) {
				if (isCallFromTestConnector) {
					this.maxRetries = 0; // disable retries for test connection
				} else {
					this.maxRetries = application.getAttributes().getInt(MultiConnectorAdapter.ARG_MAX_AGGREGATION_RETRIES, DEF_MAX_AGGREGATION_RETRIES);
					if (this.maxRetries > ABS_MAX_AGGREGATION_RETRIES) {
						this.maxRetries = ABS_MAX_AGGREGATION_RETRIES;
					}
				}
				this.delayExceptions = application.getAttributes().getBoolean(MultiConnectorAdapter.ARG_DELAY_AGGREGATION_EXCEPTIONS, false);
			}
			this.instance = instance;
			this.objectType = objectType;
			this.currentConfig = null;
			this.hostConfigurations = new LinkedBlockingQueue<Map<String,Object>>();
			this.hostConfigurations.addAll(hostConfigurations);
			this.filter = filter;
		}
				
		/**
		 * Get a temporary application definition.
		 * 
		 * @param server
		 * @return
		 * @throws GeneralException
		 */
		private Application getVolatileApplication(Map<String,Object> server) throws GeneralException {
			if (log.isDebugEnabled()) {
				log.debug(String.format("Enter: getVolatileApplication(%s)", server));
			}
			return adapter.getServerApplication(server);
		}
		
		/**
		 * Instantiate a new connector and iterator for a new host configuration.
		 * 
		 * @param hostConfiguration
		 * @throws GeneralException
		 * @throws ConnectorException
		 */
		private void setIterator(final Map<String,Object> hostConfiguration) throws GeneralException, ConnectorException {
			if (log.isDebugEnabled()) {
				log.debug(String.format("Enter: setIterator(%s)", hostConfiguration));
			}
			Application vapp = getVolatileApplication(hostConfiguration);
			application = vapp;
			hostname = (String) hostConfiguration.get(ATTR_MULTI_HOSTID);
			Connector conn = ConnectorFactory.getConnector(vapp, instance);
			if (conn instanceof ConnectorProxy) {
				this.connector = ((ConnectorProxy) conn).getInternalConnector();
			} else {
				this.connector = conn;
			}
			Map<String,Object> ops = new HashMap<String,Object>();
			if (options != null) {
				ops.putAll(options);
				// Not passing delta aggregation to the underlying connectors, as it won't be supported.
				if (ops.containsKey(Aggregator.ARG_DELTA_AGGREGATION)) {
					ops.remove(Aggregator.ARG_DELTA_AGGREGATION);
				}
			}
			if (connector != null) {
				if (iterator != null) {
					this.iterator.close();
				}
				this.iterator = (CloseableIterator<ResourceObject>) connector.iterateObjects(objectType, filter, ops);
			} else {
				this.iterator = null;
			}
			
		}
		
		/**
		 * Add a host to the list of failed ones.
		 * 
		 * @param key
		 */
		private void addFailedHost(String key) {
			if (log.isDebugEnabled()) {
				log.debug(String.format("Enter: addFailedHost(%s)", key));
			}
			if (Util.isNotNullOrEmpty(key) && !failedHosts.contains(key)) {
				failedHosts.add(key);
			}
		}
		
		private void addSucceededHost(String key) {
			if (log.isDebugEnabled()) {
				log.debug(String.format("Enter: addSucceededHost(%s)", key));
			}
			if (Util.isNotNullOrEmpty(key) && !succeededHosts.containsKey(key)) {
				succeededHosts.put(key, new Date());
			}			
		}
		
		/**
		 * Close connector and iterator for the connector.
		 * @throws  
		 */
		private void closeCurrentConnector() {
			if (log.isDebugEnabled()) {
				log.debug("Enter: closeCurrentConnector()");
			}
			addSucceededHost(hostname);
			if (iterator != null) {
				this.iterator.close();
				this.iterator = null;				
			}
			if (connector != null) {
				try {
					this.connector.destroy(options);
				} catch (ConnectorException e) {
					log.error(String.format("Error closing connector: %s", e.getMessage()), e);
				}
				this.connector = null;
			}
			this.currentConfig = null;
		}
		
		/** 
		 * Throw errors if necessary.
		 */
		private void throwErrors() {
			if (log.isDebugEnabled()) {
				log.debug("Enter: throwErrors()");
			}
			if (errors != null && !errors.isEmpty()) {
				String message = Util.listToCsv(errors);
				errors.clear();
				throw new RuntimeException(String.format("throwErrors(): Collected Aggregation Exceptions: %s", message));
			}
		}
		
		/**
		 * Get the next host configuration from the list.
		 * 
		 * For delta aggregation the names are checked against the provided list of servers.
		 * 
		 * @return
		 * @throws GeneralException 
		 */
		private Map<String,Object> getNextHostConfiguration() {
			if (log.isDebugEnabled()) {
				log.debug("Enter: getNextHostConfiguration()");
			}
			while (!hostConfigurations.isEmpty()) {
				currentConfig = hostConfigurations.poll();
				if (currentConfig == null) {
					continue;
				}
				if (currentConfig.containsKey(ARG_RETRY_COUNTER)) {
					int retries = Util.otoi(currentConfig.get(ARG_RETRY_COUNTER));
					if (retries > 300) {
						retries = 300;
					}
					try {
						log.trace("Sleeping before retry");
						Thread.sleep(100L * retries);
					} catch (InterruptedException e) {
						log.warn(String.format("Sleep interrupted: %s", e.getMessage()));
					}
				}
				return currentConfig;
			}
			throwErrors();
			return null;
		}
		
		/**
		 * Re-add the current host entry to the queue if retries are enabled (non-zero) and the retry limit has not been reached.
		 */
		private boolean requeue() {
			if (log.isDebugEnabled()) {
				log.debug("Enter: requeue()");
			}
			boolean requeued = false;
			if (currentConfig != null) {
				int retryCount = 0;
				if (currentConfig.containsKey(ARG_RETRY_COUNTER)) {
					retryCount = Util.otoi(currentConfig.get(ARG_RETRY_COUNTER));
				}
				if (log.isTraceEnabled()) {
					log.trace(String.format("Retries: %d / %d", retryCount+1, maxRetries));
				}
				if (this.maxRetries < 0 || retryCount < this.maxRetries) {
					if (log.isTraceEnabled()) {
						log.trace(String.format("Retrying configuration %s", currentConfig));
					}
					retryCount++;
					currentConfig.put(ARG_RETRY_COUNTER, retryCount);
					hostConfigurations.add(currentConfig);
					requeued = true;
				} else {
					if (log.isInfoEnabled()) {
						if (maxRetries == 0) {
							log.info("Retries not enabled, not adding back to the queue.");
						} else {
							log.info(String.format("Maximum retry limit %s reached.", maxRetries));
						}
					}
				}
				this.currentConfig = null;
			}
			this.closeCurrentConnector();
			return requeued;
		}
		
		/**
		 * Close the current iterator and get the next.
		 * 
		 * @throws GeneralException
		 * @throws ConnectorException
		 */
		private void nextIterator() throws GeneralException, ConnectorException {
			if (log.isDebugEnabled()) {
				log.debug("Enter: nextIterator()");
			}
			closeCurrentConnector();
			Map<String,Object> nextConfig = getNextHostConfiguration();
			if (nextConfig != null) {
				setIterator(nextConfig);			
			} else {
				this.hostname = null;
				this.application = null;
				if (iterator !=null) {
					iterator.close();
				}
				this.iterator = null;
			}
		}
		
		@SuppressWarnings("unchecked")
		private synchronized void updateApplicationAggregationResults() {
			if (log.isDebugEnabled()) {
				log.debug("Enter: updateApplicationAggregationResults()");
			}
			if (!adapter.shouldRegisterAggregationResult()) {
				// Ignore - Should not be registered
				return;
			}			
			if (Util.isNotNullOrEmpty(objectType)) {
				Application application = getApplication();
				if (application != null) {
					String lockMode = PersistenceManager.LOCK_TYPE_TRANSACTION;
					try {
						Map<String,Object> options = new HashMap<String,Object>();
				        options.put(SailPointContext.LOCK_TYPE, lockMode);
				        Application app = context.lockObjectById(Application.class, application.getId(), options);
						Attributes<String, Object> attributes = app.getAttributes();
						if (attributes == null) {
							attributes = new Attributes<String, Object>();
						}
						// Process failures
						String fkey = MultiConnectorAdapter.ARG_FAILED_AGGREGATIONS + "." + objectType;
						List<String> failures = (List<String>) attributes.getList(fkey);
						if (failures == null) {
							failures = new ArrayList<String>();
						}					
						if (failedHosts != null && !failedHosts.isEmpty()) {
							for (String failedHost: failedHosts) {
								if (!failures.contains(failedHost)) {
									failures.add(failedHost);
								}
							}
							if (log.isTraceEnabled()) {
								log.trace(String.format("updateApplicationAggregationResults: List of failed servers: %s", failures));
							}
						}
						// Process successes
						String skey = MultiConnectorAdapter.ARG_SUCCEEDED_AGGREGATIONS + "." + objectType;
						Object sObject = attributes.get(skey);
						Map<String,Date> successes = null;
						if (sObject instanceof Map) {
							successes = (Map<String,Date>) sObject;
							if (log.isTraceEnabled()) {
								log.trace(String.format("updateApplicationAggregationResults: Current successes: %s", successes));
							}
						}
						if (successes == null) {
							if (log.isTraceEnabled()) {
								log.trace("updateApplicationAggregationResults: creating empty success map");
							}
							successes = new HashMap<String,Date>();
						}
						if (succeededHosts != null && !succeededHosts.isEmpty()) {
							successes.putAll(succeededHosts);
						}
						// Update application
						attributes.put(fkey, failures);
						attributes.put(skey, successes);
						app.setAttributes(attributes);
						context.saveObject(app);
						adapter.setApplication(app);
					} catch (GeneralException e) {
						log.error(e);
					} finally {
						if (application != null) {
							try {
								ObjectUtil.unlockObject(context, application, lockMode);
							} catch (GeneralException e) {
								log.error(e);
							}
						}
					}
				}
			}
		}

		@Override
		public void close() {
			if (log.isDebugEnabled()) {
				log.debug("Enter: close()");
			}
			updateApplicationAggregationResults();
			throwErrors();
			this.closeCurrentConnector();
		}
		
		/**
		 * Determine whether an error can be retried.
		 *  
		 * @param t
		 * @return
		 */
		private boolean isRetryable(Throwable t) {
			if (log.isDebugEnabled()) {
				log.debug(String.format("Enter: isRetryable(%s)", t));
			}
			if (t != null) {
				String message = t.getMessage();
				if (Util.isNotNullOrEmpty(message)) {
					if (log.isTraceEnabled()) {
						log.trace(String.format("isRetryable: exception message: %s", message));
					}
					List<String> retryables = this.adapter.getRetryableAggregationErrors();
					if (retryables == null || retryables.isEmpty()) {
						if (log.isDebugEnabled()) {
							log.debug("isRetryable: No retryable messages configured, defaulting to false.");
						}
						return false;
					}
					for (String retryable: retryables) {
						if (log.isTraceEnabled()) {
							log.trace(String.format("isRetryable: checking retryable error: %s.", retryable));
						}
						if (Util.isNotNullOrEmpty(retryable)) {
							if (message.toLowerCase().indexOf(retryable.toLowerCase()) >= 0) {
								if (log.isDebugEnabled()) {
									log.debug(String.format("isRetryable: message '%s' matches retryable error '%s'; returning true.", message, retryable));
								}
								return true;
							}
						}
					}
					if (log.isDebugEnabled()) {
						log.debug("isRetryable: no retryable error found for message.");
					}
					return false;
				}
			}
			if (log.isDebugEnabled()) {
				log.debug("isRetryable: Exception or message is empty, defaulting to true.");
			}
			return true;
		}

		@Override
		public boolean hasNext() {
			if (log.isDebugEnabled()) {
				log.debug("Enter: hasNext()");
			}
			// Check if we need to get a new iterator.
			while (iterator == null && !hostConfigurations.isEmpty()) {
				try {
					nextIterator();
				} catch (GeneralException | ConnectorException e) {
					log.error(Util.stackToString(e));
					iterator = null;
					if (maxRetries != 0 && (!isRetryable(e) || !requeue())) {
						if (delayExceptions) {
							addFailedHost(hostname);
							errors.add(e.getMessage());
						} else {
							throw new RuntimeException(e);
						}
					} else if (maxRetries == 0) {
						addFailedHost(hostname);
						hostname = null;
						throw new RuntimeException(e);
					}
				}
			}
			// Check the current iterator. If exhausted, get a new one.
			while (iterator != null) {
				try {
					if (iterator.hasNext()) {
						return true;
					};
				} catch (Throwable t) {
					// An exception while checking for more records.
					// If we should delay the exceptions, add to the list, otherwise re-throw. 
					log.error(String.format("Error checking next object: %s", t.getMessage()));
					if (maxRetries != 0 && (!isRetryable(t) || !requeue())) {
						if (delayExceptions) {
							addFailedHost(hostname);
							errors.add(t.getMessage());
						} else {
							throw new RuntimeException(t);
						}
					} else if (maxRetries == 0) {
						addFailedHost(hostname);
						hostname = null;
						throw new RuntimeException(t);
					}
				}
				closeCurrentConnector();
				iterator = null;
				while (iterator == null) {
					try {
						nextIterator();
						if (iterator == null) {
							// Queue exhausted
							break;
						}
					} catch (GeneralException | ConnectorException e) {
						if (log.isTraceEnabled()) {
							log.error(Util.stackToString(e));
						} else {
							log.error(e.getMessage());
						}
						if (maxRetries != 0 && (!isRetryable(e) || !requeue())) {
							if (delayExceptions) {
								addFailedHost(hostname);
								hostname = null;
								errors.add(e.getMessage());
							} else {
								throw new RuntimeException(e);
							}
						} else if (maxRetries == 0) {
							addFailedHost(hostname);
							hostname = null;
							throw new RuntimeException(e);
						}
						iterator = null;
					}
				}
			}
			// If any exceptions have been collected, throw them now.
			throwErrors();
			return false;
		}
		
		/**
		 * Update the values of attributes marked as entitlements on the ResourceObject.
		 * @param object
		 * @throws GeneralException
		 */
		private void updateResourceObjectEntitlementNames(ResourceObject object) throws GeneralException {
			if (log.isDebugEnabled()) {
				log.debug(String.format("Enter: updateResourceObjectEntitlementNames(%s)", object));
			}
			MultiAppUtils.updateResourceObjectEntitlementNames(application, adapter.getObjectNameFormat(), object, hostname);
		}
		
		/**
		 * Update the names (identity name, display name) in the ResourceObject to match the configured format.
		 * 
		 * @param object
		 * @throws GeneralException
		 */
		private void updateResourceObjectNames(ResourceObject object) throws GeneralException {
			if (log.isDebugEnabled()) {
				log.debug(String.format("Enter: updateResourceObjectNames(%s)", object));
			}
			MultiAppUtils.updateResourceObjectNames(application, adapter.getObjectNameFormat(), object, hostname);
		}		

		@Override
		public ResourceObject next() {
			if (log.isDebugEnabled()) {
				log.debug("Enter: next()");
			}
			try {
				ResourceObject object = null;
				try {
					object = (ResourceObject) iterator.next();
				} catch (Throwable t) {
					// An exception while getting the next record.
					// If we should delay the exceptions, add to the list, otherwise re-throw. 
					log.error(String.format("Exception while getting next object for application '%s': %s", this.application.getName(), t.getMessage()));
					if (maxRetries != 0 && (!isRetryable(t) || !requeue())) {
						if (this.delayExceptions) {
							this.errors.add(t.getMessage());
						} else {
							throw new RuntimeException(t);
						}
					} else if (maxRetries == 0) {
						throw new RuntimeException(t);
					}
				}
				if (object != null) {
					updateResourceObjectNames(object);
					updateResourceObjectEntitlementNames(object);
					if (log.isTraceEnabled()) {
						log.trace(String.format("next(): returning ResourceObject:\n%s\n", object.toXml())); 
					}
					return object;
				}
			} catch (GeneralException e) {
				log.error(Util.stackToString(e));
			}
			return null;
		}

	}
	
	/**
	 * Define accepted formats for object names.
	 * 
	 * @author menno.pieters
	 *
	 */
	public enum ObjectNameFormat {
		AT("<objectname>@<hostname>", "^(?<objectname>[^@]+)@(?<hostname>[A-Za-z0-9\\._-]+)$"),
		HASH("<objectname>#<hostname>", "^(?<objectname>[^#]+)#(?<hostname>[A-Za-z0-9\\._-]+)$"),
		COLON("<hostname>:<objectname>", "^(?<hostname>[A-Za-z0-9\\._-]+):(?<objectname>[^:]+)$"),
		SLASH("<hostname>/<objectname>", "^(?<hostname>[A-Za-z0-9\\._-]+)/(?<objectname>[^/]+)$"),
		BLOCK("[<hostname>]<objectname>", "^\\[(?<hostname>[A-Za-z0-9\\._-]+)\\](?<objectname>.+)$"),
		BACKSLASH("<hostname>\\<objectname>", "^(?<hostname>[A-Za-z0-9\\._-]+)\\\\(?<objectname>[^\\\\]+)$");
		
		private String _format;
		private String _regex;
		
		/**
		 * Private Constructor.
		 * 
		 * @param _format
		 * @param _regex
		 */
		private ObjectNameFormat(String format, String regex) {
			this._format = format;
			this._regex = regex;
		}
		
		/**
		 * Check for any disallowed characters from the host name.
		 * 
		 * @param hostname
		 * @return
		 * @throws GeneralException 
		 */
		private void checkHostName(final String hostname) throws GeneralException {
			if (Util.isNotNullOrEmpty(hostname)) {
				for (int i = 0 ; i < hostname.length(); i++) {
					char c = hostname.charAt(i);
					if (!
							(
								(c >= '0' && c <= '9') ||
								(c >= 'A' && c <= 'Z') ||
								(c >= 'a' && c <= 'z') ||
								c == '.' ||
								c == '_' ||
								c == '-'
							)
						) {
						throw new GeneralException(String.format("Disallowed character '%s' in hostname '%s'", c, hostname));
					}
				}
				return;
			}
			throw new GeneralException("Null or empty hostname");
		}
		
		/**
		 * Format a string as specified by the _format.
		 * 
		 * @param objectname
		 * @param hostname
		 * @return
		 * @throws GeneralException 
		 */
		public String format(String objectname, String hostname) throws GeneralException {
			if (Util.isNotNullOrEmpty(_format) && Util.isNotNullOrEmpty(objectname) && Util.isNotNullOrEmpty(hostname)) {
				checkHostName(hostname);
				String result = _format.replace("<objectname>", objectname).replace("<hostname>", hostname);
				return result;
			}
			return null;
		}
		
		/**
		 * Retrieve the named element from the string as specified by the regular expression.
		 * 
		 * @param name
		 * @param group
		 * @return
		 */
		private String getElement(String name, String group) {
			if (Util.isNotNullOrEmpty(name) && Util.isNotNullOrEmpty(_regex)) {
				 Pattern p = Pattern.compile(this._regex);
				 Matcher m = p.matcher(name);
				 if (m.matches() && m.groupCount() >= 2) {
					 return m.group(group);
				 }
			}
			return null;
		}
		
		/**
		 * Check whether the provided string matches the regular expression for this variant of the enum.
		 * 
		 * @param name
		 * @return
		 */
		public boolean matches(String name) {
			if (Util.isNotNullOrEmpty(name) && Util.isNotNullOrEmpty(_regex)) {
				 Pattern p = Pattern.compile(this._regex);
				 Matcher m = p.matcher(name);
				 if (m.matches() && m.groupCount() >= 2) {
					 return true;
				 }
			}
			return false;
		}
		
		/**
		 * Retrieve the object name part from the specified string.
		 * 
		 * @param name
		 * @return
		 */
		public String getObjectName(String name) {
			if (Util.isNotNullOrEmpty(name) && Util.isNotNullOrEmpty(_regex)) {
				return getElement(name, "objectname");
			}
			return null;
		}
		
		/**
		 * Retrieve the host name part from the specified string.
		 * 
		 * @param name
		 * @return
		 */
		public String getHostName(String name) {
			if (Util.isNotNullOrEmpty(name) && Util.isNotNullOrEmpty(_regex)) {
				return getElement(name, "hostname");
			}
			return null;
		}
	}
	
	/**
	 * 
	 * @author menno.pieters@sailpoint.com
	 *
	 */
	public static class MultiAppUtils {
		
		private final static Logger log = Logger.getLogger(MultiAppUtils.class);
		
		/**
		 * Apply the template for the object format for the provided object name and hostname.
		 * 
		 * @param template
		 * @param objectName
		 * @param hostname
		 * @return
		 * @throws GeneralException
		 */
		public static String applyObjectNameTemplate(String template, String objectName, String hostname) throws GeneralException {
			if (log.isDebugEnabled()) {
				log.debug(String.format("Enter: applyObjectNameTemplate(%s, %s, %s)", template, objectName, hostname));
			}
			try {
				ObjectNameFormat objectNameFormat = ObjectNameFormat.valueOf(template);
				if (objectNameFormat != null) {
					return objectNameFormat.format(objectName, hostname);
				}
			} catch (java.lang.IllegalArgumentException e) {
				log.error(e);
			}
			return null;
		}

		/**
		 * Apply the object format for the provided object name and hostname.
		 * 
		 * @param objectNameFormat
		 * @param objectName
		 * @param hostname
		 * @return
		 * @throws GeneralException
		 */
		public static String applyObjectNameTemplate(ObjectNameFormat objectNameFormat , String objectName, String hostname) throws GeneralException {
			if (log.isDebugEnabled()) {
				log.debug(String.format("Enter: applyObjectNameTemplate(%s, %s, %s)", objectNameFormat, objectName, hostname));
			}
			if (objectNameFormat != null) {
				return objectNameFormat.format(objectName, hostname);
			}
			return null;
		}
		
		/**
		 * Try to identify the format of an object name.
		 * 
		 * @param name
		 * @return
		 */
		public static ObjectNameFormat identifyNameFormat(String name) {
			if (log.isDebugEnabled()) {
				log.debug(String.format("Enter: identifyNameFormat(%s)", name));
			}
			for (ObjectNameFormat f: ObjectNameFormat.values()) {
				if (log.isTraceEnabled()) {
					log.trace(String.format("Trying format %s", f.toString()));
				}
				if (f.matches(name)) {
					return f;
				}
			}
			return null;
		}

		/**
		 * Update the values of attributes marked as entitlements on the ResourceObject.
		 * 
		 * @param application
		 * @param adapter
		 * @param object
		 * @param hostname
		 * @throws GeneralException
		 */
		@SuppressWarnings("unchecked")
		public static void updateResourceObjectEntitlementNames(Application application, ObjectNameFormat f, ResourceObject object, String hostname) throws GeneralException {
			if (log.isDebugEnabled()) {
				log.debug(String.format("Enter: updateResourceObjectEntitlementNames(%s, %s, %s, %s)", application, f, object, hostname));
			}
			if (object != null) {
				String objectType = object.getObjectType();
				Schema schema = application.getSchema(objectType);
				// Potential null pointer issue - accepted risk, as that indicates a much bigger issue
				List<AttributeDefinition> entitlements = schema.getEntitlementAttributes();
				if (entitlements != null && !entitlements.isEmpty()) {
					for (AttributeDefinition entitlement: entitlements) {
						String entitlementName = entitlement.getName();
						Object v = object.get(entitlementName);						
						if (v != null) {
							if (entitlement.isMultiValued()) {
								List<String> values;
								if (v instanceof List) {
									values = (List<String>) v;
								} else {
									values = Util.csvToList(Util.otos(v), true);
								}
								List<String> newValues = new ArrayList<String>();
								for (String value: values) {
									newValues.add(f.format(value, hostname));
								}
								object.put(entitlementName, newValues);
							} else {
								String value = Util.otos(v);
								object.put(entitlementName, f.format(value, hostname));
							}
						}
					}
				}
			}
		}
		
		/**
		 * Update the names (identity name, display name) in the ResourceObject to match the configured format.
		 * 
		 * @param application
		 * @param adapter
		 * @param object
		 * @param hostname
		 * @throws GeneralException
		 */
		public static void updateResourceObjectNames(Application application, ObjectNameFormat f, ResourceObject object, String hostname) throws GeneralException {
			if (log.isDebugEnabled()) {
				log.debug(String.format("Enter: updateResourceObjectNames(%s, %s, %s, %s)", application, f, object, hostname));
			}
			if (object != null) {
				if (log.isTraceEnabled()) {
					log.trace(String.format("updateResourceObjectNames: processing ResourceObject:\n%s\n", object.toXml()));
				}
				String objectType = object.getObjectType();
				Schema schema = application.getSchema(objectType);
				// Potential null pointer issue - accepted risk, as that indicates a much bigger issue
				String idNameAttr = schema.getIdentityAttribute();
				String displayNameAttr = schema.getDisplayAttribute();
				
				String identityName = object.getIdentity();
				if (log.isTraceEnabled()) {
					log.trace(String.format("updateResourceObjectNames: identityName before formatting: %s", identityName));
				}
				identityName = f.format(identityName, hostname);
				if (log.isTraceEnabled()) {
					log.trace(String.format("updateResourceObjectNames: identityName after formatting: %s", identityName));
				}
				object.setIdentity(identityName);
				object.put(idNameAttr, identityName);
				if (Util.nullSafeEq(idNameAttr, displayNameAttr, true, true)) {
					object.setDisplayName(identityName);
				} else {
					if (application.getBooleanAttributeValue(ARG_CHANGE_DISPLAY_NAME)) {
						String displayName = object.getDisplayName();
						displayName = f.format(displayName, hostname);
						object.setDisplayName(displayName);
						object.put(displayNameAttr, displayName);
					}
				}
			}
		}
		
		public static List<String> stripHostName(List<Object> names, ObjectNameFormat f) {
			if (log.isDebugEnabled()) {
				log.debug(String.format("Enter: stripHostName(%s, %s)", names, f));
			}
			if (names != null && f != null) {
				List<String> newNames = new ArrayList<String>();
				for (Object name: names) {
					String newName = f.getObjectName(Util.otos(name));
					if (Util.isNotNullOrEmpty(newName)) {
						newNames.add(newName);
					}
				}
			}
			return null;
		}
		
		/**
		 * Get the plain object name.
		 * 
		 * @param name
		 * @param f
		 * @return
		 */
		public static String stripHostName(Object name, ObjectNameFormat f) {
			if (log.isDebugEnabled()) {
				log.debug(String.format("Enter: stripHostName(%s, %s)", name, f));
			}
			if (name != null && f != null) {
				return f.getObjectName(Util.otos(name));
			}
			return null;
		}
		
		/**
		 * Update the value of an attribute request to the selected object name format.
		 * This will be for groups mostly.
		 * 
		 * @param attributeRequest
		 * @param f
		 */
		public static void updateAttributeRequestValues(AttributeRequest attributeRequest, ObjectNameFormat f) {
			if (log.isDebugEnabled()) {
				log.debug(String.format("Enter: updateAttributeRequestValues(%s, %s)", attributeRequest, f));
			}
			if (attributeRequest != null && f != null) {
				Object values = attributeRequest.getValue();
				if (values instanceof List) {
					@SuppressWarnings("unchecked")
					List<String> v = stripHostName((List<Object>) values, f);
					attributeRequest.setValue(v);
				} else {
					attributeRequest.setValue(stripHostName(values, f));
				}
			}
		}
		
		/**
		 * Analyze an account request. Update the groups (attribute request), native identity and display name to comply for the object name format.
		 *  
		 * @param application
		 * @param accountRequest
		 * @param f
		 */
		public static void updateAccountRequestNamesAndValues(Application application, AccountRequest accountRequest, ObjectNameFormat f) {
			if (log.isDebugEnabled()) {
				log.debug(String.format("Enter: updateAccountRequestNamesAndValues(%s, %s, %s)", application, accountRequest, f));
			}
			if (application != null && accountRequest != null && f != null) {
				if (application != null && accountRequest != null && f != null) {
					String nativeIdentity = accountRequest.getNativeIdentity();
					String objectname = f.getObjectName(nativeIdentity);
					String hostname = f.getHostName(nativeIdentity);
					
					accountRequest.setNativeIdentity(objectname);
					accountRequest.setApplication(String.format("MCATEMP-%s", hostname));
					
					Schema schema = application.getAccountSchema();
					if (schema != null) {
						List<AttributeDefinition> entitlementAttributes = schema.getEntitlementAttributes();
						if (entitlementAttributes != null) {
							for (AttributeDefinition entitlementAttribute: entitlementAttributes) {
								List<AttributeRequest> attributesRequests = accountRequest.getAttributeRequests(entitlementAttribute.getName());
								if (attributesRequests != null) {
									for (AttributeRequest attributesRequest: attributesRequests) {
										updateAttributeRequestValues(attributesRequest, f);
									}
								}
							}
						}
					}
				}						
			}			
		}

		/**
		 * Analyze an object request. Update the entitlements (attribute request), native identity and display name to comply for the object name format.

		 * @param application
		 * @param objectRequest
		 * @param f
		 */
		public static void updateObjectRequestNamesAndValues(Application application, ObjectRequest objectRequest, ObjectNameFormat f) {
			if (log.isDebugEnabled()) {
				log.debug(String.format("Enter: updateObjectRequestNamesAndValues(%s, %s, %s)", application, objectRequest, f));
			}
			if (application != null && objectRequest != null && f != null) {
				String nativeIdentity = objectRequest.getNativeIdentity();
				String objectname = f.getObjectName(nativeIdentity);
				String hostname = f.getHostName(nativeIdentity);
				String objectType = objectRequest.getType();
				
				objectRequest.setNativeIdentity(objectname);
				objectRequest.setApplication(String.format("MCATEMP-%s", hostname));
				
				Schema schema = application.getSchema(objectType);
				if (schema != null) {
					List<AttributeDefinition> entitlementAttributes = schema.getEntitlementAttributes();
					if (entitlementAttributes != null) {
						for (AttributeDefinition entitlementAttribute: entitlementAttributes) {
							List<AttributeRequest> attributesRequests = objectRequest.getAttributeRequests(entitlementAttribute.getName());
							if (attributesRequests != null) {
								for (AttributeRequest attributesRequest: attributesRequests) {
									updateAttributeRequestValues(attributesRequest, f);
								}
							}
						}
					}
				}
			}			
		}
		
		@SuppressWarnings("unchecked")
		public static void checkAttributeRequestValues(final AttributeRequest attributeRequest, final String hostname, ObjectNameFormat f) throws GeneralException {
			if (log.isDebugEnabled()) {
				log.debug(String.format("Enter: checkAttributeRequestValues(%s, %s, %s)", attributeRequest, hostname, f));
			}
			if (attributeRequest == null) {
				throw new GeneralException("AttributeRequest cannot be null");
			}
			if (hostname == null) {
				throw new GeneralException("Hostname cannot be null");
			}
			Object attributeValue = attributeRequest.getValue();
			if (attributeValue != null) {
				List<String> values = new ArrayList<String>();
				if (attributeValue instanceof String) {
					values.add((String) attributeValue);
				} else if (attributeValue instanceof List) {
					for (Object v: (List<String>) attributeValue) {
						values.add(Util.otos(v));
					}
				} else {
					values.add(Util.otoa(attributeValue));
				}
				for (String value: values) {
					if (f == null) {
						f = identifyNameFormat(value);						
					}
					if (f == null) {
						throw new GeneralException("Cannot identify object name format for value");
					}
					String h = f.getHostName(value);
					if (!Util.nullSafeEq(hostname, h, false, true)) {
						throw new MultiPlanHostnameException(String.format("Mismatch for account hostname %s and entitlement hostname %s", hostname, h));
					}
				}
			}
		}
		
		/**
 		 * Sanity check on an account request: server on entitlements must match account.
		 *
		 * @param application
		 * @param accountRequest
		 * @param f
		 * @throws GeneralException
		 */
		public static void checkAccountRequest(final Application application, final AccountRequest accountRequest, ObjectNameFormat f) throws GeneralException {
			if (log.isDebugEnabled()) {
				log.debug(String.format("Enter: checkAccountRequest(%s, %s, %s)", application, accountRequest, f));
			}
			if (application == null) {
				throw new GeneralException("Application cannot be null");
			}
			if (accountRequest == null) {
				throw new GeneralException("AccountRequest cannot be null");
			}
			String nativeIdentity = accountRequest.getNativeIdentity();
			if (f == null) {
				f = identifyNameFormat(nativeIdentity);
			}
			if (f == null) {
				throw new GeneralException("Cannot identify object name format");
			}				
			String hostname = f.getHostName(nativeIdentity);
			
			Schema schema = application.getAccountSchema();
			if (schema != null) {
				List<AttributeDefinition> entitlementAttributes = schema.getEntitlementAttributes();
				if (entitlementAttributes != null) {
					for (AttributeDefinition entitlementAttribute: entitlementAttributes) {
						List<AttributeRequest> attributesRequests = accountRequest.getAttributeRequests(entitlementAttribute.getName());
						if (attributesRequests != null) {
							for (AttributeRequest attributesRequest: attributesRequests) {
								checkAttributeRequestValues(attributesRequest, hostname, f);
							}
						}
					}
				}
			}
		}

		/**
		 * Sanity check on an account request: server on entitlements must match account.
		 * Use auto-detection for name format.
		 * 
		 * @param application
		 * @param objectRequest
		 * @throws GeneralException 
		 */
		public static void checkAccountRequest(Application application, AccountRequest accountRequest) throws GeneralException {
			if (log.isDebugEnabled()) {
				log.debug(String.format("Enter: checkAccountRequest(%s, %s, %s)", application, accountRequest));
			}
			checkAccountRequest(application, accountRequest, null);
		}
		
		/**
		 * Sanity check on an object request: server on entitlements (if any) must match account.
		 * 
		 * @param application
		 * @param objectRequest
		 * @param f
		 * @throws GeneralException
		 */
		public static void checkObjectRequest(final Application application, final ObjectRequest objectRequest, ObjectNameFormat f) throws GeneralException {
			if (log.isDebugEnabled()) {
				log.debug(String.format("Enter: checkObjectRequest(%s, %s, %s)", application, objectRequest, f));
			}
			if (application == null) {
				throw new GeneralException("Application cannot be null");
			}
			if (objectRequest == null) {
				throw new GeneralException("AccountRequest cannot be null");
			}
			String nativeIdentity = objectRequest.getNativeIdentity();
			if (f == null) {
				f = identifyNameFormat(nativeIdentity);
			}
			if (f == null) {
				throw new GeneralException("Cannot identify object name format");
			}				
			String hostname = f.getHostName(nativeIdentity);
			
			Schema schema = application.getSchema(objectRequest.getType());
			if (schema != null) {
				List<AttributeDefinition> entitlementAttributes = schema.getEntitlementAttributes();
				if (entitlementAttributes != null) {
					for (AttributeDefinition entitlementAttribute: entitlementAttributes) {
						List<AttributeRequest> attributesRequests = objectRequest.getAttributeRequests(entitlementAttribute.getName());
						if (attributesRequests != null) {
							for (AttributeRequest attributesRequest: attributesRequests) {
								checkAttributeRequestValues(attributesRequest, hostname, f);
							}
						}
					}
				}
			}
		}
		
		/**
		 * Sanity check on an object request: server on entitlements (if any) must match account.
		 * Use auto-detection for name format.
		 * 
		 * @param application
		 * @param objectRequest
		 * @throws GeneralException
		 */
		public static void checkObjectRequest(final Application application, final ObjectRequest objectRequest) throws GeneralException {
			if (log.isDebugEnabled()) {
				log.debug(String.format("Enter: checkObjectRequest(%s, %s)", application, objectRequest));
			}
			checkObjectRequest(application, objectRequest);
		}
		
		/**
		 * Try to auto-correct any attribute requests within an account request. Duplicate account requests for entitlements across accounts.
		 * 
		 * @param context
		 * @param application
		 * @param accountRequest
		 * @return
		 * @throws GeneralException 
		 */
		@SuppressWarnings("unchecked")
		public static List<AccountRequest> autoCorrectAccountRequest(final SailPointContext context, final Application application, final AccountRequest accountRequest, final ObjectNameFormat f) throws GeneralException {
			if (log.isDebugEnabled()) {
				log.debug(String.format("Enter: autoCorrectAccountRequest(%s, %s, %s)", context, application, accountRequest));
			}
			if (context == null) {
				throw new GeneralException("SailPointContext cannot be null!");
			}
			if (accountRequest == null) {
				throw new GeneralException("AccountRequest cannot be null!");
			}
			if (application == null) {
				throw new GeneralException("Application cannot be null!");				
			}
			if (f == null) {
				throw new GeneralException("ObjectNameFormat cannot be null!");				
			}
			List<AccountRequest> newAccountRequests = new ArrayList<AccountRequest>();
			Schema schema = application.getAccountSchema();
			if (schema != null) {
				List<AttributeDefinition> entitlementAttributes = schema.getEntitlementAttributes();
				if (entitlementAttributes != null && !entitlementAttributes.isEmpty()) {
					// Gather host names											
					Set<String> hostNames = new HashSet<String>();
					for (AttributeDefinition entitlementAttribute: entitlementAttributes) {
						List<AttributeRequest> attributesRequests = accountRequest.getAttributeRequests(entitlementAttribute.getName());
						if (attributesRequests != null) {
							for (AttributeRequest attributesRequest: attributesRequests) {
								Object v = attributesRequest.getValue();
								if (v != null) {
									List<String> values;
									if (v instanceof List) {
										values = (List<String>) v;
									} else {
										values = new ArrayList<String>();
										values.add(Util.otos(v));
									}
									for (String value: values) {
										String hostName = f.getHostName(value);
										if (Util.isNotNullOrEmpty(hostName)) {
											hostNames.add(hostName);
										}
									}
								}
							}
						}
					}
					
					// For each host and each entitlement, correct the attribute requests.
					Map<String, List<AccountRequest>> accountRequestMap = new HashMap<String, List<AccountRequest>>();
					for (String hostName: hostNames) {
						AccountRequest accountRequestCopy = (AccountRequest) accountRequest.deepCopy(context);
						String nativeIdentity = accountRequestCopy.getNativeIdentity();
						String simpleNativeIdenitty = f.getObjectName(nativeIdentity);
						accountRequestCopy.setNativeIdentity(f.format(simpleNativeIdenitty, hostName));
						for (AttributeDefinition entitlementAttribute: entitlementAttributes) {
							List<AttributeRequest> attributeRequests = accountRequestCopy.getAttributeRequests(entitlementAttribute.getName());
							if (attributeRequests != null) {
								for (AttributeRequest attributeRequest: attributeRequests) {
									accountRequestCopy.remove(attributeRequest);
									Object v = attributeRequest.getValue();
									if (v != null) {
										if (v instanceof List) {
											List<String> values = (List<String>) v;
											List<String> newValues = new ArrayList<String>();
											for (String value: values) {
												String h = f.getHostName(value);
												if (h != null && h.equals(hostName)) {
													newValues.add(value);
												}
											}
											if (!newValues.isEmpty()) {
												attributeRequest.setValue(newValues);
												accountRequestCopy.add(attributeRequest);																		
											}
										} else {
											String value = Util.otos(v);
											String h = f.getHostName(value);
											if (h != null && h.equals(hostName)) {
												// OK, re-add
												accountRequestCopy.add(attributeRequest);																		
											}
										}
									}
								}
							}
						}
						
						List<AccountRequest> serverAccountRequests = accountRequestMap.get(hostName);
						if (serverAccountRequests == null) {
							serverAccountRequests = new ArrayList<AccountRequest>();
						}
						serverAccountRequests.add(accountRequestCopy);
						accountRequestMap.put(hostName, serverAccountRequests);
					}
																
					// Update list of account requests
					if (!accountRequestMap.isEmpty()) {
						for (String hostName: accountRequestMap.keySet()) {
							List<AccountRequest> serverAccountRequests = accountRequestMap.get(hostName);
							if (serverAccountRequests != null && !serverAccountRequests.isEmpty()) {
								newAccountRequests .addAll(serverAccountRequests);
							}
						}
					}
					
				} else {
					log.error(String.format("No entitlement attributes? This should not happen we got an error, ignoring account request: %s", accountRequest.toXml()));
					// Not sure how we got here... ignoring
				}
			} else {
				throw new GeneralException("Cannot get account schema");
			}
			return newAccountRequests;
		}
		
		/**
		 * Try to auto-correct any attribute requests within an object request. Duplicate account requests for entitlements across objects/groups.
		 * 
		 * @param context
		 * @param application
		 * @param objectRequest
		 * @param f
		 * @return
		 * @throws GeneralException
		 */
		@SuppressWarnings("unchecked")
		public static List<ObjectRequest> autoCorrectObjectRequest(final SailPointContext context, final Application application, final ObjectRequest objectRequest, final ObjectNameFormat f) throws GeneralException {
			if (log.isDebugEnabled()) {
				log.debug(String.format("Enter: autoCorrectObjectRequest(%s, %s, %s)", context, application, objectRequest));
			}
			if (context == null) {
				throw new GeneralException("SailPointContext cannot be null!");
			}
			if (objectRequest == null) {
				throw new GeneralException("ObjectRequest cannot be null!");
			}
			if (application == null) {
				throw new GeneralException("Application cannot be null!");				
			}
			if (f == null) {
				throw new GeneralException("ObjectNameFormat cannot be null!");				
			}
			List<ObjectRequest> newObjectRequests = new ArrayList<ObjectRequest>();
			Schema schema = application.getSchema(objectRequest.getType());
			if (schema != null) {
				List<AttributeDefinition> entitlementAttributes = schema.getEntitlementAttributes();
				if (entitlementAttributes != null && !entitlementAttributes.isEmpty()) {
					// Gather host names											
					Set<String> hostNames = new HashSet<String>();
					for (AttributeDefinition entitlementAttribute: entitlementAttributes) {
						List<AttributeRequest> attributesRequests = objectRequest.getAttributeRequests(entitlementAttribute.getName());
						if (attributesRequests != null) {
							for (AttributeRequest attributesRequest: attributesRequests) {
								Object v = attributesRequest.getValue();
								if (v != null) {
									List<String> values;
									if (v instanceof List) {
										values = (List<String>) v;
									} else {
										values = new ArrayList<String>();
										values.add(Util.otos(v));
									}
									for (String value: values) {
										String hostName = f.getHostName(value);
										if (Util.isNotNullOrEmpty(hostName)) {
											hostNames.add(hostName);
										}
									}
								}
							}
						}
					}
					
					// For each host and each entitlement, correct the attribute requests.
					Map<String, List<ObjectRequest>> objectRequestMap = new HashMap<String, List<ObjectRequest>>();
					for (String hostName: hostNames) {
						ObjectRequest objectRequestCopy = (ObjectRequest) objectRequest.deepCopy(context);
						String nativeIdentity = objectRequestCopy.getNativeIdentity();
						String simpleNativeIdenitty = f.getObjectName(nativeIdentity);
						objectRequestCopy.setNativeIdentity(f.format(simpleNativeIdenitty, hostName));
						for (AttributeDefinition entitlementAttribute: entitlementAttributes) {
							List<AttributeRequest> attributeRequests = objectRequestCopy.getAttributeRequests(entitlementAttribute.getName());
							if (attributeRequests != null) {
								for (AttributeRequest attributeRequest: attributeRequests) {
									objectRequestCopy.remove(attributeRequest);
									Object v = attributeRequest.getValue();
									if (v != null) {
										if (v instanceof List) {
											List<String> values = (List<String>) v;
											List<String> newValues = new ArrayList<String>();
											for (String value: values) {
												String h = f.getHostName(value);
												if (h != null && h.equals(hostName)) {
													newValues.add(value);
												}
											}
											if (!newValues.isEmpty()) {
												attributeRequest.setValue(newValues);
												objectRequestCopy.add(attributeRequest);																		
											}
										} else {
											String value = Util.otos(v);
											String h = f.getHostName(value);
											if (h != null && h.equals(hostName)) {
												// OK, re-add
												objectRequestCopy.add(attributeRequest);																		
											}
										}
									}
								}
							}
						}
						
						List<ObjectRequest> serverObjectRequests = objectRequestMap.get(hostName);
						if (serverObjectRequests == null) {
							serverObjectRequests = new ArrayList<ObjectRequest>();
						}
						serverObjectRequests.add(objectRequestCopy);
						objectRequestMap.put(hostName, serverObjectRequests);
					}
																
					// Update list of account requests
					if (!objectRequestMap.isEmpty()) {
						for (String hostName: objectRequestMap.keySet()) {
							List<ObjectRequest> serverObjectRequests = objectRequestMap.get(hostName);
							if (serverObjectRequests != null && !serverObjectRequests.isEmpty()) {
								newObjectRequests .addAll(serverObjectRequests);
							}
						}
					}
					
				} else {
					log.error(String.format("No entitlement attributes? This should not happen we got an error, ignoring object request: %s", objectRequest.toXml()));
					// Not sure how we got here... ignoring
				}
			} else {
				throw new GeneralException("Cannot get account schema");
			}
			return newObjectRequests;
		}
		
		/**
		 * Check an object request or account request for any attribute requests that contain special names starting with 
		 * IIQ_multi and strip these from the request.
		 * 
		 * @param request
		 */
		private static void stripIIQMultiAttributes(AbstractRequest request) {
			if (log.isDebugEnabled()) {
				log.debug(String.format("Enter: stripIIQMultiAttributes(request: %s)", request));
			}
			if (request != null) {
				List<AttributeRequest> attributeRequests = request.getAttributeRequests();
				if (attributeRequests != null && !attributeRequests.isEmpty()) {
					Iterator<AttributeRequest> iterator = attributeRequests.iterator();
					while (iterator.hasNext()) {
						AttributeRequest attributeRequest = iterator.next();
						String name = attributeRequest.getName();
						if (Util.isNotNullOrEmpty(name) && name.startsWith("IIQ_multi")) {
							iterator.remove();
						}
					}
					request.setAttributeRequests(attributeRequests);
				}
			}
		}
		
		/**
		 * Check all object request or account requests in a plan for any attribute requests that contain special names 
		 * starting with IIQ_multi and strip these from the request.
		 * 
		 * @param plan
		 */
		private static void stripIIQMultiAttributes(ProvisioningPlan plan) {
			if (log.isDebugEnabled()) {
				log.debug(String.format("Enter: stripIIQMultiAttributes(plan: %s)", plan));
			}
			if (plan != null && !plan.isEmpty()) {
				if (log.isTraceEnabled()) {
					log.trace("Checking account requests");
				}
				List<AccountRequest> accountRequests = plan.getAccountRequests();
				if (accountRequests != null && !accountRequests.isEmpty()) {
					for (AccountRequest accountRequest: accountRequests) {
						stripIIQMultiAttributes(accountRequest);
					}
				}
				if (log.isTraceEnabled()) {
					log.trace("Checking object requests");
				}
				List<ObjectRequest> objectRequests = plan.getObjectRequests();
				if (objectRequests != null && !objectRequests.isEmpty()) {
					for (ObjectRequest objectRequest: objectRequests) {
						stripIIQMultiAttributes(objectRequest);
					}
				}
			}
		}
		
		
		/**
		 * Recompile the plan, so that provisioning policies get re-evaluated for object that are missing data, 
		 * or modify events turned into create events if necessary.
		 * 
		 * If any questions remain open, this will fail. It needs to be generated automatically, or simply not 
		 * be required.
		 * 
		 * @param context
		 * @param application
		 * @param plan
		 * @return
		 * @throws GeneralException
		 */
		private static ProvisioningPlan recompileCorrectedPlan(final SailPointContext context, final Application application, final ProvisioningPlan plan) throws GeneralException {
			if (log.isDebugEnabled()) {
				log.debug(String.format("Enter: recompileCorrectedPlan(%s, %s, %s)", context, application, plan));
			}
			if (context == null) {
				throw new GeneralException("SailPointContext cannot be null!");
			}
			if (plan == null) {
				throw new GeneralException("Plan cannot be null!");
			}
			if (application == null) {
				throw new GeneralException("Application cannot be null!");				
			}
			Provisioner provisioner = new Provisioner(context);
			// Recompile the plan.
			ProvisioningProject project = provisioner.compile(plan);
			
			if (project.hasQuestions()) {
				if (log.isTraceEnabled()) {
					log.trace(project.toXml());
				}
				throw new GeneralException("Cannot auto-correct plan: provisioning questions unanswered.");
			}

			// Get the recompiled plan from the project.
			if (log.isTraceEnabled()) {
				log.trace(String.format("Project: %s", project.toXml()));
			}

			ProvisioningPlan rcplan = project.getPlan(application.getName());
			if (log.isTraceEnabled()) {
				log.trace(String.format("Plan after recompiling: %s", (rcplan == null)?"NULL":rcplan.toXml()));
			}
			if (rcplan != null) {
				stripIIQMultiAttributes(rcplan);
			}
			return rcplan;
		}
		
		/**
		 * Analyze a provisioning plan. Check for incorrect attribute values not matching the account host name. 
		 * Correct or ignore if configured to do so. Otherwise, fail hard with an exception.
		 * 
		 * This method is useful in a Before Provisioning Rule to correct a plan before it is sent to the connector.
		 * The connector itself will also use this method, but will neither ignore, nor autocorrect the plan. It will
		 * just fail hard.
		 * 
		 * @param context
		 * @param application
		 * @param plan
		 * @param ignoreIncorrect
		 * @param autoCorrect
		 * @throws GeneralException
		 */
		public static void checkPlanPreProvisioning(final SailPointContext context, final Application application, ProvisioningPlan plan, boolean ignoreIncorrect, boolean autoCorrect) throws GeneralException {
			if (log.isDebugEnabled()) {
				log.debug(String.format("Enter: checkPlanPreProvisioning(%s, %s, %s, %b, %b)", context, application, plan, ignoreIncorrect, autoCorrect));
			}
			if (plan == null) {
				throw new GeneralException("Plan cannot be null!");
			}
			if (application == null) {
				throw new GeneralException("Application cannot be null!");				
			}
			if (log.isTraceEnabled()) {
				log.trace(String.format("Checking plan: %s", plan.toXml()));
			}
			if (application.getBooleanAttributeValue(ARG_SKIP_CHECK_AUTOCORRECTED) && Util.otob(plan.get(PLAN_ARG_AUTOCORRECTED))) {
				if (log.isDebugEnabled()) {
					log.debug("Plan has been marked as already corrected - skipping check");
				}
				return;
			}
			
			boolean corrected = false;
			ObjectNameFormat f = ObjectNameFormat.valueOf(application.getStringAttributeValue(MultiConnectorAdapter.ARG_OBJECT_NAME_FORMAT));
			
			List<AccountRequest> accountRequests = plan.getAccountRequests();
			if (accountRequests != null && !accountRequests.isEmpty()) {
				List<AccountRequest> newAccountRequests = new ArrayList<AccountRequest>();
				for (AccountRequest accountRequest: accountRequests) {
					if (application.getName().equals(accountRequest.getApplication())) {
						try {
							checkAccountRequest(application, accountRequest, f);
							// All OK, add back to the plan
							newAccountRequests.add(accountRequest);
						} catch (MultiPlanHostnameException e) {
							if (log.isInfoEnabled()) {
								log.info(String.format("Caught exception while checking account request: %s", e.getMessage()));
							}
							if (!ignoreIncorrect) {
								if (autoCorrect) {
									log.info(String.format("Attempt to autocorrect account request %s\n%s", accountRequest, e.getMessage()));
									List<AccountRequest> correctedAccountRequests = autoCorrectAccountRequest(context, application, accountRequest, f);
									if (correctedAccountRequests != null && !correctedAccountRequests.isEmpty()) {
										newAccountRequests.addAll(correctedAccountRequests);
									}
									corrected = true;
								} else {
									throw new GeneralException(e);
								}
							} else {
								log.warn(String.format("Ignoring incorrect account request: %s\n%s", e.getMessage(), accountRequest.toXml()));
							}
						} catch (GeneralException e) {
							log.error(String.format("Fatal error checking plan: %s", e.getMessage()));
							throw new GeneralException(e);
						}
					} else {
						newAccountRequests.add(accountRequest);
					}
				}
				plan.setAccountRequests(newAccountRequests);
			}
			
			// Check/update ObjectRequest.
			List<ObjectRequest> objectRequests = plan.getObjectRequests();
			if (objectRequests != null && !objectRequests.isEmpty()) {
				List<ObjectRequest> newObjectRequests = new ArrayList<ObjectRequest>();
				for (ObjectRequest objectRequest: objectRequests) {
					if (application.getName().equals(objectRequest.getApplication())) {
						try {
							checkObjectRequest(application, objectRequest, f);
							// All OK, add back to the plan
							newObjectRequests.add(objectRequest);
						} catch (MultiPlanHostnameException e) {
							if (!ignoreIncorrect) {
								if (autoCorrect) {
									log.info(String.format("Attempt to autocorrect object request %s\n%s", objectRequest, e.getMessage()));
									List<ObjectRequest> correctedObjectRequests = autoCorrectObjectRequest(context, application, objectRequest, f);
									if (correctedObjectRequests != null && !correctedObjectRequests.isEmpty()) {
										newObjectRequests.addAll(correctedObjectRequests);
									}
									corrected = true;
								} else {
									throw new GeneralException(e);
								}
							} else {
								log.warn(String.format("Ignoring incorrect object request: %s\n%s", e.getMessage(), objectRequest.toXml()));
							}
						} catch (GeneralException e) {
							log.error(String.format("Fatal error checking plan: %s", e.getMessage()));
							throw new GeneralException(e);
						}
					} else {
						newObjectRequests.add(objectRequest);
					}
				}
				plan.setObjectRequests(newObjectRequests);
			}
			
			if (autoCorrect && corrected) {
				log.error("Recompile plan");
				ProvisioningPlan rcplan = recompileCorrectedPlan(context, application, plan);
				if (rcplan != null) {
					plan.setAccountRequests(rcplan.getAccountRequests());
					plan.setObjectRequests(rcplan.getObjectRequests());
				} else {
					plan.setAccountRequests(new ArrayList<AccountRequest>());
					plan.setObjectRequests(new ArrayList<ObjectRequest>());
				}
				
				plan.put(PLAN_ARG_AUTOCORRECTED, true);
			}
		}
		
		/**
		 * Get the named configuration from the list of server configurations.
		 * 
		 * @param serverList
		 * @param hostname
		 * @return
		 * @throws GeneralException
		 */
		public static Map<String,Object> getServerByName(List<Map<String,Object>> serverList, String hostname) throws GeneralException {
			if (log.isDebugEnabled()) {
				log.debug(String.format("Enter: getServerByName(%s, %s)", serverList, hostname));
			}
			if (Util.isNotNullOrEmpty(hostname)) {
				if (serverList != null) {
					for (Map<String,Object> server: serverList) {
						if (hostname.equals(server.get(ATTR_MULTI_HOSTID))) {
							return server;
						}
					}
				}
			}
			return null;
		}
		
		/**
		 * Create a copy of the master application with server-specific settings.
		 * 
		 * @param context
		 * @param application
		 * @param template
		 * @param server
		 * @return
		 * @throws GeneralException
		 */
		public static Application createServerApplication(final SailPointContext context, final Application application, final String connectorClassName, Map<String,Object> server) throws GeneralException {
			if (log.isDebugEnabled()) {
				log.debug(String.format("Enter: createServerApplication(%s, %s, %s, %s)", context, application, connectorClassName, server));
			}
			if (application != null && server != null && Util.isNotNullOrEmpty(connectorClassName)) {
				if (log.isTraceEnabled()) {
					log.trace(String.format("Base application: %s", application.toXml()));
				}
				String hostId = (String) server.get(ATTR_MULTI_HOSTID);
				if (Util.isNullOrEmpty(hostId)) {
					throw new GeneralException("Server definition missing host Id");
				}				
				Application clonedTemplate = (Application) application.deepCopy((Resolver) context);
				clonedTemplate.setName(String.format("MCATEMP-%s", hostId));
				clonedTemplate.setId(Util.uuid()); // Set a random id!
				clonedTemplate.setConnector(connectorClassName);
				
				// Remove excluded attributes.
				List<String> excludedAttributes = Arrays.asList(MultiConnectorAdapter.EXCLUDED_ATTRIBUTES);
				for (String excludedAttribute: excludedAttributes) {
					if (clonedTemplate.getAttributes().containsKey(excludedAttribute)) {
						clonedTemplate.getAttributes().remove(excludedAttribute);
					}
				}
				
				// Copy attributes from server configuration
				clonedTemplate.getAttributes().putAll(server);				
				// Copy schema definitions to ensure a null id
				List<Schema> masterSchemas = application.getSchemas();
				List<Schema> schemas = new ArrayList<Schema>();
				for (Schema masterSchema: masterSchemas) {
					Schema schema = (Schema) masterSchema.deepCopy((Resolver) context);
					schema.setId(null);
					schemas.add(schema);
				}
				clonedTemplate.setSchemas(schemas);
				
				if (log.isTraceEnabled()) {
					log.trace(String.format("Server application: \n%s\n", clonedTemplate.toXml()));
				}
				return clonedTemplate;
			}
			return null;
		}
		
		/**
		 * Instantiate a connector given a class name and application definition.
		 * 
		 * @param connectorName
		 * @param serverApplication
		 * @param instance
		 * @return
		 * @throws GeneralException
		 */
		public static Connector getConnectorFromTemplate(String connectorName, Application serverApplication, String instance) throws GeneralException {
			if (log.isDebugEnabled()) {
				log.debug(String.format("Enter: getConnectorFromTemplate(%s, %s, %s)", connectorName, serverApplication, instance));
			}
			if (Util.isNotNullOrEmpty(connectorName) && serverApplication != null) {
				serverApplication.setConnector(connectorName);
				Connector conn = ConnectorFactory.getConnector(serverApplication, instance);
				if (conn instanceof ConnectorProxy) {
					return ((ConnectorProxy) conn).getInternalConnector();
				} else {
					return conn;
				}

			}
			return null;
		}
	}
	
	/**
	 * This class implements a threaded process that takes Account or Object Requests from a shared queue to provision.
	 * 
	 * @author menno.pieters
	 *
	 */
	public class MultiThreadedProvisioner extends Thread {
		
		private final Logger log = Logger.getLogger(MultiThreadedProvisioner.class);
		
		private Queue<AbstractRequest> queue = null;
		private List<AbstractRequest> results = null;
		private Identity identity = null;
		private Attributes<String,Object> arguments = null;
		private ObjectNameFormat format = null;
		private Application application = null;
		private String connectorClassName = null;
		private List<Map<String,Object>> serverList = null;
		private String instance = null;
		
		private SailPointContext context = null;
		
		/**
		 * Constructor.
		 * 
		 * @param format
		 * @param application
		 * @param connectorClassName
		 * @param instance
		 * @param serverList
		 * @param queue
		 * @param arguments
		 * @throws GeneralException
		 */
		public MultiThreadedProvisioner(ObjectNameFormat format, Application application, String connectorClassName, String instance, List<Map<String,Object>> serverList, Queue<AbstractRequest> queue, Attributes<String,Object> arguments) throws GeneralException {
			super();
			if (queue == null) {
				throw new GeneralException("Null queue: cannot initialize MultiThreadedProvisioner");
			}
			if (format == null) {
				throw new GeneralException("Null ObjectNameFormat: cannot initialize MultiThreadedProvisioner");
			}
			if (application == null) {
				throw new GeneralException("Null master application: cannot initialize MultiThreadedProvisioner");				
			}
			if (connectorClassName == null) {
				throw new GeneralException("Null connectorClassName: cannot initialize MultiThreadedProvisioner");				
			}
			if (serverList == null) {
				throw new GeneralException("Null server list: cannot initialize MultiThreadedProvisioner");								
			}
			this.queue = queue;
			this.results = new ArrayList<AbstractRequest>();
			this.arguments = arguments;
			this.format = format;
			this.application = application;
			this.connectorClassName = connectorClassName;
			this.instance = instance;
			this.serverList = serverList;
		}
		
		/**
		 * Return the list of processed account/object requests.
		 * 
		 * @return
		 */
		public List<AbstractRequest> getResults() {
			return results;
		}
		
		/**
		 * Get the identity object.
		 * 
		 * @param identity
		 */
		public void setIdentity(Identity identity) {
			this.identity = identity;
		}
		
		/**
		 * Get the identity object.
		 * 
		 * @return
		 */
		public Identity getIdentity() {
			return identity;
		}

		/**
		 * Provison an account request.
		 * This will create an instance of the application definition
		 * 
		 * @param identity
		 * @param accountRequest
		 * @param arguments
		 * @return
		 * @throws GeneralException
		 * @throws ConnectorException
		 */
		private ProvisioningResult provision(Identity identity, AccountRequest accountRequest, Attributes<String,Object> arguments) throws GeneralException, ConnectorException {
			if (log.isDebugEnabled()) {
				log.debug(String.format("Enter: provision(%s, %s, %s)", identity, accountRequest, arguments));
			}
			if (identity == null) {
				if (log.isTraceEnabled()) {
					log.trace("Identity is null); trying to get identity from account request");
				}
				// Try to derive from accountRequest
				Link link = getLinkFromAccountRequest(accountRequest);
				if (link != null) {
					if (log.isTraceEnabled()) {
						log.trace(String.format("Found existing link for account request:\n%s", link.toXml()));
					}
					identity = link.getIdentity();
					if (log.isTraceEnabled() && identity != null) {
						log.trace(String.format("Found identity from link for account request:\n%s", identity.getName()));
					}
				}
			}
			if (identity == null) {
				log.error("Null identity - may result in provision issues"); 
			}
			
			if (accountRequest != null) {
				ProvisioningPlan plan = new ProvisioningPlan();
				if (arguments != null) {
					plan.setArguments(arguments);
				}
				AccountRequest subAccountRequest = (AccountRequest) accountRequest.deepCopy(context);
				String nativeIdentity = accountRequest.getNativeIdentity();
				ObjectNameFormat f = MultiAppUtils.identifyNameFormat(nativeIdentity);
				if (f == null) {
					throw new GeneralException(String.format("Unrecognized object name format: %s", nativeIdentity));
				}
				String hostname = f.getHostName(nativeIdentity);
				
				// Get config for server
				Map<String,Object> server = MultiAppUtils.getServerByName(serverList, hostname);
				// Get connector
				Application serverApplication = MultiAppUtils.createServerApplication(context, application, connectorClassName, server);
				Connector connector = MultiAppUtils.getConnectorFromTemplate(connectorClassName, serverApplication, instance);
				
				// Update the object request
				MultiAppUtils.updateAccountRequestNamesAndValues(getApplication(), subAccountRequest, f);
				plan.add(subAccountRequest);
				
				if (log.isTraceEnabled()) {
					log.trace(String.format("Plan for account request before provisioning:\n%s", plan.toXml()));
				}

				// Provision
				ProvisioningResult result = connector.provision(plan);
				connector.destroy(new HashMap<String,Object>());				
				if (log.isTraceEnabled()) {
					log.trace(String.format("Provisioning result for account request:\n%s", (result != null)?result.toXml():"NULL"));
					log.trace(String.format("Plan for account request after provisioning:\n%s", plan.toXml()));
					log.trace(String.format("Account request after provisioning:\n%s", subAccountRequest.toXml()));
				}
				
				ProvisioningResult accountResult = subAccountRequest.getResult();
				if (accountResult != null) {
					result = accountResult;
					ResourceObject object = result.getObject();
					if (object != null) {
						MultiAppUtils.updateResourceObjectNames(getApplication(), format, object, hostname);
						MultiAppUtils.updateResourceObjectEntitlementNames(getApplication(), format, object, hostname);
						result.setObject(object);
						if (log.isTraceEnabled()) {
							log.trace(String.format("ResourceObject from provisioning result:\n%s", object.toXml()));
						}
					}
				}
				accountRequest.setResult(result);
				
				return result;
			}
			return null;
		}
		
		private ProvisioningResult provision(ObjectRequest objectRequest, Attributes<String,Object> arguments) throws GeneralException, ConnectorException {
			if (log.isDebugEnabled()) {
				log.debug(String.format("Enter: provision(%s, %s)", objectRequest, arguments));
			}
			if (objectRequest != null) {
				ProvisioningPlan plan = new ProvisioningPlan();
				if (arguments != null) {
					plan.setArguments(arguments);
				}
				ObjectRequest subObjectRequest = (ObjectRequest) objectRequest.deepCopy(context);
				String nativeIdentity = objectRequest.getNativeIdentity();
				ObjectNameFormat f = MultiAppUtils.identifyNameFormat(nativeIdentity);
				if (f == null) {
					throw new GeneralException(String.format("Unrecognized object name format: %s", nativeIdentity));
				}
				String hostname = f.getHostName(nativeIdentity);
				
				// Get config for server
				Map<String,Object> server = MultiAppUtils.getServerByName(serverList, hostname);
				// Get connector
				Application serverApplication = MultiAppUtils.createServerApplication(context, application, connectorClassName, server);
				Connector connector = MultiAppUtils.getConnectorFromTemplate(connectorClassName, serverApplication, instance);
				
				// Update the object request
				MultiAppUtils.updateObjectRequestNamesAndValues(getApplication(), subObjectRequest, f);
				plan.add(subObjectRequest);
				
				if (log.isTraceEnabled()) {
					log.trace(String.format("Plan for object request:\n%s", plan.toXml()));
				}

				// Provision
				ProvisioningResult result = connector.provision(plan);
				connector.destroy(new HashMap<String,Object>());
				if (log.isTraceEnabled()) {
					log.trace(String.format("Provisioning result for object request:\n%s", (result != null)?result.toXml():"NULL"));
					log.trace(String.format("Plan for object request after provisioning:\n%s", plan.toXml()));
					log.trace(String.format("Object request after provisioning:\n%s", subObjectRequest.toXml()));
				}
				
				ProvisioningResult objectResult = subObjectRequest.getResult();
				if (objectResult != null) {
					result = objectResult;
					ResourceObject object = result.getObject();
					if (object != null) {
						MultiAppUtils.updateResourceObjectNames(getApplication(), format, object, hostname);
						MultiAppUtils.updateResourceObjectEntitlementNames(getApplication(), format, object, hostname);
						result.setObject(object);
						if (log.isTraceEnabled()) {
							log.trace(String.format("ResourceObject from provisioning result:\n%s", object.toXml()));
						}
					}
				}
				objectRequest.setResult(result);
				
				return result;
			}
			return null;
		}
		
		public void run() {
			try {
				context = SailPointFactory.createContext();
				if (queue != null && results != null) {
					results.clear();
					while (!queue.isEmpty()) {
						AbstractRequest request = queue.poll();
						if (request instanceof AccountRequest) {
							try {
								this.provision(identity, (AccountRequest) request, arguments);
							} catch (GeneralException | ConnectorException e) {
								log.error(String.format("Error provisioning account request: %s", e.getMessage()));
								if (log.isTraceEnabled()) {
									log.error(Util.stackToString(e));
								}
								ProvisioningResult result = request.getResult();
								if (result == null || Util.isNullOrEmpty(result.getStatus())) {
									if (result == null) {
										result = new ProvisioningResult();
									}
									result.addError(e);
									result.setStatus(ProvisioningResult.STATUS_FAILED);
									request.setResult(result);
								}
							}
							this.results.add(request);
						}
						if (request instanceof ObjectRequest) {
							try {
								this.provision((ObjectRequest) request, arguments);
							} catch (GeneralException | ConnectorException e) {
								log.error(String.format("Error provisioning object request: %s", e.getMessage()));
								if (log.isTraceEnabled()) {
									log.error(Util.stackToString(e));
								}
								ProvisioningResult result = request.getResult();
								if (result == null || Util.isNullOrEmpty(result.getStatus())) {
									if (result == null) {
										result = new ProvisioningResult();
									}
									result.addError(e);
									result.setStatus(ProvisioningResult.STATUS_FAILED);
									request.setResult(result);
								}
							}
							this.results.add(request);
						}
						yield();
					}
				}
			} catch (Throwable e) {
				log.error(String.format("Error in provisioning thread: %s", e.getMessage()));
			} finally {
				try {
					SailPointFactory.releaseContext(context);
				} catch (GeneralException e) {
					log.error(String.format("Error releasing context in provisioning thread: %s", e.getMessage()));
				}
			}
        }		
	}
}
