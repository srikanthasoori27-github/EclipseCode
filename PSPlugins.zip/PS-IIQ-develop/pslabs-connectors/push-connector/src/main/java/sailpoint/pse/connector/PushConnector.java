/**
 * 
 */
package sailpoint.pse.connector;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import sailpoint.api.SailPointContext;
import sailpoint.api.SailPointFactory;
import sailpoint.connector.AbstractConnector;
import sailpoint.connector.Connector;
import sailpoint.connector.ConnectorException;
import sailpoint.object.Application;
import sailpoint.object.Filter;
import sailpoint.object.Link;
import sailpoint.object.ManagedAttribute;
import sailpoint.object.Partition;
import sailpoint.object.ProvisioningPlan;
import sailpoint.object.ProvisioningPlan.AccountRequest;
import sailpoint.object.ProvisioningPlan.AttributeRequest;
import sailpoint.object.ProvisioningPlan.ObjectRequest;
import sailpoint.object.ProvisioningResult;
import sailpoint.object.QueryOptions;
import sailpoint.object.ResourceObject;
import sailpoint.object.Schema;
import sailpoint.object.Application.Feature;
import sailpoint.object.AttributeDefinition;
import sailpoint.tools.CloseableIterator;
import sailpoint.tools.GeneralException;
import sailpoint.tools.Util;

/**
 * @author menno.pieters
 * 
 * 2021.06.01-0001 / 1.0.1 - PLSI-1072: fix for account creation with multi-values accounts.
 *
 */
public class PushConnector extends AbstractConnector {

	public final static String CONNECTOR_TYPE = "Push Connector";

	private final static Logger log = Logger.getLogger(PushConnector.class);
	private SailPointContext context;

	/**
	 * @param application
	 * @throws GeneralException
	 */
	public PushConnector(Application application) throws GeneralException {
		super(application);
		if (log.isDebugEnabled()) {
			log.debug(String.format("Constructor: PushConnector(%s)", application));
		}
		context = SailPointFactory.getCurrentContext();
	}

	/**
	 * @param application
	 * @param instance
	 * @throws GeneralException
	 */
	public PushConnector(Application application, String instance) throws GeneralException {
		super(application, instance);
		if (log.isDebugEnabled()) {
			log.debug(String.format("Constructor: PushConnector(%s, %s)", application, instance));
		}
		context = SailPointFactory.getCurrentContext();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see sailpoint.connector.Connector#getObject(java.lang.String,
	 * java.lang.String, java.util.Map)
	 */
	@Override
	public ResourceObject getObject(final String objectType, final String identityName, final Map<String, Object> options) throws ConnectorException {
		if (log.isDebugEnabled()) {
			log.debug(String.format("Enter: getObject(%s, %s, %s)", objectType, identityName, options));
		}
		if (AbstractConnector.TYPE_ACCOUNT.equals(objectType)) {
			List<Filter> filters = new ArrayList<Filter>();
			filters.add(Filter.eq("application.name", this.getApplication().getName()));
			filters.add(Filter.eq("nativeIdentity", identityName));
			if (this.getInstance() != null) {
				filters.add(Filter.eq("instance", this.getInstance()));
			}
			Filter filter = Filter.and(filters);

			Link link = null;
			try {
				link = context.getUniqueObject(Link.class, filter);
			} catch (GeneralException e) {
				log.error("Unable to get unique link object", e);
			}
			if (link != null) {
				Schema schema = this.getApplication().getAccountSchema();
				return linkToResourceObject(link, schema);
			}
		} else {
			Schema schema = this.getApplication().getSchema(objectType);
			List<Filter> filters = new ArrayList<Filter>();
			filters.add(Filter.eq("application.name", this.getApplication().getName()));
			filters.add(Filter.eq("attribute", schema.getIdentityAttribute()));
			filters.add(Filter.eq("value", identityName));
			if (this.getInstance() != null) {
				filters.add(Filter.eq("instance", this.getInstance()));
			}
			Filter filter = Filter.and(filters);

			ManagedAttribute managedAttribute = null;
			try {
				managedAttribute = context.getUniqueObject(ManagedAttribute.class, filter);
			} catch (GeneralException e) {
				log.error("Unable to get unique link object", e);
			}
			if (managedAttribute != null) {
				return managedAttributeToResourceObject(managedAttribute, schema);
			}
		}
		return null;
	}

	/**
	 * Convert a Link object into a ResourceObject.
	 * 
	 * @param link
	 * @return
	 */
	public static ResourceObject linkToResourceObject(Link link, Schema schema) {
		if (log.isDebugEnabled()) {
			log.debug(String.format("Enter: linkToResourceObject(%s, %s)", link, schema));
		}
		if (link != null && schema != null) {
			String identityAttr = schema.getIdentityAttribute();
			String displayAttr = schema.getDisplayAttribute();
			ResourceObject object = new ResourceObject();
			object.setObjectType(AbstractConnector.TYPE_ACCOUNT);
			object.setIdentity(link.getNativeIdentity());
			object.setInstance(link.getInstance());
			object.setUuid(link.getUuid());
			object.setDisplayName(link.getDisplayName());
			object.setAttributes(link.getAttributes());
			if (Util.isNotNullOrEmpty(identityAttr)) {
				object.put(identityAttr, link.getNativeIdentity());
			}
			if (Util.isNotNullOrEmpty(displayAttr)) {
				object.put(displayAttr, link.getDisplayName());
			}
			if (log.isTraceEnabled()) {
				log.trace(String.format("Exit: linkToResourceObject(...): %s", object.toMap()));
			}
			return object;
		}
		return null;
	}

	/**
	 * Convert a ManagedAttribute into a ResourceObject.
	 * 
	 * @param managedAttribute
	 * @param schema
	 * @return
	 */
	@SuppressWarnings("deprecation")
	public static ResourceObject managedAttributeToResourceObject(ManagedAttribute managedAttribute, Schema schema) {
		if (log.isDebugEnabled()) {
			log.debug(String.format("Enter: managedAttributeToResourceObject(%s, %s)", managedAttribute, schema));
		}
		if (managedAttribute != null && schema != null) {
			String identityAttr = schema.getIdentityAttribute();
			String displayAttr = schema.getDisplayAttribute();
			ResourceObject object = new ResourceObject();
			object.setObjectType(schema.getObjectType());
			object.setIdentity(managedAttribute.getValue());
			object.setInstance(managedAttribute.getInstance());
			object.setUuid(managedAttribute.getUuid());
			object.setDisplayName(managedAttribute.getDisplayName());
			object.setAttributes(managedAttribute.getAttributes());
			if (Util.isNotNullOrEmpty(identityAttr)) {
				object.put(identityAttr, managedAttribute.getValue());
			}
			if (Util.isNotNullOrEmpty(displayAttr)) {
				object.put(displayAttr, managedAttribute.getDisplayName());
			}
			if (log.isTraceEnabled()) {
				log.trace(String.format("Exit: managedAttributeToResourceObject(...): %s", object.toMap()));
			}
			return object;
		}
		return null;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * sailpoint.connector.Connector#getIteratorPartitions(java.lang.String,
	 * int, sailpoint.object.Filter, java.util.Map)
	 */
	@Override
	public List<Partition> getIteratorPartitions(String objectType, int suggestedPartitionCount, Filter filter, Map<String, Object> ops) throws ConnectorException {
		return null;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see sailpoint.connector.Connector#iterateObjects(java.lang.String,
	 * sailpoint.object.Filter, java.util.Map)
	 */
	@Override
	public CloseableIterator<ResourceObject> iterateObjects(final String objectType, final Filter filter, final Map<String, Object> options) throws ConnectorException {
		if (log.isDebugEnabled()) {
			log.debug(String.format("Enter: iterateObjects(%s, %s, %s)", objectType, filter, options));
		}
		try {
			if (AbstractConnector.TYPE_ACCOUNT.equals(objectType)) {
				return new LinkIterator<ResourceObject>(this.getApplication(), filter, null, null);
			} else {
				return new ManagedAttributeIterator<ResourceObject>(this.getApplication(), objectType, filter, null, null);
			}
		} catch (GeneralException e) {
			throw new ConnectorException(e);
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * sailpoint.connector.Connector#iterateObjects(sailpoint.object.Partition)
	 */
	@Override
	public CloseableIterator<ResourceObject> iterateObjects(Partition partition) throws ConnectorException {
		throw new UnsupportedOperationException();
	}
	
	/**
	 * Filter out any attribute requests for non-schema attributes.
	 * 
	 * @param schema
	 * @param accountRequest
	 */
	private void filterAccountRequest(Schema schema, AccountRequest accountRequest) {
		if (log.isDebugEnabled()) {
			log.debug(String.format("Enter: filterAccountRequest(%s,%s)", schema, accountRequest));
		}
		if (schema != null && accountRequest != null) {
			List<AttributeRequest> attributeRequests = accountRequest.getAttributeRequests();
			if (attributeRequests != null && !attributeRequests.isEmpty()) {
				Iterator<AttributeRequest> iterator = attributeRequests.iterator();
				while (iterator.hasNext()) {
					AttributeRequest attributeRequest = iterator.next();
					String name = attributeRequest.getName();
					if (Connector.ATT_IIQ_DISABLED.equals(name) || Connector.ATT_IIQ_LOCKED.equals(name)) {
						if (log.isInfoEnabled()) {
							log.info(String.format("filterAccountRequest: Allowing special attribute %s", name));
						}
						continue;
					}
					AttributeDefinition def = schema.getAttributeDefinition(name);
					if (def == null) {
						log.warn(String.format("filterAccountRequest: Attribute %s ignored, not defined on schema", name));
						iterator.remove();
					}
				}
			}
		}
	}
	
	/**
	 * Filter out any attribute requests for non-schema attributes.
	 * 
	 * @param schema
	 * @param objectRequest
	 */
	private void filterObjectRequest(Schema schema, ObjectRequest objectRequest) {
		if (log.isDebugEnabled()) {
			log.debug(String.format("Enter: filterObjectRequest(%s,%s)", schema, objectRequest));
		}
		if (schema != null && objectRequest != null) {
			List<AttributeRequest> attributeRequests = objectRequest.getAttributeRequests();
			if (attributeRequests != null && !attributeRequests.isEmpty()) {
				Iterator<AttributeRequest> iterator = attributeRequests.iterator();
				while (iterator.hasNext()) {
					AttributeRequest attributeRequest = iterator.next();
					String name = attributeRequest.getName();
					if (Connector.ATT_IIQ_DISABLED.equals(name) || Connector.ATT_IIQ_LOCKED.equals(name)) {
						if (log.isInfoEnabled()) {
							log.info(String.format("filterObjectRequest: Allowing special attribute %s", name));
						}
						continue;
					}
					AttributeDefinition def = schema.getAttributeDefinition(name);
					if (def == null) {
						log.warn(String.format("filterObjectRequest: Attribute %s ignored, not defined on schema", name));
						iterator.remove();
					}
				}
			}
		}
	}
	
	/**
	 * Convert values to their designated type.
	 * 
	 * @param schemaAttr
	 * @param value
	 * @return
	 */
	private Object convertSchemaValue(AttributeDefinition schemaAttr, Object value, boolean multi) {
		if (log.isDebugEnabled()) {
			log.debug(String.format("Enter: convertSchemaValue(%s,%s)", schemaAttr, value));			
		}
		if (schemaAttr != null && value != null) {
			if (value instanceof List) {
				if (multi) {
					return Util.otol(value);
				}
				if (((List<?>) value).isEmpty()) {
					return null;
				}
				value = ((List<?>) value).iterator().next();
			}
			if (AttributeDefinition.AttributeType.BOOLEAN.toString().equals(schemaAttr.getType())) {
				return Util.otob(value);
			}
			if (AttributeDefinition.AttributeType.INT.toString().equals(schemaAttr.getType())) {
				return Util.otoi(value);
			}
			if (AttributeDefinition.AttributeType.LONG.toString().equals(schemaAttr.getType())) {
				return Util.atol(Util.otos(value));
			}
			return Util.otos(value);
		}
		return null;
	}
	
	/**
	 * For a Create Account operation, construct a ResourceObject.
	 * 
	 * @param schema
	 * @param accountRequest
	 * @return
	 */
	private ResourceObject convertAccountCreateRequestToResourceObject(Schema schema, AccountRequest accountRequest) {
		if (log.isDebugEnabled()) {
			log.debug(String.format("Enter: convertAccountCreateRequestToResourceObject(%s,%s)", schema, accountRequest));
		}
		if (schema != null && accountRequest != null && AccountRequest.Operation.Create.equals(accountRequest.getOperation())) {
			ResourceObject object = new ResourceObject();
			object.setObjectType(Schema.TYPE_ACCOUNT);
			object.setIdentity(accountRequest.getNativeIdentity());
			String displayName = null;
			AttributeRequest displayNameRequest = accountRequest.getAttributeRequest(schema.getDisplayAttribute());
			if (displayNameRequest != null) {
				displayName = (String) displayNameRequest.getValue();
			} else {
				displayName = accountRequest.getNativeIdentity();
			}
			object.setDisplayName(displayName);
			List<AttributeDefinition> schemaAttrs = schema.getAttributes();
			if (schemaAttrs != null && !schemaAttrs.isEmpty()) {
				for (AttributeDefinition schemaAttr: schemaAttrs) {
					String name = schemaAttr.getName();
					boolean multi = schemaAttr.isMulti();
					if (multi) {
						List<AttributeRequest> schemaAttributeRequests = accountRequest.getAttributeRequests(name);
						if (schemaAttributeRequests != null && !schemaAttributeRequests.isEmpty()) {
							List<Object> values = new ArrayList<Object>();
							for (AttributeRequest schemaAttributeRequest: schemaAttributeRequests) {
								Object value = convertSchemaValue(schemaAttr, schemaAttributeRequest.getValue(), multi);
								if (value != null && !values.contains(value)) {
									values.add(value);
								}
							}
							if (!values.isEmpty()) {
								object.put(name, values);
							}
						}
					} else {
						AttributeRequest schemaAttributeRequest = accountRequest.getAttributeRequest(name);
						if (schemaAttributeRequest != null) {
							Object value = convertSchemaValue(schemaAttr, schemaAttributeRequest.getValue(), multi);
							if (value != null) {
								object.put(name, value);
							}
						}
					}
				}
			}
			if (log.isTraceEnabled()) {
				try {
					log.trace(String.format("convertAccountCreateRequestToResourceObject(): %s", object.toXml()));
				} catch (GeneralException e) {
					e.printStackTrace();
				}
			}
			return object;
		}
		return null;
	}

	private ResourceObject convertGroupCreateRequestToResourceObject(Schema schema, ObjectRequest objectRequest) {
		if (log.isDebugEnabled()) {
			log.debug(String.format("Enter: convertGroupCreateRequestToResourceObject(%s,%s)", schema, objectRequest));
		}
		if (schema != null && objectRequest != null && ProvisioningPlan.ObjectOperation.Create.equals(objectRequest.getOp())) {
			ResourceObject object = new ResourceObject();
			object.setObjectType(schema.getObjectType());
			object.setIdentity(objectRequest.getNativeIdentity());
			String displayName = null;
			AttributeRequest displayNameRequest = objectRequest.getAttributeRequest(schema.getDisplayAttribute());
			if (displayNameRequest != null) {
				displayName = (String) displayNameRequest.getValue();
			} else {
				displayName = objectRequest.getNativeIdentity();
			}
			object.setDisplayName(displayName);
			List<AttributeDefinition> schemaAttrs = schema.getAttributes();
			if (schemaAttrs != null && !schemaAttrs.isEmpty()) {
				for (AttributeDefinition schemaAttr: schemaAttrs) {
					String name = schemaAttr.getName();
					boolean multi = schemaAttr.isMulti();
					AttributeRequest schemaAttributeRequest = objectRequest.getAttributeRequest(name);
					if (schemaAttributeRequest != null) {
						Object value = null;
						if (multi) {
							value = Util.otol(schemaAttributeRequest.getValue());
						} else {
							value = Util.otos(schemaAttributeRequest.getValue());
						}
						if (value != null) {
							object.put(name, value);
						}
					}
				}
			}
			if (log.isTraceEnabled()) {
				try {
					log.trace(String.format("convertAccountCreateRequestToResourceObject(): %s", object.toXml()));
				} catch (GeneralException e) {
					e.printStackTrace();
				}
			}
			return object;
		}
		return null;
	}	
	@Override
	public ProvisioningResult provision(ProvisioningPlan plan) throws ConnectorException {
		if (log.isDebugEnabled()) {
			log.debug(String.format("Enter: testConfiguration(%s)", plan));
		}
		ProvisioningResult result = new ProvisioningResult();
		result.setStatus(ProvisioningResult.STATUS_COMMITTED);

		List<AccountRequest> accountRequests = plan.getAccountRequests(this.getApplication().getName());
		List<ObjectRequest> objectRequests = plan.getObjectRequests();
		
		// On Create add identity attribute to plan object
		if (accountRequests != null) {
			Schema schema = this.getApplication().getAccountSchema();
			for (AccountRequest accountRequest: accountRequests) {
				filterAccountRequest(schema, accountRequest);
				if (AccountRequest.Operation.Create.equals(accountRequest.getOperation())) {
					AttributeRequest attributeRequest = accountRequest.getAttributeRequest(schema.getIdentityAttribute());
					if (attributeRequest == null) {
						attributeRequest = new AttributeRequest(schema.getIdentityAttribute(), ProvisioningPlan.Operation.Set, accountRequest.getNativeIdentity());
						accountRequest.add(attributeRequest);
					}
					ProvisioningResult subResult = new ProvisioningResult();
					subResult.setStatus(ProvisioningResult.STATUS_COMMITTED);
					ResourceObject object = convertAccountCreateRequestToResourceObject(schema, accountRequest);
					if (object != null) {
						subResult.setObject(object);
					}
					accountRequest.setResult(subResult);
				}
			}
		}
		if (objectRequests != null) {
			for (ObjectRequest objectRequest: objectRequests) {
				Schema schema = this.getApplication().getSchema(objectRequest.getType());
				filterObjectRequest(schema, objectRequest);
				if (ProvisioningPlan.ObjectOperation.Create.equals(objectRequest.getOp())) {
					AttributeRequest attributeRequest = objectRequest.getAttributeRequest(schema.getIdentityAttribute());
					if (attributeRequest == null) {
						attributeRequest = new AttributeRequest(schema.getIdentityAttribute(), ProvisioningPlan.Operation.Set, objectRequest.getNativeIdentity());
						objectRequest.add(attributeRequest);
					}
					ProvisioningResult subResult = new ProvisioningResult();
					subResult.setStatus(ProvisioningResult.STATUS_COMMITTED);
					ResourceObject object = convertGroupCreateRequestToResourceObject(schema, objectRequest);
					if (object != null) {
						subResult.setObject(object);
					}
					objectRequest.setResult(subResult);
				}
			}
		}

		if (log.isTraceEnabled()) {
			try {
				log.trace(String.format("Plan after provisioning: %s", plan.toXml()));
			} catch (GeneralException e) {
				e.printStackTrace();
			}
		}
		plan.setResult(result);
		return result;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see sailpoint.connector.Connector#testConfiguration()
	 */
	@Override
	public void testConfiguration() throws ConnectorException {
		if (log.isDebugEnabled()) {
			log.debug("Enter: testConfiguration()");
		}
		// Always OK.
	}

	@Override
	public String getConnectorType() {
		if (log.isDebugEnabled()) {
			log.debug("Enter: getConnectorType()");
		}
		return CONNECTOR_TYPE;
	}

	@Override
	public List<Feature> getSupportedFeatures() {
		if (log.isDebugEnabled()) {
			log.debug("Enter: getSupportedFeatures()");
		}
		List<Feature> features = new ArrayList<Feature>();
		features.add(Feature.ENABLE);
		features.add(Feature.PROVISIONING);
		features.add(Feature.SEARCH);
		features.add(Feature.UNLOCK);
		/*
		 * Deprecated function, but kept for compatibility reasons.
		 */
		return features;
	}

	/**
	 * This iterator will search for Link objects and convert them into
	 * ResourceObjects.
	 * 
	 * @author menno.pieters
	 *
	 * @param <ResourceObject>
	 */
	@SuppressWarnings("hiding")
	public class LinkIterator<ResourceObject> implements Iterator<ResourceObject>, CloseableIterator<ResourceObject> {

		private Iterator<Link> iterator = null;
		private Application application = null;
		private QueryOptions queryOptions = null;

		/**
		 * Constructor.
		 * 
		 * @param application
		 * @param filter
		 * @param start
		 * @param limit
		 * @throws GeneralException
		 */
		public LinkIterator(Application application, Filter filter, Integer start, Integer limit) throws GeneralException {
			this.application = application;
			QueryOptions qo = new QueryOptions();
			qo.addOrdering("nativeIdentity", true);
			qo.add(Filter.eq("application.name", application.getName()));
			if (filter != null) {
				qo.add(filter);
			}
			if (limit != null && limit > 0) {
				qo.setResultLimit(limit.intValue());
			}
			if (start != null && start >= 0) {
				qo.setFirstRow(start);
			}
			this.queryOptions = qo;
		}

		@Override
		public void close() {
			Util.flushIterator(iterator);
		}

		/**
		 * Initialize the search and internal iterator.
		 * 
		 * @throws GeneralException
		 */
		private void initIterator() throws GeneralException {
			if (iterator == null) {
				this.iterator = context.search(Link.class, this.queryOptions);
			}
		}

		@Override
		public boolean hasNext() {
			boolean result = false;
			try {
				initIterator();
				result = (iterator != null && iterator.hasNext());
			} catch (GeneralException e) {
				log.error(e);
			}
			return result;
		}

		@SuppressWarnings("unchecked")
		@Override
		public ResourceObject next() {
			try {
				initIterator();
				if (iterator != null) {
					Schema schema = this.application.getAccountSchema();
					return (ResourceObject) PushConnector.linkToResourceObject(iterator.next(), schema);
				}
			} catch (GeneralException e) {
				log.error(e);
			}
			return null;
		}

	}

	/**
	 * This iterator will return ManagedAttribute objects converted into
	 * ResourceObjects for group aggregation.
	 * 
	 * @author menno.pieters
	 *
	 * @param <ResourceObject>
	 */
	@SuppressWarnings("hiding")
	public class ManagedAttributeIterator<ResourceObject> implements Iterator<ResourceObject>, CloseableIterator<ResourceObject> {

		private Iterator<ManagedAttribute> iterator = null;
		private Application application = null;
		private QueryOptions queryOptions = null;
		private String objectType = null;

		/**
		 * Constructor.
		 * 
		 * @param application
		 * @param objectType
		 * @param filter
		 * @param start
		 * @param limit
		 * @throws GeneralException
		 */
		public ManagedAttributeIterator(Application application, String objectType, Filter filter, Integer start, Integer limit) throws GeneralException {
			this.application = application;
			this.objectType = objectType;
			QueryOptions qo = new QueryOptions();
			qo.addOrdering("value", true);
			qo.add(Filter.eq("application.name", application.getName()));
			qo.add(Filter.eq("type", objectType));
			if (filter != null) {
				qo.add(filter);
			}
			if (limit != null && limit > 0) {
				qo.setResultLimit(limit.intValue());
			}
			if (start != null && start >= 0) {
				qo.setFirstRow(start);
			}
			this.queryOptions = qo;
		}

		@Override
		public void close() {
			Util.flushIterator(iterator);
		}

		/**
		 * Initialize the search and internal iterator.
		 * 
		 * @throws GeneralException
		 */
		private void initIterator() throws GeneralException {
			if (iterator == null) {
				this.iterator = context.search(ManagedAttribute.class, this.queryOptions);
			}
		}

		@Override
		public boolean hasNext() {
			boolean result = false;
			try {
				initIterator();
				result = (iterator != null && iterator.hasNext());
			} catch (GeneralException e) {
				log.error(e);
			}
			return result;
		}

		@SuppressWarnings("unchecked")
		@Override
		public ResourceObject next() {
			try {
				initIterator();
				if (iterator != null) {
					Schema schema = this.application.getSchema(objectType);
					return (ResourceObject) PushConnector.managedAttributeToResourceObject(iterator.next(), schema);
				}
			} catch (GeneralException e) {
				log.error(e);
			}
			return null;
		}

	}
}
