BeanShell Null Pointer Exception in line 0.

Yeah, I hate this error as well.  

After some investigation I found the issue is linked to the Bean Scripting Framework integration class, specifically the BeanShellBSFEngine.class which is shipped with the BeanShell library... so it isn't IdentityIQ causing this.  The Class only needed a minor fix to expose the information.

This workaround  should give you the line number and statement which caused the error.

To enable drop the BeanShellBSFEngine.class class file into the "./WEB-INF/classes/bsh/util" folder (if the folder does not exist, create it) and no more NPE in line 0 messages.
I’ve also posted up the source code here as well

DO NOT USE this code into a production, but is useful for DEV environments. 