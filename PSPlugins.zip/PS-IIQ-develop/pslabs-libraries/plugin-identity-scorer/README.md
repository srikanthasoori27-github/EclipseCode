# Plugin Identity Scorer

## Introduction

This library provides a way to more easily extend the IdentityIQ risk scoring mechanism. This library
provides a special score that acts as an adapter between IdentityIQ and a risk scorer class packed
in a plugin.

This feature allows the identity risk model to be extended using the plugin framework.

## Configuration

The configuration of the risk model is stored in the `ScoreConfig` object. In this configuration an
existing `ScoreDefinition` can be edited or a new one created, to add a new category. The `scorer`
attribute must be changed to `sailpoint.score.PluginIdentityScorer` in order to use the Plugin Identity
Scorer. Furthermore, two attributes must be added to the attributes map:
* `pluginName`: specify the name of the plugin that contains the scorer class to be used.
* `pluginClassName`: specify the full class name for the scorer. The class must implement the class `sailpoint.object.Scorer`.

Example (scorer to entitlements replaced):

```xml
    <ScoreDefinition component="true" configPage="gotoBusinessRoleCompPage" displayName="score_def_businessRoleScore_name" name="businessRoleScore" parent="rawBusinessRoleScore" scorer="sailpoint.score.PluginIdentityScorer" shortName="score_def_businessRoleScore_shortname" weight="25">
      <Attributes>
        <Map>
          <entry key="activityMonitoringFactor" value="0.5"/>
          <entry key="activityMonitoringFactorMax" value="1"/>
          <entry key="activityMonitoringFactorMin" value="0"/>
          <entry key="certifiedFactor" value="0.0"/>
          <entry key="certifiedFactorMax" value="1"/>
          <entry key="certifiedFactorMin" value="0"/>
          <entry key="compensated" value="true"/>
          <entry key="expiredFactor" value="1.5"/>
          <entry key="expiredFactorMax" value="10"/>
          <entry key="expiredFactorMin" value="1"/>
          <entry key="mitigatedFactor" value="0.5"/>
          <entry key="mitigatedFactorMax" value="1"/>
          <entry key="mitigatedFactorMin" value="0"/>
          <entry key="pluginClassName" value="com.sailpoint.score.BusinessRoleScorer"/>
          <entry key="pluginName" value="predictiveidentityservicesplugin"/>
          <entry key="remediatedFactor" value="2.0"/>
          <entry key="remediatedFactorMax" value="11"/>
          <entry key="remediatedFactorMin" value="1"/>
          <entry key="uncertifiedFactor" value="1.0"/>
          <entry key="uncertifiedFactorMax" value="11"/>
          <entry key="uncertifiedFactorMin" value="1"/>
        </Map>
      </Attributes>
      <Description>score_def_businessRoleScore_desc</Description>
    </ScoreDefinition>
```

## Plugin Implementation

A scorer class in the plugin must implement the interface `sailpoint.object.Scorer`. Due to package restrictions,
it is not possible to extend `sailpoint.score.AbstractScorer`. In case multiple scorers are packaged in a plugin,
it may be useful to create a custom abstract class to extend inside the plugin.

Note that the class loader in recent versions of IdentityIQ will not allow loading classes from packages that
start with `sailpoint.`. E.g. `sailpoint.score.MyCustomScorer` cannot be loaded, but `com.sailpoint.score.MyCustomScorer` can.

There is a special scorer configuration page named `customScoreInclude.xhtml`, which can be configured by setting the
attribute `configPage` to `gotoCustomScorePage`. The contents of this form can be defined by adding a `<Signature>` 
section to the `ScoreDefintion`. Example:

```xml
    <ScoreDefinition component="true" configPage="gotoCustomScorePage" displayName="Outlier Score" name="outlierScore" scorer="sailpoint.score.PluginIdentityScorer" shortName="Outlier" weight="25">
      <Attributes>
        <Map>
          <entry key="activityMonitoringFactor" value="0.5"/>
          <entry key="certifiedFactor" value="0.0"/>
          <entry key="disabled" value="false"/>
          <entry key="expiredFactor" value="1.5"/>
          <entry key="mitigatedFactor" value="0.5"/>
          <entry key="pluginClassName" value="com.sailpoint.score.OutlierScorer"/>
          <entry key="pluginName" value="predictiveidentityservicesplugin"/>
          <entry key="remediatedFactor" value="2.0"/>
          <entry key="score" value="400"/>
          <entry key="uncertifiedFactor" value="1.0"/>
        </Map>
      </Attributes>
      <Description>Outlier Score</Description>
      <Signature>
        <Inputs>
          <Argument defaultValue="100" helpKey="Additional score for outlier identities" name="score" type="int">
            <Prompt>Outlier Score</Prompt>
          </Argument>
        </Inputs>
      </Signature>
    </ScoreDefinition>
```
