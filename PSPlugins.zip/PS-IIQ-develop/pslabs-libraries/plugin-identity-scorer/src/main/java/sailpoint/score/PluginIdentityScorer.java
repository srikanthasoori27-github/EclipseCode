package sailpoint.score;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import sailpoint.api.SailPointContext;
import sailpoint.object.GenericIndex;
import sailpoint.object.Identity;
import sailpoint.object.Plugin;
import sailpoint.object.SailPointObject;
import sailpoint.object.ScoreConfig;
import sailpoint.object.ScoreDefinition;
import sailpoint.object.ScoreItem;
import sailpoint.object.Scorer;
import sailpoint.plugin.PluginsUtil;
import sailpoint.tools.GeneralException;
import sailpoint.tools.Util;

public class PluginIdentityScorer extends AbstractScorer {

	private static Log log = LogFactory.getLog(PluginIdentityScorer.class);

	public final static String ARG_PLUGIN_NAME = "pluginName";
	public final static String ARG_PLUGIN_CLASS_NAME = "pluginClassName";

	private Scorer scorer = null;

	public PluginIdentityScorer() {
		super();
		if (log.isDebugEnabled()) {
			log.debug("Constructor: PluginIdentityScorer()");
		}
	}
	
	private Scorer getPluginScorerClass(ScoreDefinition def) {
		if (log.isDebugEnabled()) {
			log.debug(String.format("Enter: getPluginScorerClass(%s)", def));
		}
		if (scorer != null) {
			return scorer;
		}
		String pluginName = def.getString(ARG_PLUGIN_NAME);
		String className = def.getString(ARG_PLUGIN_CLASS_NAME);
		if (log.isTraceEnabled()) {
			log.trace(String.format("Plugin name: %s; Class name: %s.", pluginName, className));
		}
		Object object = null;
		try {
			object = PluginsUtil.instantiateWithException(pluginName, className, Plugin.ClassExportType.UNCHECKED, null, null);
		} catch (GeneralException e) {
			log.error(String.format("Error getting class %s from plugin %s: %s", className, pluginName, e.getMessage()));
			if (log.isTraceEnabled()) {
				log.error(Util.stackToString(e));
			}
		}
		if (log.isTraceEnabled()) {
			log.trace(String.format("Class Object: %s", object));
		}		
		if (object instanceof Scorer) {
			if (log.isTraceEnabled()) {
				log.trace("Setting Scorer");
			}
			scorer = (Scorer) object;
		}		
		return scorer;
	}

	@Override
	public int getScore(ScoreDefinition def, GenericIndex index) {
		if (log.isDebugEnabled()) {
			log.debug(String.format("Enter: getScore(%s, %s)", def, index));
		}
		int score = 0;
		Scorer scorer = getPluginScorerClass(def);
		if (scorer != null) {
			if (log.isTraceEnabled()) {
				log.trace("Scorer found");
			}
			score = scorer.getScore(def, index);
		} else {
			log.error("Error instantiating scorer");
		}
		return score;
	}

	/**
	 * This is used only when subclassing LinkAttributeScorer used for
	 * calculating application scores. For identity scores this always returns
	 * null.
	 */
	@Override
	public ScoreItem isMatch(SailPointObject obj) throws GeneralException {
		if (log.isDebugEnabled()) {
			log.debug(String.format("Enter: isMatch(%s)", obj));
		}
		return null;
	}

	@Override
	public void score(SailPointContext context, ScoreConfig config, ScoreDefinition def, SailPointObject src, GenericIndex index) throws GeneralException {
		if (log.isDebugEnabled()) {
			log.debug(String.format("Enter: score(%s, %s, %s, %s, %s)", context, config, def, src, index));
		}
        // Make sure we're configured as an identity score
        if (!(src instanceof Identity))
            throw new GeneralException("IdentityAttributeScorer called with non-Identity");

		Scorer scorer = getPluginScorerClass(def);
		if (scorer != null) {
			if (log.isTraceEnabled()) {
				log.trace("Scorer found");
			}
			scorer.score(context, config, def, src, index);
		} else {
			log.error("Error instantiating scorer");
		}
	}

}
