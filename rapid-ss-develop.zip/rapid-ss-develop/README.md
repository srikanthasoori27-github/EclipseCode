"# rapid-ss" 
This is the Accelorator Pack.
A.K.A Smart Service (SS) / Rapid Onboarding of Applications 'Doohickey?' (ROAD)
In order to build the rapid-ss project:
 1. Clone repo
 2. Add/Create a folder in the rapid-ss cloned directory named 'base/ga'
 3. Place a copy of the IdentityIQ zip file in this new ga directory. A copy of identityiq-8.0.zip is located on sloop at "\\sloop\knockabout\Rapid Development\"
 4. Run 'ant zipRelease' in the rapid-ss direcoty to build the project
 5. If the first run of 'ant zipRelease' fails, try again as the first run creates a /base/efix/8.0 folder (8.0 represents the IIQ release and may be different for your build)
