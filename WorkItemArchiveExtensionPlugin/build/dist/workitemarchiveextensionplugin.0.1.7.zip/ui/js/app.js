/**
 * Create the module.
 */

var ksModule = angular.module('workitemarchiveextensionplugin', []);

/**
 * Define any configs or statics
 */
//ksModule.config(function ($httpProvider) {
//    $httpProvider.defaults.xsrfCookieName = "CSRF-TOKEN";
//});


/**
 * Controller for the Kitchen Sink plugin.
 */
ksModule.controller('workitemarchiveextensionpluginController', [ '$scope','$http', function($scope,$http) {
	$scope.welcomeMessage="Hello, World!";
	 $scope.results = "";
   $scope.objects = "";  
	
	 $http({
      method: 'GET',
	     url: PluginHelper.getPluginRestUrl("workitemarchiveextensionplugin/workitemarchiveExtension")
    }).then(function successCallback(response) {
		   try {
		          $scope.objects = response.data;
	       }  catch(err) {
               $scope.directions= "Search error!";
               $scope.objects = ["Search error: could not parse response"];           
           }
	   }, function errorCallback(response) {
             $scope.directions= "Search error: unable to get list of objects!";
           
	   });
}]

);
