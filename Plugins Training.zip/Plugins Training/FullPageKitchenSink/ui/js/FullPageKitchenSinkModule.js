/**
 * Create the module.
 */

var ksModule = angular.module('FullPageKitchenSink', ['ui.bootstrap', 'sailpoint.i18n',
  'sailpoint.comment', 'sailpoint.email', 'sailpoint.esig',
  'sailpoint.identity.account', 'sailpoint.modal',
  'sailpoint.util', 'sailpoint.tree', 'sailpoint.ui.bootstrap.carousel',
  'sailpoint.dataview', 'sailpoint.config']);

/**
 * Define any configs or statics
 */
ksModule.config(function ($httpProvider) {
    $httpProvider.defaults.xsrfCookieName = "CSRF-TOKEN";
});

/**
 * Defining a test object directive for the card list
 */
ksModule.directive('testObject', function() {
    return {
        restrict: 'E',
        scope: {
            testObject: '=testObject'
        },
        controller: 'ksController',
        controllerAs: 'ctrl',
        bindToController: true,
        templateUrl: '../plugin/FullPageKitchenSink/ui/js/template/testObject-template.html' 
    };
});

/**
 * Controller for the Kitchen Sink plugin.
 */
ksModule.controller('ksController', function(commentService, $q, 
    spModal, spNotificationService, navigationService,
    configService, ColumnConfig, ListResultDTO, 
    PagingData, SortOrder, spTranslateFilter, SUNRISE_TEMPLATE_URL,
    SUNRISE_FOOTER_URL, infoModalService, DataTableDirectiveConfig, CardListConfig) {

    
    var me = this,
        // dummy column configs to stage some data
        colConfig1 = {
            dataIndex: 'name',
            label: 'Username'
        }, colConfig2 = {
            dataIndex: 'displayableName',
            label: 'Name'
        }, colConfig3 = {
            dataIndex: 'id',
            fieldOnly: true
        },
        // set up some staged data for the tree directive
        parents = [{
            name: 'Dad',
            hasChildren: true,
            children: [{
                name: 'Me',
                hasChildren: false
            }, {
                name: 'Bro',
                hasChildren: false
            }, {
                name: 'Sis',
                hasChildren: false
            }]
        }],
        gramps = {
            name: 'Granddaddy',
            hasChildren: true,
            children: parents
        },
        granny = {
            name: 'Granny',
            hasChildren: false
        },
        // use this as a static to generate x amount of paged results
        stagedDataCount = 22;

    // this variable will hold the nodes used in the tree directive
    me.nodes = [ gramps, granny ];

    // set up some dates for the dueDateDirective and sunrise dialog
    me.today = new Date();
    me.tomorrow = new Date();
    me.dayAfter = new Date();
    me.tomorrow.setDate(me.tomorrow.getDate() + 1);
    me.dayAfter.setDate(me.dayAfter.getDate() + 2);

    // set up some staged PTO data for the data table directive
    me.ptos = [];
    me.tempDate = new Date();
    for (var i = 1; i <= stagedDataCount; i++) {
        me.tempDate.setDate(me.tempDate.getDate() + 1);
        me.ptos.push({
            "accountDisplayName": "Person" + i,
            "applicationName": "IdentityIQ",
            "attributeRequests": [],
            "attributes": null,
            "certificationName": null,
            "created": new Date(me.tempDate.getTime()),
            "errorMessages": [],
            "filteredRequests": [],
            "forceable": true,
            "forced": false,
            "id": i,
            "identityDisplayName": "Person" + i,
            "identityName": "Dot Person" + i,
            "integration": "IdentityIQ",
            "lastRetry": null,
            "manualWorkItem": null,
            "modified": null,
            "name": i,
            "nativeIdentity": "Dot Person",
            "operation": "Modify",
            "permissionRequests": [],
            "result": null,
            "retry": false,
            "retryCount": 0,
            "source": (i % 2 == 0) ? "Rule" : "LCM",
            "status": "Success",
            "statusMessage": "Success",
            "ticketId": null,
            "timedOut": false,
            "type": "Auto",
            "typeMessage": "Auto"});
    }

    // Create the data table config. Here we are going to piggy back off the Admin Console column configs
    me.tableConfig = new DataTableDirectiveConfig({
        columnConfigKey: 'provisioningTransactionColumns',
        headerEnabled: true,
        columnsBtnEnabled: false,
        pagingInfoEnabled: true
    });

    // set up some dummy data for demonstrating the dropdown directive
    me.dropdownOptions = [{
        displayName: 'first thing',
        id: 1
    }, {
        displayName: 'second thing',
        id: 2
    }, {
        displayName: 'third thing',
        id: 3
    }];
    
    // set a 5 limit to demonstrate paging for the card list
    me.pagingData = new PagingData(5);

    // variable used to demonstrate sp-animate-change directive
    me.animateValue = 0;

    // set up some column configs for the cards
    me.columnConfigs = [
        new ColumnConfig(colConfig1),
        new ColumnConfig(colConfig2),
        new ColumnConfig(colConfig3)
    ];
    
    // stage data for the people to be represented in the cards
    me.people = [];
    for (var i = 1; i <= stagedDataCount; i++) {
        me.people.push({
            id: i,
            name: 'Johnny' + i, 
            displayableName: 'Johnny No. ' + i
        });
    };

    // dummy variable for a holder for required text field
    me.requiredText = "This field is required";

    // dummy card list config for the card list directive
    // we don't need to define a column config since we are already
    // staging test data as part of the getItems() that gets called
    me.cardListConfig = new CardListConfig({});

    /**
     * Function used by the card list directive to populate the items to show.
     * Here we will just return the paginated staged data
     *
     * @return Promise A promise that resolves with the array of cards
     */
    me.getItems = function(startIdx, itemsPerPage, filterValues, sortOrder) {
        var sliced = me.people.slice(startIdx, startIdx + itemsPerPage),
            result = {
                data: new ListResultDTO({
                    count: me.people.length,
                    objects: sliced
                })
        };
        return $q.when(result);
    }

    /**
    * Return the card list config needed by the card list directive.
    */
    me.getCardListConfig = function() {
        return me.cardListConfig;
    }

    /**
     * Function to call the comment service to open its modal
     */
    me.openComment = function() {
        commentService.openCommentDialog('Kitchen Sink Comment Service Modal',
            'This is a test modal from the comment service');
    };

    /**
    * Calls the spModal service to open a test modal
    */
    me.openModal = function() {
        spModal.open({
            title: 'Kitchen sink modal',
            backdrop: 'static',
            content: 'This is a test modal using the spModal service',
            handleCancelPromise: true
        });
    };

    /**
    * Calls the spNotification service to trigger an alert
    */
    me.addNotification = function() {
        spNotificationService.addNotification('This is a test alert notification',
                    spNotificationService.STATUS.ERROR);
        spNotificationService.triggerDirective();
    };

    /**
    * Takes the user to Request Access via the navigation service
    */
    me.goToRequestAccess = function() {
        navigationService.go({
            url: '../accessRequest/accessRequest.jsf'
        });
    };

    me.getColumnConfigs = function() {
        return me.columnConfigs;
    };

    /**
    * Opens a modal with the sunrise/sunset template
    */
    me.openSunriseDialog = function() {
        spModal.open({
            title: spTranslateFilter('ui_request_edit_start_end_date'),
            controller: 'SunriseDialogCtrl as ctrl',
            templateUrl: SUNRISE_TEMPLATE_URL,
            footerTemplateUrl: SUNRISE_FOOTER_URL,
            resolve: {
                sunriseDate: function() {
                    return new Date();
                },
                sunsetDate: function() {
                    return new Date();
                }
            },
            backdrop: 'static',
            keyboard: false,
            handleCancelPromise: true
        });
    };

    /**
    * Opens a test info modal
    */
    me.openInfoModal = function() {
        infoModalService.open('Kitchen Sink Info Modal', 'This is a test info modal');
    }

    /**
    * Returns dummy PTOs defined earlier. This mocks what the datatable would expect
    */
    me.getPtos = function(startIdx, itemsPerPage, filterValues, sortOrder) {
        var copy = me.ptos.slice();
        if (sortOrder) {
            copy.sort(function(a, b) {
                var valA = a[sortOrder.getSortProperty()];
                var valB = b[sortOrder.getSortProperty()];
                if (valA < valB) {
                    return -1;
                }
                if (valA > valB) {
                    return 1;
                }
                 // must be equal
                return 0;
            });
            if (!sortOrder.isSortAscending()) {
                copy.reverse();
            }
        }

        var sliced = copy.slice(startIdx, startIdx + itemsPerPage),
            result = {
                data: new ListResultDTO({
                    count: me.ptos.length,
                    objects: sliced
                })
        };
        return $q.when(result);
    };

    /**
    * Returns the data table config
    */
    me.getDataTableConfig = function() {
        return me.tableConfig;
    };

    /**
    * Returns the date for tomorrow
    */
    me.getTomorrow = function() {
        return me.tomorrow;
    };

    /**
    * Returns the date for the day after tomorrow
    */
    me.getDayAfter = function() {
        return me.dayAfter;
    }
});
